# Implementation Plan: Executive-Grade Enterprise ERP & HRIS with Kong Gateway, Multi-Tier RBAC, Dynamic Whitelabeling & Standardized Architecture

This plan establishes an enterprise-grade foundation for the **Sachhi Saheli SaaS ERP**, incorporating:
- **Kong API Gateway**: High-performance API Gateway with declarative configuration (`kong.yml`) routing web, api, python-worker, storage, and auth.
- **Standardized Error Taxonomy (`errors.ts`)**: RFC 7807 compliant error envelopes with distinct domain error codes (`AppError`, `ValidationError`, `ForbiddenError`, `TenantError`).
- **Structured Logging Everywhere (`logger.ts`)**: Correlation IDs (`x-request-id`), tenant isolation context, and audit-ready logging across all routes.
- **Comprehensive Automated Test Suite**: Automated unit and integration tests covering multi-tenancy, statutory labour laws, workflow state machines, and authentication.
- **3-Tier Multi-Level User Hierarchy**:
  1. **Super Admin**: Platform-wide operator (tenant lifecycle, billing, system telemetry).
  2. **App Developer**: Developer/Integrator role (API keys, webhooks, Platform Studio schema tuning, worker queue monitoring).
  3. **Client-Level Roles**: Organization-level personas (`PRESIDENT`, `HR`, `FINANCE`, `MANAGER`, `EMPLOYEE`).
- **Dynamic Whitelabeling & Multi-Tenant Theming**: Complete tenant-specific branding (organization name, logo, favicon, primary/accent colors via CSS variables, legal entity type, and currency).
- **Postgres 16, Redis 7, MinIO S3 & Zitadel IAM**: Local dockerized infrastructure with automated schema migrations and seed data (no hardcoded mock data).
- **Executive-Style UX Suite**: 9-dot App Launcher, View Switchers (Kanban/List/Form), Record Chatter with activities, and all 16 BRD workflow modules.

---

## 1. System Architecture & Kong API Gateway

```
                         ┌─────────────────────────────────┐
                         │    Client Browser / SPA Web     │
                         └────────────────┬────────────────┘
                                          │ HTTP :80 / :443
                         ┌────────────────▼────────────────┐
                         │      Kong API Gateway (:8000)   │
                         │   (Declarative kong.yml router) │
                         │   • CORS & Rate Limiting        │
                         │   • Correlation ID Injection    │
                         └──┬───────┬────────────┬──────┬──┘
                            │       │            │      │
          ┌─────────────────┘       │            │      └─────────────────┐
          │ /                       │ /api       │ /worker                │ /storage
   ┌──────▼──────┐           ┌──────▼──────┐ ┌───▼───────────┐     ┌──────▼──────┐
   │  React Web  │           │   Node.js   │ │ Python Worker │     │    MinIO    │
   │  (:3000)    │           │ Modular API │ │ (FastAPI:8000)│     │ S3 (:9000)  │
   └─────────────┘           └──────┬──────┘ └───────────────┘     └─────────────┘
                                    │
                 ┌──────────────────┼──────────────────┐
                 │                  │                  │
          ┌──────▼──────┐    ┌──────▼──────┐    ┌──────▼──────┐
          │ PostgreSQL  │    │    Redis    │    │   Zitadel   │
          │    (:5432)  │    │   (:6379)   │    │  IAM (:8080)│
          └─────────────┘    └─────────────┘    └─────────────┘
```

### Kong Gateway Configuration (`kong.yml`):
- Declarative mode (DB-less for maximum speed and simplicity in Docker).
- **Services & Routes**:
  - `web`: path `/` -> `http://web:3000`
  - `api`: path `/api` -> `http://api:4000` (strips `/api` prefix or rewrites)
  - `worker`: path `/worker` -> `http://python-worker:8000`
  - `storage`: path `/storage` -> `http://minio:9000`
  - `auth`: path `/auth` -> `http://zitadel:8080`
- **Global Plugins**:
  - `correlation-id`: Injects or preserves `X-Request-ID` across every request.
  - `cors`: Handles origins, methods, credentials, and headers.
  - `request-transformer`: Propagates tenant context headers.

---

## 2. Standardized Error Handling & Structured Logging

### A. Standardized Error Architecture (`apps/api/src/core/errors/index.ts`)
```typescript
export abstract class AppError extends Error {
  abstract readonly statusCode: number;
  abstract readonly errorCode: string;
  constructor(message: string, public readonly details?: any) {
    super(message);
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

export class ValidationError extends AppError {
  readonly statusCode = 400;
  readonly errorCode = 'VALIDATION_ERROR';
}

export class UnauthorizedError extends AppError {
  readonly statusCode = 401;
  readonly errorCode = 'UNAUTHORIZED';
}

export class ForbiddenError extends AppError {
  readonly statusCode = 403;
  readonly errorCode = 'FORBIDDEN_ACCESS';
}

export class NotFoundError extends AppError {
  readonly statusCode = 404;
  readonly errorCode = 'NOT_FOUND';
}

export class ConflictError extends AppError {
  readonly statusCode = 409;
  readonly errorCode = 'RESOURCE_CONFLICT';
}

export class TenantError extends AppError {
  readonly statusCode = 400;
  readonly errorCode = 'INVALID_TENANT';
}
```

Standardized JSON error envelope returned on every failure:
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Tenure must be at least 5 years for Gratuity eligibility",
    "details": { "field": "tenureYears", "value": 3.2 },
    "requestId": "req_8f19bc2a",
    "timestamp": "2026-09-19T03:35:00.000Z"
  }
}
```

### B. Structured Logging (`apps/api/src/core/logging/logger.ts`)
- Lightweight, zero-overhead structured logger outputting JSON with:
  - `timestamp`, `level` (`DEBUG`, `INFO`, `WARN`, `ERROR`)
  - `requestId` (from Kong or generated)
  - `tenantId`
  - `userId` & `userRole`
  - `module` (e.g. `HRIS:PAYROLL`, `WORKFLOW`, `AUTH`)
  - `durationMs` and HTTP status codes for all requests.

---

## 3. Multi-Level User Hierarchy (3 Tiers)

1. **Tier 1: SUPER_ADMIN (Platform Operator)**:
   - Tenant lifecycle: Create, configure, suspend, and view organizations.
   - Global telemetry, audit logs, and infrastructure health metrics.
2. **Tier 2: APP_DEVELOPER (System Engineer / Integrator)**:
   - Webhook & API key configuration.
   - Platform Studio customization: Edit workflow approval steps, adjust statutory formulas, inspect database tables, and view python-worker task queues.
3. **Tier 3: CLIENT_LEVEL_USERS (Tenant Organization)**:
   - `PRESIDENT`: Executive Director / Organization Head (final sign-off on budgets, offers, payroll, exit settlements).
   - `HR`: HR Head & People Ops (recruitment, onboarding, leave balances, policy compliance).
   - `FINANCE`: Finance Controller (payroll disbursement, COA, AP/AR invoices, gratuity payouts).
   - `MANAGER`: Function Head / Reporting Manager (team attendance, travel approval, appraisals).
   - `EMPLOYEE`: Individual Contributor (self-service profile, punch-in, leave apply, payslip download).

---

## 4. Dynamic Whitelabeling & Branding Engine

Every tenant in PostgreSQL stores branding metadata:
```sql
CREATE TABLE tenants (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(64) UNIQUE NOT NULL,
    logo_url TEXT,
    favicon_url TEXT,
    primary_color VARCHAR(16) DEFAULT '#4f46e5',
    accent_color VARCHAR(16) DEFAULT '#065f46',
    legal_entity_type VARCHAR(64) DEFAULT 'NGO',
    currency VARCHAR(8) DEFAULT 'INR',
    tagline VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
```

### Frontend Dynamic Theming (`TenantBrandingContext.tsx`):
- On app load, fetches `/api/tenant/branding`.
- Injects dynamic CSS variables into `:root`:
  - `--tenant-primary`: e.g. `#4f46e5`
  - `--tenant-accent`: e.g. `#065f46`
- Updates header logo, page title, favicon, and brand tags instantly.
- Tenant switcher allows testing with **Sachhi Saheli (NGO)** and switching to **Apex Global Corp (Enterprise)** to demonstrate instant whitelabeling.

---

## 5. Automated Test Suite Architecture

We will implement comprehensive automated tests (`apps/api/test/`):
1. **Statutory Labour Law Tests (`compliance.test.ts`)**:
   - Gratuity Act 1972 formula: `(15 * Basic * Years) / 26` (verifying 5-year cutoff & rounding).
   - EPF 1952 formula: 12% employee + 12% employer.
   - Maternity Benefit Act 2017: 26 weeks entitlement check.
2. **Workflow State Machine Tests (`workflow.test.ts`)**:
   - Test approval transitions across all stages: `DRAFT` -> `PENDING_MANAGER` -> `PENDING_HR` -> `PENDING_PRESIDENT` -> `APPROVED`.
   - Ensure unauthorized role attempts trigger `ForbiddenError (403)`.
3. **Multi-Tenancy Isolation Tests (`tenancy.test.ts`)**:
   - Ensure Tenant A cannot read or modify Tenant B's employees, workflows, or financial records.
4. **Error Handling Tests (`errors.test.ts`)**:
   - Verify standardized error format and correlation ID propagation.

---

## 6. Executive-Style UX & All Missing BRD Modules

- **9-Dot App Launcher**: Quick-search waffle menu to jump between all 14 apps.
- **Dynamic View Switchers**: ▦ Kanban, ☰ List, ☷ Form, 📈 Analytics.
- **Record Chatter**: Messages, Log Notes, Scheduled Activities, and Audit timeline on every record.
- **Recruitment & Candidate Kanban**: 5 stages, 2-reference checks verification modal, President offer letters.
- **Onboarding & Induction**: 3 Category checklists (Standard, Intern, Contractual), IT/Admin provisioning, 6-month probation tracker.
- **Performance & KRAs**: SMART KRAs, self & manager ratings, President calibration bell curve.
- **Travel & Expense Management**: Tour approvals with advances, city tier per-diem validation, local conveyance, emergency advances.
- **Exit & Offboarding**: 16-step departmental clearance, F&F settlement with Gratuity & Leave encashment, relieving certificates.
- **Finance & Accounting**: Chart of Accounts, Invoices (AR), Vendor Bills (AP), General Ledger.
- **CRM & PPM**: Donor pipeline Kanban, Project task Kanban (To Do -> Done), Timesheet logging.
- **Python Worker Document Integration**: Live PDF generation for Payslips, Offers, and Relieving letters.

---

## 7. Verification Plan

### Automated Execution
1. Run automated test suite: `npm --prefix apps/api test` (all tests passing).
2. TypeScript build check: `npm --prefix apps/api run build && npm --prefix apps/web run build` (0 errors).
3. Validate Kong Gateway declarative configuration: verify `kong.yml` syntax.

### Live UI & System Verification
1. **Kong Gateway Routing**: Verify Kong routes `/api/health`, `/worker/health`, `/storage`, and `/`.
2. **Dynamic Whitelabeling**: Switch between "Sachhi Saheli" and a demo tenant; verify logo, title, and theme colors update dynamically.
3. **Multi-Tier RBAC**: Switch personas between Super Admin, App Developer, President, HR, Finance, Manager, and Employee.
4. **Standardized Errors & Logging**: Trigger validation errors and verify structured error envelope with `requestId` in console.
5. **Enterprise Multi-Views & Chatter**: Verify Kanban/List switching and log notes/activities on records.
