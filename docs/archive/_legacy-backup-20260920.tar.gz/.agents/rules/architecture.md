# Architecture Rules: Modular Monolith with Microservices Readiness

## Core Architecture Principles

1. **Modular Monolith as the Standard**:
   - The application is composed of isolated, self-contained business modules inside `apps/api/src/modules/`.
   - Each module owns its:
     - Domain Entities & DTOs
     - Controllers (REST endpoints)
     - Business Services
     - Repositories / Data Access
     - Event Handlers
   - No module may directly import private implementation details of another module.

2. **Decoupled Inter-Module Communication**:
   - Synchronous queries must pass through exported Public Module Services or Facades.
   - Cross-domain side-effects (e.g. Leave approved -> Notify Payroll; Exit finalized -> Close Access & Post Journal) must trigger via the **Domain Event Bus**.
   - This ensures any module can be cut out and deployed as a standalone microservice container by replacing in-memory event dispatch with a message queue (RabbitMQ/Redis/Kafka) without modifying domain logic.

3. **Database Isolation Strategy**:
   - While sharing a PostgreSQL database in the monolithic deployment, each module operates on separate schema tables or logical table namespaces (e.g. `hris_*`, `finance_*`, `crm_*`, `ppm_*`, `workflow_*`).
   - Cross-module foreign key constraints that would block microservice separation should be avoided or loosely coupled via UUID references.

4. **Auxiliary Document Microservice (Python)**:
   - Compute-heavy jobs, PDF payslip generation, digital sign stamping, and statutory export files belong in the `apps/python-worker` microservice.
   - The Node.js API invokes this microservice via REST or asynchronous worker queues.
