# Workflow Library & Authority Approval Matrix

This document defines the 16 multi-level approval workflows specified in the Sachhi Saheli BRD v2. All state transitions in the workflow engine must adhere to these steps and approver authorities.

| # | Workflow Name | Trigger Event | Approval Chain / Steps | Final Sign-off | Key Output / Action |
|---|---|---|---|---|---|
| 1 | **Recruitment Requisition** | New position identified | Function Head -> President | President | Job posting authorized with budget band |
| 2 | **Candidate Offer** | 2 Reference checks completed | HR -> President | President | Digitally signed offer letter with secure acceptance link |
| 3 | **Onboarding / Induction** | Offer accepted | Admin (Desk/Equipment) + IT (Access) + Function Head | HR | Orientation complete, probation tracking initiated |
| 4 | **Attendance Check-in / Lateness** | Daily check-in after 10 AM | Auto-flag -> Reporting Manager | Reporting Manager | 3rd late arrival initiates half-day pay deduction |
| 5 | **Work From Home (WFH)** | Employee request (<=2/mo) | Reporting Manager -> President | President | Attendance credit & WFH registry update |
| 6 | **Standard Leave (CL/SL/EL/LWP)** | Leave request submitted | Reporting Manager | Reporting Manager | Balance deduction & payroll sync |
| 7 | **Special Leave (ML/PtL/AL)** | Maternity/Paternity/Adoption | Reporting Manager -> HR -> President | President | Statutory 26w/5d leave entitlement booked |
| 8 | **Performance Appraisal** | Annual cycle (1 April) | Self-Review -> Manager Rating -> President Calibration | President | Bell-curve calibration & increment/promotion order |
| 9 | **Monthly Payroll Processing** | End of calendar month | Attendance/Deduction cutoff -> Finance -> President | President | Bank disbursement file & digital payslips |
| 10 | **Tour / Travel Approval** | Tour requested (3-4d ahead) | Reporting Manager -> President (if HOD or Inter-state) | President / RM | Advance disbursement & travel booking |
| 11 | **Travel Expense Claim** | Within 7 days of return | Reporting Manager -> Finance | Finance | Per-diem tier validation & expense reimbursement |
| 12 | **Local Conveyance Claim** | Daily business movement | Reporting Manager -> Finance | Finance | Mileage/voucher reimbursement |
| 13 | **Employee Resignation / Exit** | Resignation submitted | Reporting Manager -> HR -> President | President | Notice period countdown & 16-step exit checklist |
| 14 | **Full & Final Settlement (F&F)** | Exit checklist completed | Finance -> President | President | F&F statement, gratuity payout, relieving letter |
| 15 | **Health Check-up Reimbursement**| Bill submitted | HR -> Finance | Finance | Reimbursement of ₹2,000-₹3,000 |
| 16 | **Emergency Salary Advance** | Application submitted | Reporting Manager -> Finance -> President | President | Advance disbursed, 12-month EMI schedule mapped to payroll |

## State Machine Conventions
All workflows operate on standard states:
`DRAFT` -> `PENDING_APPROVAL` (with current `assigned_approver_role`) -> `APPROVED` | `REJECTED` | `CANCELLED`.
Workflows with multiple stages transition `PENDING_STAGE_1` -> `PENDING_STAGE_2` -> `PENDING_STAGE_FINAL` -> `APPROVED`.
