# Security, RBAC & Audit Trail Specifications

## 1. Role-Based Access Control (RBAC)
The ERP strictly enforces five primary role levels:
1. **EMPLOYEE**: Self-service (Profile view, Attendance clock-in/out, Leave applications, Payslip view/download, Reimbursement claims, Resignation).
2. **MANAGER (Reporting Manager / Function Head)**: Team oversight, Approval of standard leave, WFH recommendations, Appraisals, Tour approvals, Requisitions.
3. **HR (HR Manager / HR Operations)**: Employee lifecycle management, Onboarding/Exit coordination, Special leave verification, Policy compliance, Attendance monthly closure.
4. **FINANCE (Finance Head / Accounts Team)**: Payroll calculations, Statutory payouts (PF, Gratuity), Travel expense audits, F&F settlement calculations, General Ledger postings.
5. **PRESIDENT (Executive Director / Super Admin)**: Organization-wide authority, Final sign-off on Job requisitions, Candidate offers, Special leaves, WFH, Appraisal calibration, Monthly payroll release, F&F settlements, Emergency advances.

## 2. Authentication & Session Management
- **Password Policy**: Minimum 8 characters, including upper, lower, numeric, and special characters. Forced reset every 180 days.
- **Session Timeout**: Auto-logout after 20 minutes of inactivity for sensitive roles (Finance, HR, President).
- **JWT Tokens**: Short-lived Access Tokens (15-30 mins) with secure HTTP-only Refresh Tokens.

## 3. Immutable Audit Trails & Document Retention
- Every state transition, approval action, salary modification, and document generation creates an append-only audit event in `audit_logs`.
- Minimum 6+ years data retention compliance for statutory labour law records.
- Records can never be silently mutated or hard-deleted. Soft deletions with tombstone audit records are mandatory.
