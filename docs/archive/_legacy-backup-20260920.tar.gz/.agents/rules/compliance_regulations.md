# Indian Statutory Compliance & Labour Law Regulations

All HRIS, Payroll, Leave, and Exit logic must strictly adhere to the following Indian Labour Laws and Sachhi Saheli policies as specified in BRD v2:

## 1. Provident Fund (EPF & MP Act, 1952)
- **Employee Contribution**: 12% of (Basic Salary + Dearness Allowance).
- **Employer Contribution**: 12% of (Basic Salary + Dearness Allowance), split into EPF (3.67%) and EPS (8.33% up to statutory wage ceiling of ₹15,000, or actual as per organization policy).
- Calculations must be precision-rounded to nearest rupee.

## 2. Payment of Gratuity Act, 1972
- **Eligibility**: Minimum 5 continuous years of full-time service (waived in case of demise or permanent disablement).
- **Calculation Formula**:
  `Gratuity = (15 * Last Drawn Basic Salary * Tenure in Completed Years) / 26`
- Years of service calculation: Part of year exceeding 6 months counts as 1 full year.

## 3. Leave Entitlements & Rules
- **Casual Leave (CL)**: 10 days / year. Cannot be carried forward. Approver: Reporting Manager.
- **Sick Leave (SL)**: 10 days / year. Cannot be carried forward. Approver: Reporting Manager.
- **Earned Leave (EL)**: 15 days / year. Max carryover capped at 30 days.
  - Requires minimum 6 months of continuous service to apply.
  - Minimum 15 days advance notice required before taking leave.
- **Maternity Leave (ML)**: 26 weeks paid leave as per Maternity Benefit (Amendment) Act 2017. Requires supporting medical records. Multi-level approval: Reporting Manager -> HR -> President.
- **Paternity Leave (PtL)**: 5 days. Approver: Reporting Manager -> HR -> President.
- **Adoption Leave (AL)**: 5 days. Approver: Reporting Manager -> HR -> President.
- **Leave Without Pay (LWP)**: Up to 30 days. Approver: Reporting Manager.
- **Compensatory Off**: Earned by working on non-working days. Approver: Reporting Manager.

## 4. Attendance & Working Hours Rules
- Official business start: 10:00 AM.
- Digital check-in after 10:00 AM triggers an automatic **Lateness Flag**.
- Repeated lateness rule: 3 or more late arrivals within a calendar month trigger an automatic **Half-Day Salary Deduction**.
- **Work From Home (WFH)**: Capped at a maximum of 2 days per month. Requires 2-tier approval (Reporting Manager + President).

## 5. Benefits & Advance Regulations
- **Medical Insurance**: ₹3,00,000 cover per family.
- **Personal Accident Cover**: ₹5,00,000 per employee.
- **Annual Health Check-Up Reimbursement**: ₹2,000 - ₹3,000 based on employee age band.
- **Emergency Salary Advance**:
  - Maximum limit: up to 3 months' gross salary or ₹1,00,000 (whichever is lower).
  - Repayment: Deducted via monthly EMI across a maximum 12-month tenure.

## 6. Exit & Clearance (16-Step Clearance Checklist)
- Notice period adherence tracking.
- Departmental clearances: Admin (assets/ID card), IT (email, laptop, credentials), Finance (travel advances, loans, recovery), HR (records, leaves).
- Full & Final (F&F) Settlement: Pending basic salary, earned leave encashment, statutory gratuity, less loan/advance deductions.
- Mandatory approval chain for F&F: Finance Head -> President.
- Relieving letter and Experience Certificate issued only upon status = `PAID`.
