# Sachhi Saheli Enterprise ERP & HRIS — Workspace Instructions

Welcome to the **Sachhi Saheli SaaS ERP** codebase. This project implements a full-featured Enterprise Resource Planning system with a primary focus on **Human Resource Information System (HRIS)** (Phase 1), with integrated domains for **Finance & Accounts**, **CRM**, and **Project & Portfolio Management (PPM)**.

---

## 1. Architectural Philosophy: Modular Monolith (Microservices-Ready)

This codebase follows a **Modular Monolith** pattern:
- **Single Process / Unified Deployment**: The application runs as a modular monolith for maximum operational simplicity, low latency, and ease of deployment.
- **Strict Domain Boundaries**: Each domain (`hris`, `finance`, `crm`, `ppm`, `workflow-engine`, `compliance`) is encapsulated in `apps/api/src/modules/<domain>`.
- **Decoupled Communication**: Modules interact via explicit public service interfaces or the asynchronous Domain Event Bus (`apps/api/src/core/events/`). Direct database joins or direct cross-module private model access are prohibited.
- **Microservice Extraction Ready**: Any module can be extracted into an independent microservice container with zero business logic rewriting.
- **Auxiliary Microservices**: Heavy computation and PDF document rendering (Payslips, Relieving Letters, Statutory Reports) are offloaded to `apps/python-worker` (FastAPI).

---

## 2. Directory Structure

```
saas-erp/
├── .agents/
│   └── rules/
│       ├── architecture.md           # Domain-driven boundaries & microservice extraction rules
│       ├── compliance_regulations.md  # Statutory Indian Labour Laws (PF, Gratuity, Maternity, Leaves)
│       ├── workflow_matrix.md        # The 16 BRD approval workflows and authority matrix
│       └── security_rbac.md          # RBAC, audit trails, and data protection rules
├── AGENTS.md                         # This file (workspace root rules)
├── docker-compose.yml                # Full stack container orchestration
├── apps/
│   ├── api/                          # Modular Monolith Backend (Node.js, Express, TypeScript)
│   ├── web/                          # Premium React SPA (React 19/18, Tailwind CSS, Lucide icons)
│   └── python-worker/                # Document & Statutory Calculation Microservice (FastAPI)
```

---

## 3. Statutory Compliance Requirements

All developers and agents working on this project must uphold Indian statutory mandates:
- **Payment of Gratuity Act, 1972**: `(15 * Basic Salary * Tenure in Years) / 26` for eligible employees (>= 5 years of service, except death/disability).
- **Employees' Provident Funds and Miscellaneous Provisions Act, 1952**: 12% employee contribution + 12% employer contribution on Basic + DA.
- **Maternity Benefit (Amendment) Act, 2017**: 26 weeks paid leave for female employees with multi-level sign-off (Manager -> HR -> President).
- **Paternity & Adoption Leave**: 5 days with Manager -> HR -> President sign-off.
- **Earned Leave (EL)**: Minimum 6 months of continuous service, 15 days advance notice, carryover capped at 30 days.
- **Audit & Record Retention**: All payroll, attendance, and exit records must be retained for at least 6 years in an immutable audit ledger.

---

## 4. UI/UX Excellence Standards

The frontend must provide an **executive-grade, bespoke user experience**:
- **Design Language**: Polished modern SaaS aesthetic (Tailwind CSS, curated color palette with deep slate, indigo, emerald accents, glassmorphism, subtle micro-animations).
- **No Generic Placeholders**: Interactive data visualizations, role switcher (President, HR, Manager, Finance, Employee), real-time approval queues, and complete forms.
- **Accessibility & Responsiveness**: Clean typography, full mobile/tablet responsiveness, keyboard accessibility, and intuitive navigation.
