# Implementation Plan: Executive-Grade Enterprise ERP & HRIS with Multi-Tenancy, Zitadel, PostgreSQL, Redis, MinIO & API Gateway

This plan details the full implementation of the **Sachhi Saheli SaaS ERP**, upgrading it to an executive **Executive-Style platform** with complete production-grade infrastructure:
- **Local Infrastructure (Docker Compose)**: PostgreSQL 16, Redis 7, MinIO S3 Object Storage (with bucket provisioning), Nginx API Gateway, Python Worker, and Zitadel IAM for authentication.
- **True Multi-Tenancy**: Schema design with `tenant_id` on all entities, tenant context middleware, and tenant-isolated repository queries.
- **No Hardcoded Mock Data**: Full PostgreSQL schema migrations and automated DB seed script (`schema.sql` & `seed.sql`/`seed.ts`) populating relational tables directly into Postgres.
- **Zitadel IAM Integration**: Bearer token OIDC validation, organization/tenant mapping, and role extraction (`PRESIDENT`, `HR`, `FINANCE`, `MANAGER`, `EMPLOYEE`).
- **Executive-Style UX**: 9-dot App Launcher, View Switchers (Kanban / List / Form / Analytics), Record Chatter with activities and audit timeline, and Status Pipeline Ribbons.
- **All Missing BRD Features**: Recruitment & Candidate Kanban (with 2-reference check validation), Onboarding & Induction (3 category checklists & probation), Performance Management (KRAs & President calibration), Travel & Per-Diem Expense Claims, and Full & Final Exit Settlement.

---

## 1. Infrastructure Architecture & Docker Orchestration

```
                      ┌─────────────────────────────────┐
                      │    Client Browser / SPA Web     │
                      └────────────────┬────────────────┘
                                       │ HTTP :80 / :443
                      ┌────────────────▼────────────────┐
                      │     Nginx API Gateway (:80)     │
                      └──┬───────┬────────────┬──────┬──┘
                         │       │            │      │
       ┌─────────────────┘       │            │      └─────────────────┐
       │ /                       │ /api       │ /worker                │ /storage
┌──────▼──────┐           ┌──────▼──────┐ ┌───▼───────────┐     ┌──────▼──────┐
│  React Web  │           │   Node.js   │ │ Python Worker │     │    MinIO    │
│  (:3000)    │           │ Modular API │ │ (FastAPI:8000)│     │ S3 (:9000)  │
└─────────────┘           └──────┬──────┘ └───────────────┘     └─────────────┘
                                 │
              ┌──────────────────┼──────────────────┐
              │                  │                  │
       ┌──────▼──────┐    ┌──────▼──────┐    ┌──────▼──────┐
       │ PostgreSQL  │    │    Redis    │    │   Zitadel   │
       │    (:5432)  │    │   (:6379)   │    │  IAM (:8080)│
       └─────────────┘    └─────────────┘    └─────────────┘
```

### Services in `docker-compose.yml`:
1. **`postgres`**: Relational store for all ERP domains with ACID guarantees.
2. **`redis`**: Asynchronous task broker, session cache, and fast counters.
3. **`minio` & `minio-init`**: S3-compatible document storage (buckets: `sachhi-saheli-docs`, `payslips`, `attachments`). `minio-init` automatically provisions buckets and public download policies.
4. **`zitadel`**: Open-source IAM for enterprise OIDC authentication and multi-tenancy organization mapping.
5. **`gateway` (Nginx)**: API Gateway routing:
   - `/` -> `web:3000`
   - `/api/` -> `api:4000`
   - `/worker/` -> `python-worker:8000`
   - `/storage/` -> `minio:9000`
   - `/auth/` -> `zitadel:8080`
6. **`api`**: Node.js/Express Modular Monolith backend.
7. **`python-worker`**: FastAPI document & statutory calculation worker.

---

## 2. Multi-Tenancy Architecture

1. **Tenant Identification**:
   - Every HTTP request resolves `tenantId` from:
     - Zitadel OIDC token claims: `urn:zitadel:iam:org:id` / `org_id` / `tenant_id`
     - Custom fallback header for local development: `x-tenant-id` (default: `sachhi-saheli-delhi`)
2. **Database Scoping**:
   - Every database table includes `tenant_id VARCHAR(64) NOT NULL`.
   - All SQL queries explicitly filter `WHERE tenant_id = $1`.
   - Multi-tenant indexes: `CREATE INDEX idx_<table>_tenant ON <table>(tenant_id);`.
3. **Storage Scoping**:
   - S3 object keys are tenant-prefixed: `${tenantId}/${category}/${filename}`.

---

## 3. Database Schema & Automated Seeding (No Hardcoded Mock Data)

### A. Database DDL (`schema.sql`)
The PostgreSQL schema covers all domains:
- **Tenancy & IAM**: `tenants`, `users`
- **HRIS Core**:
  - `employee_profiles` (statutory info, PF/Gratuity eligibility, bank details)
  - `attendance_records` (clock-in, 10 AM late flag, WFH flag, half-day deductions)
  - `leave_balances` (8 leave types, carryforward caps)
  - `exit_records` (16-step clearance checklist, F&F settlements)
- **Recruitment & Selection**:
  - `recruitment_requisitions` (budget bands, status)
  - `candidates` (stages: Sourced -> Screening -> Interview -> Reference Check -> Offer, with 2 verified references)
- **Onboarding & Induction**:
  - `onboarding_checklists` (templates for Standard, Intern, Contractual; IT, Admin, HR tasks, 6-month probation countdown)
- **Performance & KRAs**:
  - `appraisal_cycles` & `employee_appraisals` (SMART KRAs, self-ratings, manager ratings, President calibration)
- **Travel & Expense Management**:
  - `travel_tours` (destinations, advances, city tiers)
  - `expense_claims` (per-diem limits, receipts, local conveyance, emergency salary advances)
- **Workflows & Approvals**:
  - `workflow_instances` (the 16 BRD approval workflows, current stages, multi-level sign-offs)
- **Finance & Accounting**:
  - `finance_coa` (Chart of Accounts, balances)
  - `invoices` (Accounts Receivable for donors, Accounts Payable for vendor bills)
- **CRM & PPM**:
  - `crm_contacts` & `crm_pipeline` (grant stages, donor pipeline)
  - `ppm_projects` & `ppm_tasks` (task stages: To Do -> In Progress -> Review -> Done, timesheets)
- **Audit Ledger & Record Chatter**:
  - `audit_logs` (immutable statutory compliance ledger, 6-year retention)
  - `chatter_messages` (log notes, messages, scheduled activities)

### B. Automated Seeding (`seed.sql` / `db.ts`)
- On application boot, the database connection verifies table existence, applies `schema.sql` if missing, and executes `seed.sql` to populate initial organization data for `sachhi-saheli-delhi` tenant.
- No in-memory hardcoded arrays — the database becomes the true system of record.

---

## 4. Zitadel Authentication & RBAC

1. **Zitadel OIDC Middleware (`apps/api/src/core/middleware/auth.ts`)**:
   - Inspects `Authorization: Bearer <jwt>`.
   - Decodes and validates JWT claims from Zitadel.
   - Extracts `userId`, `email`, `role` (`PRESIDENT`, `HR`, `FINANCE`, `MANAGER`, `EMPLOYEE`), and `tenantId`.
   - In local dev mode, provides simulated persona impersonation via `x-simulated-user-id` and `x-tenant-id` while maintaining full compatibility with standard Zitadel tokens.

---

## 5. Executive-Style User Experience & Frontend Architecture

1. **Enterprise 9-Dot App Launcher (`AppLauncherModal.tsx`)**:
   - Top-left 9-dot waffle icon triggering full-screen or drop-down App Launcher.
   - 14 distinct app tiles:
     - 👥 Employees Master
     - 🎯 Recruitment & Candidate Pipeline
     - 🚀 Onboarding & Induction (3 Categories)
     - 🌴 Leave & Time Off (8 Types)
     - ⏰ Attendance & Biometrics (10 AM Late Rule)
     - 💰 Payroll & Statutory (EPF 1952, Gratuity 1972)
     - 📈 Performance (KRAs & Calibration)
     - ✈️ Travel, Expenses & Advances
     - 🚪 Exit Clearance (16 Steps & F&F)
     - 📊 Finance & Invoicing (AR/AP & COA)
     - 🤝 CRM & Donor Pipeline
     - 📋 PPM & Project Tasks
     - ⚡ Approvals Inbox (16 Workflows)
     - ⚖️ Statutory Legal Vault & Audit Ledger
   - Built-in live search to filter apps instantly.
2. **Unified Multi-View Switcher (`ViewSwitcher.tsx`)**:
   - Toggle seamlessly between:
     - ▦ **Kanban View** (card boards with stage transitions)
     - ☰ **List / Tree View** (sortable data table with search filters)
     - ☷ **Form / Detail View** (with Action ribbon and status pipeline breadcrumbs)
     - 📈 **Analytics / Pivot View** (KPI summaries and distributions)
3. **Record Chatter Widget (`EnterpriseChatter.tsx`)**:
   - Tabbed interaction on every record:
     - `Send Message` / `Log Note`
     - `Schedule Activity` (Call, Email, Meeting, To-Do with due date)
     - `Audit Timeline` (immutable history of stage transitions and approvals)
4. **Enterprise Search, Filters & Group-By Bar (`EnterpriseSearchBar.tsx`)**:
   - Search query input + "Filters" dropdown + "Group By" dropdown.
5. **New & Upgraded Dedicated Module Pages**:
   - `RecruitmentPage.tsx`: Job Requisitions & 5-stage Candidate Pipeline Kanban with 2-reference check validation modal.
   - `OnboardingPage.tsx`: Induction checklists across Standard, Intern, Contractual joiners, IT/Admin provisioning, and probation tracker.
   - `PerformancePage.tsx`: SMART KRAs, self-review rating, manager rating, and President bell-curve calibration.
   - `TravelExpensesPage.tsx`: Tour approvals with advance disbursement, per-diem claims by city tier, local conveyance, emergency advances (3 mo / 12 mo EMI), and health reimbursement.
   - `EmployeesPage.tsx`, `CrmPage.tsx`, `PpmPage.tsx`, `FinancePage.tsx`, `ApprovalsPage.tsx`, `PayrollPage.tsx`: Upgraded with Kanban/List/Form views, Chatter, and real PostgreSQL persistence.

---

## 6. Python Worker & MinIO Document Integration

1. **PDF Generation**:
   - `/worker/generate-payslip-pdf`: Official payslip with statutory PF/Gratuity stamps.
   - `/worker/generate-offer-letter-pdf`: President-signed offer letter with compensation bands.
   - `/worker/generate-relieving-letter-pdf`: Relieving certificate issued upon F&F clearance.
2. **MinIO Upload**:
   - Generated PDFs and uploaded receipts are stored in MinIO S3 bucket scoped under tenant ID.

---

## 7. Verification Plan

### Automated Tests
1. **Compilation**:
   - `npm --prefix apps/api run build`
   - `npm --prefix apps/web run build`
2. **Database Initialization & Seeding**:
   - Verify PostgreSQL schema creation and seed execution without errors.
   - Query DB to verify multi-tenant data exists in `tenants`, `users`, `employees`, `workflows`, etc.
3. **Docker Services**:
   - Check `docker-compose.yml` config validation (`docker compose config`).

### Manual & UI Testing
1. **App Launcher**: Open waffle launcher, search for modules, and switch between apps.
2. **Multi-View System**: Toggle between Kanban, List, and Form views across Recruitment, CRM, PPM Tasks, and Employees.
3. **Multi-Tenancy**: Verify queries return data scoped to active tenant.
4. **Record Chatter**: Post notes, schedule activities, and verify real-time audit logs.
5. **Approval Workflow Execution**: Test 2-tier and 3-tier approvals (e.g. Maternity leave, Requisition, Tour).
6. **PDF Generation**: Download generated payslip PDF from the worker and verify formatting.
