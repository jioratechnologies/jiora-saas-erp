from fastapi import FastAPI, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import io
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib import colors

app = FastAPI(title="Sachhi Saheli Document & Statutory Microservice", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class PayslipRequest(BaseModel):
    employeeName: str
    employeeId: str
    designation: str
    department: str
    monthYear: str
    basicSalary: float
    hra: float
    specialAllowance: float
    employeePF: float
    professionalTax: float
    netPayable: float

@app.get("/health")
def health():
    return {
        "status": "HEALTHY",
        "service": "Sachhi Saheli Python Worker Microservice",
        "features": ["PDF Payslip Generation", "Offer Letters", "Statutory Compliance Audit"]
    }

@app.post("/generate-payslip-pdf")
def generate_payslip_pdf(data: PayslipRequest):
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter

    # Header
    p.setFont("Helvetica-Bold", 16)
    p.setFillColor(colors.HexColor("#1e293b"))
    p.drawString(50, height - 50, "SACHHI SAHELI (REGISTERED NGO)")
    
    p.setFont("Helvetica", 10)
    p.setFillColor(colors.HexColor("#64748b"))
    p.drawString(50, height - 65, "Promoting Menstrual Health, Gender Equity & Adolescent Well-being")
    p.drawString(50, height - 78, "Official Salary Payslip — " + data.monthYear)

    p.setStrokeColor(colors.HexColor("#cbd5e1"))
    p.line(50, height - 90, width - 50, height - 90)

    # Employee Details Box
    p.setFont("Helvetica-Bold", 10)
    p.setFillColor(colors.HexColor("#334155"))
    p.drawString(50, height - 110, f"Employee Name: {data.employeeName}")
    p.drawString(320, height - 110, f"Employee ID: {data.employeeId}")
    p.drawString(50, height - 128, f"Designation: {data.designation}")
    p.drawString(320, height - 128, f"Department: {data.department}")

    p.line(50, height - 140, width - 50, height - 140)

    # Earnings & Deductions Table
    p.setFont("Helvetica-Bold", 11)
    p.drawString(50, height - 165, "Earnings")
    p.drawString(200, height - 165, "Amount (INR)")
    p.drawString(320, height - 165, "Deductions")
    p.drawString(460, height - 165, "Amount (INR)")

    p.setFont("Helvetica", 10)
    y = height - 190
    p.drawString(50, y, "Basic Salary")
    p.drawRightString(260, y, f"Rs. {data.basicSalary:,.2f}")
    p.drawString(320, y, "Provident Fund (12%)")
    p.drawRightString(530, y, f"Rs. {data.employeePF:,.2f}")

    y -= 20
    p.drawString(50, y, "House Rent Allowance (HRA)")
    p.drawRightString(260, y, f"Rs. {data.hra:,.2f}")
    p.drawString(320, y, "Professional Tax")
    p.drawRightString(530, y, f"Rs. {data.professionalTax:,.2f}")

    y -= 20
    p.drawString(50, y, "Special Allowance")
    p.drawRightString(260, y, f"Rs. {data.specialAllowance:,.2f}")

    gross = data.basicSalary + data.hra + data.specialAllowance
    deductions = data.employeePF + data.professionalTax

    y -= 30
    p.line(50, y + 10, width - 50, y + 10)
    p.setFont("Helvetica-Bold", 10)
    p.drawString(50, y - 5, "Gross Earnings")
    p.drawRightString(260, y - 5, f"Rs. {gross:,.2f}")
    p.drawString(320, y - 5, "Total Deductions")
    p.drawRightString(530, y - 5, f"Rs. {deductions:,.2f}")

    y -= 40
    p.setFillColor(colors.HexColor("#065f46"))
    p.rect(50, y - 25, width - 100, 35, fill=1, stroke=0)
    p.setFillColor(colors.white)
    p.setFont("Helvetica-Bold", 12)
    p.drawString(70, y - 13, "NET TAKE-HOME PAYABLE:")
    p.drawRightString(width - 70, y - 13, f"Rs. {data.netPayable:,.2f}")

    # Statutory Compliance Stamp
    y -= 80
    p.setFillColor(colors.HexColor("#475569"))
    p.setFont("Helvetica", 8)
    p.drawString(50, y, "Statutory Compliance Notes:")
    p.drawString(50, y - 12, "• Provident Fund deducted and remitted under Employees' Provident Funds and Miscellaneous Provisions Act, 1952.")
    p.drawString(50, y - 24, "• Gratuity coverage governed by Payment of Gratuity Act, 1972.")
    p.drawString(50, y - 36, "• Medical insurance cover of Rs. 3,00,000 per family maintained.")
    p.drawString(50, y - 48, "• This is a computer generated salary document and requires no physical seal when issued via ERP.")

    # Signatures
    p.line(50, y - 90, 200, y - 90)
    p.drawString(50, y - 102, "Finance Controller / Accounts Head")

    p.line(width - 200, y - 90, width - 50, y - 90)
    p.drawString(width - 200, y - 102, "Authorized Signatory (President)")

    p.showPage()
    p.save()

    buffer.seek(0)
    return Response(content=buffer.getvalue(), media_type="application/pdf", headers={
        "Content-Disposition": f"attachment; filename=payslip_{data.employeeId}_{data.monthYear.replace(' ', '_')}.pdf"
    })

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
