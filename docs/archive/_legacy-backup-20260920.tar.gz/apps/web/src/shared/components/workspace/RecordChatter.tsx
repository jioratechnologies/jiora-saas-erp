import { useState, useEffect } from 'react';
import {
  MessageSquare,
  FileText,
  Calendar,
  Send,
  Phone,
  Mail,
  Users,
  CheckCircle2,
  Circle,
  Clock,
  Sparkles,
} from 'lucide-react';
import { apiClient } from '@/api';
import { useAuth } from '@/context/AuthContext';
import { useRealtime } from '@/context/RealtimeContext';

interface RecordChatterProps {
  recordType: 'candidate' | 'employee' | 'workflow' | 'invoice' | 'task' | 'onboarding' | 'appraisal' | 'contact' | 'tour' | string;
  recordId: string;
  recordTitle?: string;
}

export function RecordChatter({ recordType, recordId, recordTitle }: RecordChatterProps) {
  const { currentUser } = useAuth();
  const { subscribeToRecord, isConnected } = useRealtime();
  const [activeTab, setActiveTab] = useState<'note' | 'activity'>('note');
  const [messages, setMessages] = useState<any[]>([]);
  const [noteContent, setNoteContent] = useState('');
  const [activityType, setActivityType] = useState<'CALL' | 'EMAIL' | 'MEETING' | 'TODO'>('CALL');
  const [activityContent, setActivityContent] = useState('');
  const [activityDueDate, setActivityDueDate] = useState(
    new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0]
  );
  const [submitting, setSubmitting] = useState(false);

  const fetchChatter = async () => {
    try {
      const res = await apiClient.getChatter(recordType, recordId, currentUser);
      if (res && res.success) {
        setMessages(res.data || []);
      }
    } catch (e) {
      console.error('Failed to load chatter:', e);
    }
  };

  useEffect(() => {
    if (recordId) {
      fetchChatter();

      // Real-time WebSocket subscription for live stream updates
      const unsubscribe = subscribeToRecord(recordType, recordId, (incoming: any) => {
        if (incoming?.payload) {
          setMessages((prev) => {
            const idx = prev.findIndex((m) => m.id === incoming.payload.id);
            if (idx >= 0) {
              const updated = [...prev];
              updated[idx] = incoming.payload;
              return updated;
            }
            return [incoming.payload, ...prev];
          });
        }
      });

      return () => unsubscribe();
    }
  }, [recordType, recordId, currentUser, subscribeToRecord]);

  const handlePostNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteContent.trim() || submitting) return;

    setSubmitting(true);
    try {
      const res = await apiClient.postChatterNote(recordType, recordId, noteContent.trim(), currentUser);
      if (res && res.success) {
        setNoteContent('');
        await fetchChatter();
      }
    } catch (e) {
      console.error('Failed to post note:', e);
    } finally {
      setSubmitting(false);
    }
  };

  const handleScheduleActivity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activityContent.trim() || submitting) return;

    setSubmitting(true);
    try {
      const res = await apiClient.scheduleChatterActivity(
        recordType,
        recordId,
        activityType,
        activityContent.trim(),
        activityDueDate,
        currentUser
      );
      if (res && res.success) {
        setActivityContent('');
        setActiveTab('note');
        await fetchChatter();
      }
    } catch (e) {
      console.error('Failed to schedule activity:', e);
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleActivity = async (id: string) => {
    try {
      await apiClient.toggleChatterActivity(id, currentUser);
      await fetchChatter();
    } catch (e) {
      console.error('Failed to toggle activity:', e);
    }
  };

  const getActivityIcon = (type?: string) => {
    switch (type) {
      case 'CALL':
        return <Phone className="w-3.5 h-3.5 text-blue-400" />;
      case 'EMAIL':
        return <Mail className="w-3.5 h-3.5 text-purple-400" />;
      case 'MEETING':
        return <Users className="w-3.5 h-3.5 text-emerald-400" />;
      default:
        return <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />;
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
      {/* Top Header */}
      <div className="p-4 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-indigo-400" />
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">
            Chatter & Activities
          </h3>
          {recordTitle && (
            <span className="text-[11px] text-slate-400 truncate max-w-[200px]">
              • {recordTitle}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {isConnected && (
            <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Live Sync
            </span>
          )}
          <span className="text-[10px] text-slate-500 font-mono">
            {messages.length} events
          </span>
        </div>
      </div>

      {/* Action Buttons Tabs */}
      <div className="flex items-center gap-2 p-3 bg-slate-900/90 border-b border-slate-800">
        <button
          onClick={() => setActiveTab('note')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
            activeTab === 'note'
              ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
              : 'bg-slate-800 text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Log Note</span>
        </button>

        <button
          onClick={() => setActiveTab('activity')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
            activeTab === 'activity'
              ? 'bg-amber-600 text-white shadow-sm shadow-amber-600/30'
              : 'bg-slate-800 text-slate-400 hover:text-slate-200'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Schedule Activity</span>
        </button>
      </div>

      {/* Form Area */}
      <div className="p-4 border-b border-slate-800 bg-slate-950/40">
        {activeTab === 'note' ? (
          <form onSubmit={handlePostNote} className="space-y-2">
            <textarea
              rows={2}
              value={noteContent}
              onChange={(e) => setNoteContent(e.target.value)}
              placeholder="Log an internal note, remark or feedback..."
              className="w-full p-2.5 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition resize-none"
            />
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={!noteContent.trim() || submitting}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white shadow transition"
              >
                <Send className="w-3 h-3" />
                <span>Post Note</span>
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleScheduleActivity} className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] font-semibold text-slate-400 block mb-1">Activity Type</label>
                <select
                  value={activityType}
                  onChange={(e: any) => setActivityType(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                >
                  <option value="CALL">Call</option>
                  <option value="EMAIL">Email</option>
                  <option value="MEETING">Meeting</option>
                  <option value="TODO">To-Do</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] font-semibold text-slate-400 block mb-1">Due Date</label>
                <input
                  type="date"
                  value={activityDueDate}
                  onChange={(e) => setActivityDueDate(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>
            <input
              type="text"
              value={activityContent}
              onChange={(e) => setActivityContent(e.target.value)}
              placeholder="Summary of activity (e.g. Call candidate to confirm joining)..."
              className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={!activityContent.trim() || submitting}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white shadow transition"
              >
                <Calendar className="w-3 h-3" />
                <span>Schedule</span>
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Timeline Stream */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.length === 0 ? (
          <div className="text-center py-8 text-slate-500 text-xs">
            <Sparkles className="w-6 h-6 mx-auto mb-2 opacity-40" />
            No chatter notes or activities logged yet.
          </div>
        ) : (
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`p-3 rounded-xl border text-xs transition-all ${
                msg.messageType === 'ACTIVITY'
                  ? msg.completed
                    ? 'bg-slate-950/30 border-slate-800/60 opacity-60'
                    : 'bg-amber-950/20 border-amber-500/30'
                  : 'bg-slate-950/50 border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  {msg.messageType === 'ACTIVITY' ? (
                    <button
                      onClick={() => handleToggleActivity(msg.id)}
                      className="text-slate-400 hover:text-amber-400 transition"
                      title={msg.completed ? 'Mark pending' : 'Mark done'}
                    >
                      {msg.completed ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Circle className="w-4 h-4 text-amber-400" />
                      )}
                    </button>
                  ) : (
                    <div className="w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-300 flex items-center justify-center text-[10px] font-bold">
                      {msg.authorName ? msg.authorName[0] : 'U'}
                    </div>
                  )}
                  <span className="font-semibold text-white text-[11px]">
                    {msg.authorName || 'System'}
                  </span>
                  {msg.messageType === 'ACTIVITY' && (
                    <span className="flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                      {getActivityIcon(msg.activityType)}
                      {msg.activityType}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1 text-[10px] text-slate-500">
                  <Clock className="w-3 h-3" />
                  <span>{new Date(msg.createdAt).toLocaleDateString()}</span>
                </div>
              </div>

              <p className={`text-slate-300 text-[11px] leading-relaxed pl-6 ${msg.completed ? 'line-through text-slate-500' : ''}`}>
                {msg.content}
              </p>

              {msg.messageType === 'ACTIVITY' && msg.dueDate && (
                <div className="mt-2 pl-6 flex items-center gap-2 text-[10px] text-amber-400">
                  <span>Due by: {msg.dueDate}</span>
                  {msg.completed && <span className="text-emerald-400 font-semibold">• Completed</span>}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
