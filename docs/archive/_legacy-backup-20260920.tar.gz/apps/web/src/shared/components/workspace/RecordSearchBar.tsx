import { useState } from 'react';
import { Search, Filter, Layers, X } from 'lucide-react';

export interface FilterOption {
  id: string;
  label: string;
}

export interface GroupByOption {
  id: string;
  label: string;
}

interface RecordSearchBarProps {
  placeholder?: string;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  filters?: FilterOption[];
  activeFilters?: string[];
  onToggleFilter?: (filterId: string) => void;
  groupByOptions?: GroupByOption[];
  activeGroupBy?: string;
  onSelectGroupBy?: (groupById: string) => void;
}

export function RecordSearchBar({
  placeholder = 'Search records (Ctrl+F)...',
  searchQuery,
  onSearchChange,
  filters = [],
  activeFilters = [],
  onToggleFilter,
  groupByOptions = [],
  activeGroupBy,
  onSelectGroupBy,
}: RecordSearchBarProps) {
  const [filterMenuOpen, setFilterMenuOpen] = useState(false);
  const [groupByMenuOpen, setGroupByMenuOpen] = useState(false);

  return (
    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 w-full">
      {/* Search Input */}
      <div className="relative flex-1">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder={placeholder}
          className="w-full pl-10 pr-8 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition shadow-inner"
        />
        {searchQuery && (
          <button
            onClick={() => onSearchChange('')}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Filter Dropdown */}
      {filters.length > 0 && (
        <div className="relative">
          <button
            onClick={() => {
              setFilterMenuOpen((v) => !v);
              setGroupByMenuOpen(false);
            }}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition ${
              activeFilters.length > 0
                ? 'bg-indigo-600/20 border-indigo-500/40 text-indigo-300'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Filter className="w-3.5 h-3.5" />
            <span>Filters</span>
            {activeFilters.length > 0 && (
              <span className="w-4 h-4 rounded-full bg-indigo-600 text-white text-[10px] flex items-center justify-center font-bold">
                {activeFilters.length}
              </span>
            )}
          </button>

          {filterMenuOpen && (
            <div className="absolute right-0 top-full mt-1.5 w-48 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl p-1.5 z-30 space-y-0.5">
              <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Quick Filters
              </div>
              {filters.map((f) => {
                const isActive = activeFilters.includes(f.id);
                return (
                  <button
                    key={f.id}
                    onClick={() => onToggleFilter && onToggleFilter(f.id)}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs transition ${
                      isActive
                        ? 'bg-indigo-600/20 text-indigo-300 font-semibold'
                        : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span>{f.label}</span>
                    {isActive && <span className="text-indigo-400 font-bold">✓</span>}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Group By Dropdown */}
      {groupByOptions.length > 0 && (
        <div className="relative">
          <button
            onClick={() => {
              setGroupByMenuOpen((v) => !v);
              setFilterMenuOpen(false);
            }}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition ${
              activeGroupBy
                ? 'bg-purple-600/20 border-purple-500/40 text-purple-300'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Group By</span>
            {activeGroupBy && <span className="w-2 h-2 rounded-full bg-purple-500" />}
          </button>

          {groupByMenuOpen && (
            <div className="absolute right-0 top-full mt-1.5 w-44 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl p-1.5 z-30 space-y-0.5">
              <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Group Records By
              </div>
              <button
                onClick={() => {
                  onSelectGroupBy && onSelectGroupBy('');
                  setGroupByMenuOpen(false);
                }}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition ${
                  !activeGroupBy ? 'bg-purple-600/20 text-purple-300 font-semibold' : 'text-slate-400 hover:bg-slate-800'
                }`}
              >
                None (Standard)
              </button>
              {groupByOptions.map((g) => (
                <button
                  key={g.id}
                  onClick={() => {
                    onSelectGroupBy && onSelectGroupBy(g.id);
                    setGroupByMenuOpen(false);
                  }}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition ${
                    activeGroupBy === g.id
                      ? 'bg-purple-600/20 text-purple-300 font-semibold'
                      : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  {g.label}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
