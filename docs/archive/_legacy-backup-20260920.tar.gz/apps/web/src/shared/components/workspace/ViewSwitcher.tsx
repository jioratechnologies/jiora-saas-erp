import React from 'react';
import { LayoutGrid, List, BarChart3, Network } from 'lucide-react';

export type ViewMode = 'kanban' | 'list' | 'analytics' | 'hierarchy';

interface ViewSwitcherProps {
  currentView: ViewMode;
  onViewChange: (view: ViewMode) => void;
  availableViews?: ViewMode[];
}

export function ViewSwitcher({
  currentView,
  onViewChange,
  availableViews = ['kanban', 'list', 'analytics'],
}: ViewSwitcherProps) {
  const VIEWS: { id: ViewMode; label: string; icon: any }[] = [
    { id: 'kanban', label: 'Kanban', icon: LayoutGrid },
    { id: 'list', label: 'List', icon: List },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'hierarchy', label: 'Hierarchy', icon: Network },
  ];

  const visibleViews = VIEWS.filter((v) => availableViews.includes(v.id));

  return (
    <div className="inline-flex items-center bg-slate-900 border border-slate-800 rounded-xl p-1 shadow-inner">
      {visibleViews.map((v) => {
        const Icon = v.icon;
        const active = currentView === v.id;
        return (
          <button
            key={v.id}
            onClick={() => onViewChange(v.id)}
            title={`${v.label} View`}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all duration-150 ${
              active
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Icon className="w-3.5 h-3.5" />
            <span className="hidden md:inline">{v.label}</span>
          </button>
        );
      })}
    </div>
  );
}
