import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users,
  Briefcase,
  UserCheck,
  Clock,
  Calendar,
  FileText,
  UserMinus,
  Landmark,
  HeartHandshake,
  ShieldCheck,
  CheckSquare,
  Plane,
  TrendingUp,
  Search,
  X,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import { useTenant } from '@/context/TenantBrandingContext';

interface AppItem {
  id: string;
  name: string;
  category: 'HRIS' | 'ERP' | 'GOVERNANCE';
  icon: any;
  color: string;
  path: string;
  description: string;
  badge?: string;
}

const APPS: AppItem[] = [
  // Core HRIS
  { id: 'employees', name: 'Employees Master', category: 'HRIS', icon: Users, color: 'from-blue-500 to-indigo-600', path: '/hris/employees', description: 'Directory, profiles, statutory numbers & bank details' },
  { id: 'recruitment', name: 'Recruitment & Offers', category: 'HRIS', icon: Briefcase, color: 'from-purple-500 to-indigo-600', path: '/hris/recruitment', description: 'Job openings, candidate Kanban & 2-ref checks', badge: 'BRD v2' },
  { id: 'onboarding', name: 'Onboarding & Induction', category: 'HRIS', icon: UserCheck, color: 'from-teal-500 to-emerald-600', path: '/hris/onboarding', description: 'Checklists across Standard, Intern & Contractual' },
  { id: 'attendance', name: 'Attendance & Biometrics', category: 'HRIS', icon: Clock, color: 'from-amber-500 to-orange-600', path: '/hris/attendance', description: 'Daily check-in, 10 AM late flags & WFH capping' },
  { id: 'leave', name: 'Time Off & Leaves', category: 'HRIS', icon: Calendar, color: 'from-rose-500 to-pink-600', path: '/hris/leave', description: '8 Statutory leave balances & multi-tier approvals' },
  { id: 'payroll', name: 'Payroll & Statutory', category: 'HRIS', icon: FileText, color: 'from-emerald-500 to-teal-700', path: '/hris/payroll', description: '12% EPF, Payment of Gratuity Act 1972 & payslips' },
  { id: 'performance', name: 'Performance & KRAs', category: 'HRIS', icon: TrendingUp, color: 'from-cyan-500 to-blue-600', path: '/hris/performance', description: 'SMART KRAs, appraisals & President bell curve', badge: 'BRD v2' },
  { id: 'travel', name: 'Travel & Expenses', category: 'HRIS', icon: Plane, color: 'from-sky-500 to-indigo-600', path: '/hris/travel', description: 'Tour approvals, city-tier per-diem & emergency advance', badge: 'BRD v2' },
  { id: 'exit', name: 'Exit Clearance & F&F', category: 'HRIS', icon: UserMinus, color: 'from-red-500 to-rose-700', path: '/hris/exit', description: '16-step clearance checklist & Full & Final settlement' },

  // Enterprise ERP
  { id: 'finance', name: 'Finance & Invoicing', category: 'ERP', icon: Landmark, color: 'from-amber-600 to-yellow-600', path: '/finance', description: 'Chart of accounts, vendor payables & donor invoices' },
  { id: 'crm', name: 'CRM & Donors', category: 'ERP', icon: HeartHandshake, color: 'from-pink-500 to-rose-600', path: '/crm', description: 'Grant pipeline Kanban, partner stages & donor contacts' },
  { id: 'ppm', name: 'Projects & Tasks (PPM)', category: 'ERP', icon: Briefcase, color: 'from-violet-500 to-purple-700', path: '/ppm', description: 'Programs, task Kanban boards & timesheets' },

  // Governance & Approvals
  { id: 'workflows', name: 'Workflows & Approvals', category: 'GOVERNANCE', icon: CheckSquare, color: 'from-indigo-500 to-blue-700', path: '/workflows', description: 'The 16 BRD approval matrices & audit trails' },
  { id: 'compliance', name: 'Statutory Legal Vault', category: 'GOVERNANCE', icon: ShieldCheck, color: 'from-emerald-600 to-teal-800', path: '/compliance', description: 'Live Indian Labour Law calculators & immutable audit logs' },
];

export function AppLauncherModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const navigate = useNavigate();
  const { tenant } = useTenant();
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'ALL' | 'HRIS' | 'ERP' | 'GOVERNANCE'>('ALL');

  const filteredApps = useMemo(() => {
    return APPS.filter((app) => {
      const matchesSearch =
        app.name.toLowerCase().includes(search.toLowerCase()) ||
        app.description.toLowerCase().includes(search.toLowerCase());
      const matchesCat = categoryFilter === 'ALL' || app.category === categoryFilter;
      return matchesSearch && matchesCat;
    });
  }, [search, categoryFilter]);

  if (!isOpen) return null;

  const handleLaunch = (path: string) => {
    navigate(path);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-10 bg-slate-950/80 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl max-h-[90vh] flex flex-col bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden">
        {/* Header with Search & Branding */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-6 border-b border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-xl shadow-lg shadow-indigo-600/30">
              🌸
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-wide uppercase">
                  {tenant?.name || 'Sachhi Saheli'} Apps
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-semibold border border-indigo-500/30">
                  Enterprise Suite
                </span>
              </div>
              <p className="text-xs text-slate-400">All enterprise modules & statutory tools in one place</p>
            </div>
          </div>

          {/* Search bar inside launcher */}
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              autoFocus
              placeholder="Search apps (e.g. recruitment, leave)..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-800/80 border border-slate-700/80 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition"
            />
          </div>

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 sm:static w-8 h-8 rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 flex items-center justify-center text-slate-400 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Category Pill Filters */}
        <div className="flex items-center gap-2 px-6 py-3 bg-slate-900/80 border-b border-slate-800 text-xs overflow-x-auto">
          <span className="text-slate-500 font-medium mr-2">Filter:</span>
          {(['ALL', 'HRIS', 'ERP', 'GOVERNANCE'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                categoryFilter === cat
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'bg-slate-800/60 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {cat === 'ALL' ? 'All Applications' : cat}
            </button>
          ))}
        </div>

        {/* Apps Grid */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredApps.map((app) => {
            const Icon = app.icon;
            return (
              <button
                key={app.id}
                onClick={() => handleLaunch(app.path)}
                className="group relative flex flex-col items-start p-4 rounded-2xl bg-slate-950/40 hover:bg-slate-800/70 border border-slate-800/80 hover:border-indigo-500/50 hover:shadow-xl hover:shadow-indigo-600/10 transition-all duration-200 text-left"
              >
                <div className="flex items-center justify-between w-full mb-3">
                  <div className={`w-11 h-11 rounded-2xl bg-gradient-to-tr ${app.color} flex items-center justify-center text-white shadow-md group-hover:scale-105 transition-transform`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  {app.badge && (
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                      {app.badge}
                    </span>
                  )}
                </div>
                <h3 className="text-sm font-semibold text-white group-hover:text-indigo-300 transition-colors">
                  {app.name}
                </h3>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {app.description}
                </p>
                <div className="mt-4 pt-3 border-t border-slate-800/60 w-full flex items-center justify-between text-[10px] text-slate-500 group-hover:text-indigo-400 transition-colors">
                  <span>Launch App</span>
                  <ExternalLink className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Tip: Press <kbd className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 font-mono text-[10px]">Cmd+K</kbd> anywhere for instant Omni-Search</span>
          </div>
          <button
            onClick={() => handleLaunch('/tenant-settings')}
            className="text-indigo-400 hover:text-indigo-300 font-medium"
          >
            Customize Organization Branding →
          </button>
        </div>
      </div>
    </div>
  );
}
