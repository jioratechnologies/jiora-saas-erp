import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/shared/utils/utils';

const badgeVariants = cva(
  'inline-flex items-center font-medium rounded-full border whitespace-nowrap transition-colors',
  {
    variants: {
      color: {
        indigo: '',
        emerald: '',
        rose: '',
        amber: '',
        sky: '',
        purple: '',
        slate: '',
      },
      variant: {
        solid: 'text-white border-transparent',
        soft: 'border-current',
        outline: 'bg-transparent border-current',
      },
      size: {
        xs: 'px-2 py-0.5 text-[10px] gap-1',
        sm: 'px-2.5 py-0.5 text-xs gap-1.5',
        md: 'px-3 py-1 text-xs gap-1.5',
      },
    },
    compoundVariants: [
      // Solid
      { color: 'indigo', variant: 'solid', className: 'bg-indigo-600 text-white' },
      { color: 'emerald', variant: 'solid', className: 'bg-emerald-600 text-white' },
      { color: 'rose', variant: 'solid', className: 'bg-rose-600 text-white' },
      { color: 'amber', variant: 'solid', className: 'bg-amber-600 text-white' },
      { color: 'sky', variant: 'solid', className: 'bg-sky-600 text-white' },
      { color: 'purple', variant: 'solid', className: 'bg-purple-600 text-white' },
      { color: 'slate', variant: 'solid', className: 'bg-slate-700 text-slate-200' },
      // Soft
      { color: 'indigo', variant: 'soft', className: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30' },
      { color: 'emerald', variant: 'soft', className: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' },
      { color: 'rose', variant: 'soft', className: 'bg-rose-500/15 text-rose-300 border-rose-500/30' },
      { color: 'amber', variant: 'soft', className: 'bg-amber-500/15 text-amber-300 border-amber-500/30' },
      { color: 'sky', variant: 'soft', className: 'bg-sky-500/15 text-sky-300 border-sky-500/30' },
      { color: 'purple', variant: 'soft', className: 'bg-purple-500/15 text-purple-300 border-purple-500/30' },
      { color: 'slate', variant: 'soft', className: 'bg-slate-800 text-slate-300 border-slate-700' },
      // Outline
      { color: 'indigo', variant: 'outline', className: 'text-indigo-400 border-indigo-500/50' },
      { color: 'emerald', variant: 'outline', className: 'text-emerald-400 border-emerald-500/50' },
      { color: 'rose', variant: 'outline', className: 'text-rose-400 border-rose-500/50' },
      { color: 'amber', variant: 'outline', className: 'text-amber-400 border-amber-500/50' },
      { color: 'sky', variant: 'outline', className: 'text-sky-400 border-sky-500/50' },
      { color: 'purple', variant: 'outline', className: 'text-purple-400 border-purple-500/50' },
      { color: 'slate', variant: 'outline', className: 'text-slate-400 border-slate-700' },
    ],
    defaultVariants: { color: 'slate', variant: 'soft', size: 'sm' },
  }
);

export interface BadgeProps
  extends Omit<React.HTMLAttributes<HTMLSpanElement>, 'color'>,
    VariantProps<typeof badgeVariants> {
  dot?: boolean;
}

export const Badge = React.forwardRef<HTMLSpanElement, BadgeProps>(
  ({ className, color, variant, size, dot, children, ...props }, ref) => (
    <span ref={ref} className={cn(badgeVariants({ color, variant, size }), className)} {...props}>
      {dot && <span className="inline-block w-1.5 h-1.5 rounded-full bg-current" aria-hidden />}
      {children}
    </span>
  )
);
Badge.displayName = 'Badge';
