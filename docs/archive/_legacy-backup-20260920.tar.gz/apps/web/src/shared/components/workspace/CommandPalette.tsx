import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Search,
  Users,
  Calendar,
  Clock,
  FileText,
  Briefcase,
  Plane,
  HeartHandshake,
  Landmark,
  ShieldCheck,
  CheckSquare,
  Sparkles,
  ArrowRight,
  Plus,
  RefreshCw,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useTenant } from '@/context/TenantBrandingContext';

interface CommandItem {
  id: string;
  title: string;
  category: 'NAVIGATION' | 'ACTION' | 'TENANT' | 'PERSONA';
  icon: any;
  action: () => void;
  shortcut?: string;
}

export function CommandPalette({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const navigate = useNavigate();
  const { personas, switchPersona } = useAuth();
  const { tenant, allTenants, switchTenant } = useTenant();
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);

  const commands: CommandItem[] = useMemo(() => {
    const list: CommandItem[] = [
      // Quick Navigation
      { id: 'nav_emp', title: 'Go to Employees Directory', category: 'NAVIGATION', icon: Users, action: () => navigate('/hris/employees') },
      { id: 'nav_rec', title: 'Go to Recruitment & Candidates Kanban', category: 'NAVIGATION', icon: Briefcase, action: () => navigate('/hris/recruitment') },
      { id: 'nav_onb', title: 'Go to Onboarding & Induction', category: 'NAVIGATION', icon: Users, action: () => navigate('/hris/onboarding') },
      { id: 'nav_att', title: 'Go to Attendance & Biometrics', category: 'NAVIGATION', icon: Clock, action: () => navigate('/hris/attendance') },
      { id: 'nav_leave', title: 'Go to Time Off & Leave Management', category: 'NAVIGATION', icon: Calendar, action: () => navigate('/hris/leave') },
      { id: 'nav_pay', title: 'Go to Payroll & Statutory EPF/Gratuity', category: 'NAVIGATION', icon: FileText, action: () => navigate('/hris/payroll') },
      { id: 'nav_travel', title: 'Go to Travel & Expense Claims', category: 'NAVIGATION', icon: Plane, action: () => navigate('/hris/travel') },
      { id: 'nav_perf', title: 'Go to Performance & Appraisals', category: 'NAVIGATION', icon: Sparkles, action: () => navigate('/hris/performance') },
      { id: 'nav_crm', title: 'Go to CRM & Donor Pipeline', category: 'NAVIGATION', icon: HeartHandshake, action: () => navigate('/crm') },
      { id: 'nav_ppm', title: 'Go to Projects & Task Kanban', category: 'NAVIGATION', icon: Briefcase, action: () => navigate('/ppm') },
      { id: 'nav_fin', title: 'Go to Finance, Invoicing & COA', category: 'NAVIGATION', icon: Landmark, action: () => navigate('/finance') },
      { id: 'nav_wf', title: 'Go to Approvals Inbox (16 Workflows)', category: 'NAVIGATION', icon: CheckSquare, action: () => navigate('/workflows') },
      { id: 'nav_comp', title: 'Go to Statutory Legal Vault & Audit Logs', category: 'NAVIGATION', icon: ShieldCheck, action: () => navigate('/compliance') },

      // Quick Actions
      { id: 'act_checkin', title: 'Quick Action: Clock In / Check-in for Today', category: 'ACTION', icon: Plus, action: () => navigate('/hris/attendance') },
      { id: 'act_leave', title: 'Quick Action: Apply for Leave (CL/SL/EL/Maternity)', category: 'ACTION', icon: Plus, action: () => navigate('/hris/leave') },
      { id: 'act_tour', title: 'Quick Action: Request Tour & Travel Advance', category: 'ACTION', icon: Plus, action: () => navigate('/hris/travel') },
      { id: 'act_claim', title: 'Quick Action: Submit Expense Claim', category: 'ACTION', icon: Plus, action: () => navigate('/hris/travel') },
      { id: 'act_adv', title: 'Quick Action: Emergency Salary Advance Request', category: 'ACTION', icon: Plus, action: () => navigate('/hris/travel') },
      { id: 'act_cand', title: 'Quick Action: Source New Candidate', category: 'ACTION', icon: Plus, action: () => navigate('/hris/recruitment') },
      { id: 'act_branding', title: 'Quick Action: Customize Whitelabel Branding', category: 'ACTION', icon: Sparkles, action: () => navigate('/tenant-settings') },
    ];

    // Tenant Switchers
    for (const t of allTenants) {
      list.push({
        id: `tenant_${t.id}`,
        title: `Switch Tenant: ${t.name} (${t.currency})`,
        category: 'TENANT',
        icon: RefreshCw,
        action: () => switchTenant(t.id),
      });
    }

    // Persona Switchers
    for (const p of personas) {
      list.push({
        id: `persona_${p.id}`,
        title: `Simulate Persona: ${p.name} (${p.role})`,
        category: 'PERSONA',
        icon: Users,
        action: () => switchPersona(p.id),
      });
    }

    return list;
  }, [navigate, allTenants, personas, switchTenant, switchPersona]);

  const filtered = useMemo(() => {
    if (!query.trim()) return commands;
    return commands.filter((c) => c.title.toLowerCase().includes(query.toLowerCase()));
  }, [commands, query]);

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((i) => (i + 1) % filtered.length);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((i) => (i - 1 + filtered.length) % filtered.length);
      } else if (e.key === 'Enter' && filtered[selectedIndex]) {
        e.preventDefault();
        filtered[selectedIndex].action();
        onClose();
      } else if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, filtered, selectedIndex, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Search Header */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-slate-800 bg-slate-950/70">
          <Search className="w-5 h-5 text-indigo-400 flex-shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type a command, app name, or search (e.g. leave, candidate, switch)..."
            className="w-full bg-transparent text-sm text-white placeholder-slate-500 focus:outline-none"
          />
          <kbd className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-[10px] font-mono text-slate-400">
            ESC
          </kbd>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto p-2 space-y-1">
          {filtered.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">
              No matching commands found for "{query}".
            </div>
          ) : (
            filtered.map((item, idx) => {
              const Icon = item.icon;
              const isSelected = idx === selectedIndex;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    item.action();
                    onClose();
                  }}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs transition ${
                    isSelected
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                      : 'text-slate-300 hover:bg-slate-800/80'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                        isSelected ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="font-medium text-left">{item.title}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] opacity-70">
                    <span className="uppercase tracking-wider">{item.category}</span>
                    <ArrowRight className="w-3 h-3" />
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* Bottom hints */}
        <div className="px-4 py-2.5 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between text-[11px] text-slate-500">
          <span>Active Tenant: <strong className="text-indigo-400">{tenant?.name}</strong></span>
          <div className="flex items-center gap-3">
            <span>↑↓ Navigate</span>
            <span>↵ Select</span>
            <span>ESC Close</span>
          </div>
        </div>
      </div>
    </div>
  );
}
