import { Check } from 'lucide-react';

export interface PipelineStage {
  id: string;
  label: string;
}

interface StatusPipelineRibbonProps {
  stages: PipelineStage[];
  currentStageId: string;
  onSelectStage?: (stageId: string) => void;
  readOnly?: boolean;
}

export function StatusPipelineRibbon({
  stages,
  currentStageId,
  onSelectStage,
  readOnly = false,
}: StatusPipelineRibbonProps) {
  const currentIndex = stages.findIndex((s) => s.id === currentStageId);

  return (
    <div className="flex items-center overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/90 p-1 shadow-inner text-xs">
      {stages.map((stage, idx) => {
        const isCurrent = stage.id === currentStageId;
        const isCompleted = currentIndex > idx;
        const isFuture = currentIndex < idx;

        return (
          <button
            key={stage.id}
            type="button"
            disabled={readOnly}
            onClick={() => !readOnly && onSelectStage && onSelectStage(stage.id)}
            className={`group relative flex items-center gap-2 px-3.5 py-1.5 rounded-lg font-semibold transition-all whitespace-nowrap ${
              isCurrent
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : isCompleted
                ? 'text-emerald-400 hover:text-emerald-300 hover:bg-slate-800/60'
                : 'text-slate-400 hover:text-slate-300 hover:bg-slate-800/40'
            }`}
          >
            {isCompleted ? (
              <Check className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <span
                className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold ${
                  isCurrent
                    ? 'bg-white text-indigo-700'
                    : 'bg-slate-800 text-slate-400 group-hover:bg-slate-700'
                }`}
              >
                {idx + 1}
              </span>
            )}
            <span>{stage.label}</span>
          </button>
        );
      })}
    </div>
  );
}
