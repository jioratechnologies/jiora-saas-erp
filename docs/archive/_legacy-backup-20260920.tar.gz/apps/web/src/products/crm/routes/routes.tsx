import { lazy } from 'react';
import type { RouteObject } from 'react-router-dom';
import { page } from '@/platform/routing/page';

const CrmPage = lazy(() => import('../pages/CrmPage'));

export const crmRoutes: RouteObject[] = [
  { path: 'crm', element: page('CRM & Donors', <CrmPage />) },
];
