import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { apiClient } from '@/api';
import {
  HeartHandshake,
  Building,
  User,
  DollarSign,
  Briefcase,
  Plus,
  ArrowRight,
  MessageSquare,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { Badge } from '@/shared/components/ui/Badge';
import { RecordChatter } from '@/shared/components/workspace/RecordChatter';

const STAGE_FLOW = ['LEAD', 'CONTACTED', 'PROPOSAL_SUBMITTED', 'PARTNERED'];

export default function CrmPage() {
  const { currentUser } = useAuth();
  const [pipeline, setPipeline] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedContact, setSelectedContact] = useState<any | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newContact, setNewContact] = useState({
    orgName: '',
    contactPerson: '',
    email: '',
    phone: '',
    category: 'CSR_DONOR',
    grantPotential: 2500000,
    focus: 'Menstrual health advocacy & schools',
  });

  useEffect(() => {
    fetchData();
  }, [currentUser]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const pRes = await apiClient.getCrmPipeline(currentUser);
      setPipeline(pRes.pipeline || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleAdvanceStage = async (contactId: string, currentStage: string) => {
    const currentIndex = STAGE_FLOW.indexOf(currentStage);
    if (currentIndex >= 0 && currentIndex < STAGE_FLOW.length - 1) {
      const nextStage = STAGE_FLOW[currentIndex + 1];
      try {
        await apiClient.updateCrmStage(contactId, nextStage, currentUser);
        await fetchData();
      } catch (err) {
        console.error('Failed to update stage:', err);
      }
    }
  };

  const handleCreateContact = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiClient.createCrmContact(newContact, currentUser);
      setShowAddModal(false);
      await fetchData();
    } catch (err) {
      console.error('Failed to create contact:', err);
    }
  };

  const getStageHeader = (stage: string) => {
    switch (stage) {
      case 'LEAD':
        return { label: 'Initial Leads', color: 'border-slate-700 bg-slate-900/60' };
      case 'CONTACTED':
        return { label: 'Contacted & Scoped', color: 'border-blue-500/40 bg-blue-950/20' };
      case 'PROPOSAL_SUBMITTED':
        return { label: 'Proposal Submitted', color: 'border-amber-500/40 bg-amber-950/20' };
      default:
        return { label: 'Partnered & Active', color: 'border-emerald-500/40 bg-emerald-950/20' };
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>CRM & Institutional Donor Pipeline</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              CRM Pipeline Kanban
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            De-duplicated contacts, CSR grant pipeline stages, and strategic partnership activity tracking
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-indigo-600/20 transition self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Add Stakeholder / Lead
        </button>
      </div>

      {/* Kanban Pipeline Columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {pipeline.map((col) => {
          const style = getStageHeader(col.stage);
          return (
            <div
              key={col.stage}
              className={`p-4 rounded-3xl glass-panel border ${style.color} space-y-3 flex flex-col min-h-[500px]`}
            >
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <div>
                  <h3 className="text-xs font-bold text-white">{style.label}</h3>
                  <span className="text-[10px] text-slate-400 font-mono">
                    ₹ {((col.totalGrantValue || 0) / 100000).toFixed(1)} Lakhs
                  </span>
                </div>
                <Badge color="slate" variant="soft" size="xs">
                  {col.count}
                </Badge>
              </div>

              <div className="space-y-3 flex-1">
                {col.contacts?.map((c: any) => (
                  <div
                    key={c.id}
                    onClick={() => setSelectedContact(c)}
                    className={`p-4 rounded-2xl border transition cursor-pointer ${
                      selectedContact?.id === c.id
                        ? 'bg-indigo-600/20 border-indigo-500'
                        : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="font-bold text-xs text-white">{c.orgName}</div>
                    <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-1">
                      <User className="w-3 h-3 text-slate-500" />
                      <span>{c.contactPerson}</span>
                    </div>
                    <div className="text-[10px] text-slate-400 line-clamp-2 mt-1">
                      Focus: <span className="text-slate-300">{c.focus}</span>
                    </div>
                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] mt-2">
                      <span className="text-slate-400 font-mono">
                        ₹ {((c.grantPotential || 0) / 100000).toFixed(1)}L
                      </span>

                      {col.stage !== 'PARTNERED' && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleAdvanceStage(c.id, col.stage);
                          }}
                          className="flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 hover:bg-indigo-600 text-indigo-300 hover:text-white text-[10px] font-semibold transition"
                          title="Advance to next pipeline stage"
                        >
                          <span>Move</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Contact Chatter Modal / Drawer */}
      {selectedContact && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-white">{selectedContact.orgName}</h3>
                <p className="text-xs text-slate-400">
                  {selectedContact.contactPerson} • Potential: ₹{((selectedContact.grantPotential || 0) / 100000).toFixed(1)} Lakhs
                </p>
              </div>
              <button
                onClick={() => setSelectedContact(null)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="text-xs text-slate-300 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
              <span className="font-semibold text-slate-400 block mb-0.5">Strategic Alignment:</span>
              {selectedContact.focus}
            </div>

            <RecordChatter
              recordType="contact"
              recordId={selectedContact.id}
              recordTitle={`CRM: ${selectedContact.orgName}`}
            />
          </div>
        </div>
      )}

      {/* Add Contact Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white">Add New Institutional Lead</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreateContact} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Organization / Foundation Name</label>
                <input
                  type="text"
                  value={newContact.orgName}
                  onChange={(e) => setNewContact({ ...newContact, orgName: e.target.value })}
                  placeholder="e.g. Tata Trusts / Gates Foundation"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Key Contact Person</label>
                <input
                  type="text"
                  value={newContact.contactPerson}
                  onChange={(e) => setNewContact({ ...newContact, contactPerson: e.target.value })}
                  placeholder="Name of CSR / Program Officer"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Grant Potential (₹)</label>
                <input
                  type="number"
                  value={newContact.grantPotential}
                  onChange={(e) => setNewContact({ ...newContact, grantPotential: parseInt(e.target.value) || 0 })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Focus & Thematic Alignment</label>
                <textarea
                  rows={2}
                  value={newContact.focus}
                  onChange={(e) => setNewContact({ ...newContact, focus: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg"
                >
                  Create Lead
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
