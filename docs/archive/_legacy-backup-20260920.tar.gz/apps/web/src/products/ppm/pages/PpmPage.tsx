import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { apiClient } from '@/api';
import {
  FolderKanban,
  Clock,
  CheckCircle2,
  TrendingUp,
  User,
  AlertCircle,
  Briefcase,
  Plus,
  ArrowRight,
  MessageSquare,
  CheckSquare,
} from 'lucide-react';
import { Badge } from '@/shared/components/ui/Badge';
import { RecordChatter } from '@/shared/components/workspace/RecordChatter';

const TASK_STAGES = ['TODO', 'IN_PROGRESS', 'REVIEW', 'DONE'];

export default function PpmPage() {
  const { currentUser } = useAuth();
  const [projects, setProjects] = useState<any[]>([]);
  const [tasks, setTasks] = useState<any[]>([]);
  const [timesheets, setTimesheets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'projects' | 'kanban' | 'timesheets'>('projects');
  const [selectedTask, setSelectedTask] = useState<any | null>(null);
  const [showNewTaskModal, setShowNewTaskModal] = useState(false);
  const [newTaskForm, setNewTaskForm] = useState({
    title: '',
    projectId: 'PRJ-2026-01',
    assigneeName: 'Priya Mehra',
    estimatedHours: 12,
    stage: 'TODO',
  });

  useEffect(() => {
    fetchData();
  }, [currentUser]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [pRes, tRes, tasksRes] = await Promise.all([
        apiClient.getPpmProjects(currentUser),
        apiClient.getPpmTimesheets(currentUser),
        apiClient.getPpmTasks(currentUser),
      ]);
      setProjects(pRes.data || []);
      setTimesheets(tRes.data || []);
      setTasks(tasksRes.data || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleAdvanceTask = async (taskId: string, currentStage: string) => {
    const idx = TASK_STAGES.indexOf(currentStage);
    if (idx >= 0 && idx < TASK_STAGES.length - 1) {
      const nextStage = TASK_STAGES[idx + 1];
      try {
        await apiClient.updatePpmTaskStage(taskId, nextStage, currentUser);
        await fetchData();
      } catch (err) {
        console.error('Failed to advance task stage:', err);
      }
    }
  };

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiClient.createPpmTask(newTaskForm, currentUser);
      setShowNewTaskModal(false);
      await fetchData();
    } catch (err) {
      console.error('Failed to create task:', err);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>Project & Portfolio Management (PPM)</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              PPM & Project Tasks
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Programs, task Kanban boards, milestone tracking, resource allocation, and staff timesheets
          </p>
        </div>

        <button
          onClick={() => setShowNewTaskModal(true)}
          className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-indigo-600/20 transition self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Create Task
        </button>
      </div>

      {/* View Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('projects')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition ${
            activeTab === 'projects' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          Active Programs ({projects.length})
        </button>
        <button
          onClick={() => setActiveTab('kanban')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition ${
            activeTab === 'kanban' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          Task Kanban ({tasks.length})
        </button>
        <button
          onClick={() => setActiveTab('timesheets')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition ${
            activeTab === 'timesheets' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          Weekly Timesheets ({timesheets.length})
        </button>
      </div>

      {/* Tab 1: Projects Grid */}
      {activeTab === 'projects' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {projects.map((prj) => (
            <div key={prj.id} className="p-5 rounded-3xl glass-card border border-slate-800 space-y-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-[10px] font-mono font-bold text-indigo-400">{prj.code}</span>
                  <h3 className="text-sm font-bold text-white mt-0.5">{prj.name}</h3>
                </div>
                <Badge color="emerald" variant="soft" size="xs">
                  {prj.status}
                </Badge>
              </div>

              <div className="space-y-1.5 text-xs text-slate-400">
                <div className="flex justify-between">
                  <span>Lead:</span>
                  <span className="font-semibold text-slate-200">{prj.manager}</span>
                </div>
                <div className="flex justify-between">
                  <span>Budget Allocated:</span>
                  <span className="font-mono text-white">₹ {(prj.budget / 100000).toFixed(1)} Lakhs</span>
                </div>
                <div className="flex justify-between">
                  <span>Spent to Date:</span>
                  <span className="font-mono text-indigo-300">₹ {(prj.spent / 100000).toFixed(1)} Lakhs</span>
                </div>
              </div>

              {/* Progress */}
              <div className="space-y-1 pt-1 border-t border-slate-800">
                <div className="flex justify-between text-[11px] text-slate-400">
                  <span>Milestone Completion</span>
                  <span className="font-bold text-white">{prj.progressPercent}%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-indigo-500"
                    style={{ width: `${prj.progressPercent}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 2: Task Kanban Board */}
      {activeTab === 'kanban' && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {TASK_STAGES.map((stage) => {
            const stageTasks = tasks.filter((t) => t.stage === stage);
            return (
              <div
                key={stage}
                className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 flex flex-col min-h-[500px]"
              >
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                    {stage.replace('_', ' ')}
                  </h4>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400">
                    {stageTasks.length}
                  </span>
                </div>

                <div className="space-y-2.5 flex-1">
                  {stageTasks.map((t) => (
                    <div
                      key={t.id}
                      onClick={() => setSelectedTask(t)}
                      className={`p-3.5 rounded-xl border transition cursor-pointer ${
                        selectedTask?.id === t.id
                          ? 'bg-indigo-600/20 border-indigo-500'
                          : 'bg-slate-950/80 border-slate-800/90 hover:border-slate-700'
                      }`}
                    >
                      <span className="text-[9px] font-mono text-indigo-400 font-bold block">{t.id}</span>
                      <h5 className="text-xs font-semibold text-white mt-1">{t.title}</h5>
                      <div className="flex items-center justify-between text-[10px] text-slate-400 mt-2.5 pt-2 border-t border-slate-800/80">
                        <span>{t.assigneeName}</span>
                        <span className="font-mono text-indigo-300">{t.estimatedHours}h</span>
                      </div>

                      {stage !== 'DONE' && (
                        <div className="mt-2 pt-1 flex justify-end">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAdvanceTask(t.id, t.stage);
                            }}
                            className="flex items-center gap-1 text-[10px] px-2 py-0.5 rounded bg-slate-800 hover:bg-indigo-600 text-indigo-300 hover:text-white font-semibold transition"
                          >
                            <span>Move</span>
                            <ArrowRight className="w-2.5 h-2.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Tab 3: Timesheets table */}
      {activeTab === 'timesheets' && (
        <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Weekly Project Timesheets (Staff Hours)
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left text-slate-300">
              <thead className="text-[11px] uppercase bg-slate-950/60 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-4">Employee</th>
                  <th className="py-2.5 px-4">Project</th>
                  <th className="py-2.5 px-4">Hours Logged</th>
                  <th className="py-2.5 px-4">Week Period</th>
                  <th className="py-2.5 px-4">Approval Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {timesheets.map((ts: any) => (
                  <tr key={ts.id} className="hover:bg-slate-800/30">
                    <td className="py-2.5 px-4 font-sans text-white font-semibold">{ts.employeeName}</td>
                    <td className="py-2.5 px-4 font-sans text-slate-300">{ts.projectName}</td>
                    <td className="py-2.5 px-4 text-indigo-300 font-bold">{ts.hours} hrs</td>
                    <td className="py-2.5 px-4 text-slate-400">{ts.weekPeriod}</td>
                    <td className="py-2.5 px-4 font-sans">
                      <Badge color={ts.status === 'APPROVED' ? 'emerald' : 'amber'} variant="soft" size="xs">
                        {ts.status}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Selected Task Chatter Modal */}
      {selectedTask && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between pb-3 border-b border-slate-800">
              <div>
                <span className="text-[10px] font-mono text-indigo-400 font-bold">{selectedTask.id}</span>
                <h3 className="text-base font-bold text-white">{selectedTask.title}</h3>
                <p className="text-xs text-slate-400">
                  Assignee: {selectedTask.assigneeName} • Stage: {selectedTask.stage}
                </p>
              </div>
              <button
                onClick={() => setSelectedTask(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <RecordChatter
              recordType="task"
              recordId={selectedTask.id}
              recordTitle={`Task: ${selectedTask.title}`}
            />
          </div>
        </div>
      )}

      {/* Create Task Modal */}
      {showNewTaskModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white">Create Project Task</h3>
              <button onClick={() => setShowNewTaskModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Task Title</label>
                <input
                  type="text"
                  value={newTaskForm.title}
                  onChange={(e) => setNewTaskForm({ ...newTaskForm, title: e.target.value })}
                  placeholder="e.g. Conduct district stakeholder audit"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Assignee</label>
                <input
                  type="text"
                  value={newTaskForm.assigneeName}
                  onChange={(e) => setNewTaskForm({ ...newTaskForm, assigneeName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Estimated Hours</label>
                <input
                  type="number"
                  value={newTaskForm.estimatedHours}
                  onChange={(e) => setNewTaskForm({ ...newTaskForm, estimatedHours: parseInt(e.target.value) || 0 })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewTaskModal(false)}
                  className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg"
                >
                  Create Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
