import { lazy } from 'react';
import type { RouteObject } from 'react-router-dom';
import { page } from '@/platform/routing/page';

const PpmPage = lazy(() => import('../pages/PpmPage'));

export const ppmRoutes: RouteObject[] = [
  { path: 'ppm', element: page('PPM & Projects', <PpmPage />) },
];
