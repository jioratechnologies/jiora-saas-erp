import { lazy } from 'react';
import type { RouteObject } from 'react-router-dom';
import { page } from '@/platform/routing/page';

const ApprovalsPage = lazy(() => import('../pages/ApprovalsPage'));

export const workflowsRoutes: RouteObject[] = [
  { path: 'workflows', element: page('Approvals & Workflows', <ApprovalsPage />) },
];
