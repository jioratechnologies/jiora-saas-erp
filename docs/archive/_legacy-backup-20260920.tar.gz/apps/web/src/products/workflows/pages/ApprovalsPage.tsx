import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useUiStore } from '@/platform/state/uiStore';
import { apiClient } from '@/api';
import { WorkflowInstance } from '@/types';
import {
  CheckCircle2,
  XCircle,
  Clock,
  ArrowRight,
  MessageSquare,
  User,
  Layers,
  Calendar,
  AlertCircle,
  Sparkles,
} from 'lucide-react';
import { Button } from '@/shared/components/ui/Button';
import { Badge } from '@/shared/components/ui/Badge';
import { EmptyState } from '@/shared/components/ui/EmptyState';

export default function ApprovalsPage() {
  const { currentUser } = useAuth();
  const addNotification = useUiStore((s) => s.addNotification);
  const refreshKey = useUiStore((s) => s.refreshKey);
  const [workflows, setWorkflows] = useState<WorkflowInstance[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTab, setSelectedTab] = useState<'MY_ACTION' | 'ALL'>('MY_ACTION');
  const [actionComments, setActionComments] = useState<Record<string, string>>({});
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  useEffect(() => {
    fetchWorkflows();
  }, [currentUser, refreshKey]);

  const fetchWorkflows = async () => {
    try {
      setLoading(true);
      const res = await apiClient.getWorkflows(currentUser);
      if (res.success) {
        setWorkflows(res.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (wfId: string) => {
    const comments = actionComments[wfId] || 'Approved through executive console.';
    try {
      const res = await apiClient.approveWorkflow(wfId, comments, currentUser);
      if (res.success) {
        const msg = `Workflow advanced to: ${res.data.currentStage}`;
        setActionSuccess(`Workflow approved successfully! ${msg}`);
        addNotification({
          type: 'success',
          title: 'Workflow Approved',
          message: msg,
        });
        setTimeout(() => setActionSuccess(null), 4000);
        fetchWorkflows();
      }
    } catch (e: any) {
      addNotification({
        type: 'error',
        title: 'Approval Failed',
        message: e?.message || 'Error executing approval action',
      });
    }
  };

  const handleReject = async (wfId: string) => {
    const comments = actionComments[wfId] || 'Rejected after review.';
    try {
      const res = await apiClient.rejectWorkflow(wfId, comments, currentUser);
      if (res.success) {
        setActionSuccess('Workflow rejected.');
        addNotification({
          type: 'warning',
          title: 'Workflow Rejected',
          message: 'The request has been marked as rejected.',
        });
        setTimeout(() => setActionSuccess(null), 4000);
        fetchWorkflows();
      }
    } catch (e: any) {
      addNotification({
        type: 'error',
        title: 'Rejection Failed',
        message: e?.message || 'Error rejecting workflow',
      });
    }
  };

  const isCurrentStageForMe = (wf: WorkflowInstance) => {
    const role = currentUser?.role;
    if (role === 'PRESIDENT' && wf.currentStage === 'PENDING_PRESIDENT') return true;
    if (role === 'HR' && wf.currentStage === 'PENDING_HR') return true;
    if (role === 'FINANCE' && wf.currentStage === 'PENDING_FINANCE') return true;
    if (role === 'MANAGER' && wf.currentStage === 'PENDING_MANAGER') return true;
    return false;
  };

  const filteredWorkflows = workflows.filter((wf) => {
    if (selectedTab === 'MY_ACTION') {
      return isCurrentStageForMe(wf);
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header & Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <span>Workflow & Multi-Level Approvals Hub</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              16 Workflows Engine
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Enforcing approval authority matrices per Sachhi Saheli BRD v2
          </p>
        </div>

        <div className="flex bg-slate-900 border border-slate-800 rounded-xl p-1 self-start">
          <button
            onClick={() => setSelectedTab('MY_ACTION')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
              selectedTab === 'MY_ACTION'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Awaiting My Action ({workflows.filter(isCurrentStageForMe).length})
          </button>
          <button
            onClick={() => setSelectedTab('ALL')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
              selectedTab === 'ALL'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            All Workflows ({workflows.length})
          </button>
        </div>
      </div>

      {actionSuccess && (
        <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/40 text-emerald-300 text-xs font-medium flex items-center gap-2 animate-fade-in-up">
          <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {loading ? (
        <div className="p-12 text-center text-xs text-slate-400">Loading active approval requests...</div>
      ) : filteredWorkflows.length === 0 ? (
        <EmptyState
          title={selectedTab === 'MY_ACTION' ? 'No Pending Approvals For Your Role' : 'No Workflows Recorded'}
          description={
            selectedTab === 'MY_ACTION'
              ? `You are currently logged in as ${currentUser?.name} (${currentUser?.role}). There are no requests awaiting your sign-off.`
              : 'All workflows have been settled or none created yet.'
          }
        />
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredWorkflows.map((wf) => {
            const isActionable = isCurrentStageForMe(wf);

            return (
              <div
                key={wf.id}
                className={`p-6 rounded-2xl glass-panel border transition-all ${
                  isActionable
                    ? 'border-amber-500/40 bg-slate-900/90 shadow-lg shadow-amber-500/5'
                    : 'border-slate-800/80 bg-slate-900/60'
                }`}
              >
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-4">
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge color="indigo" variant="soft" size="xs">
                        {wf.workflowType}
                      </Badge>
                      <h3 className="text-base font-bold text-white">{wf.title}</h3>
                      {isActionable && (
                        <Badge color="amber" variant="solid" size="xs">
                          Action Required
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-slate-300">Department: {wf.department}</p>

                    <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-1">
                      <span className="flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-slate-500" />
                        Initiated by <strong className="text-slate-200">{wf.requesterName}</strong> ({wf.requesterRole})
                      </span>
                      <span className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-slate-500" />
                        {new Date(wf.createdAt).toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {/* Stage pill */}
                  <div className="text-right shrink-0">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1">
                      Current Stage
                    </span>
                    <Badge
                      color={wf.currentStage === 'APPROVED' ? 'emerald' : wf.currentStage === 'REJECTED' ? 'rose' : 'amber'}
                      variant="soft"
                      size="sm"
                    >
                      {wf.currentStage}
                    </Badge>
                  </div>
                </div>

                {/* Workflow Payload Summary */}
                {wf.payload && (
                  <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-300 font-mono mb-4 grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {Object.entries(wf.payload).map(([key, val]) => (
                      <div key={key}>
                        <span className="text-[10px] text-slate-500 uppercase block">{key}</span>
                        <span className="text-slate-200 font-semibold">{String(val)}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Multi-step Approval History Tracker */}
                <div className="border-t border-slate-800/80 pt-4 mt-2">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-2.5 block flex items-center gap-1.5">
                    <Layers className="w-3 h-3" />
                    Approval Audit Trail ({wf.stages?.length || 0} Stages)
                  </span>

                  <div className="space-y-2">
                    {(wf.stages || []).map((stage, sIdx) => (
                      <div
                        key={sIdx}
                        className="flex flex-col sm:flex-row sm:items-center justify-between text-xs p-2.5 rounded-lg bg-slate-950/30 border border-slate-800/50 gap-2"
                      >
                        <div className="flex items-center gap-2">
                          {stage.decision === 'APPROVED' ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          ) : stage.decision === 'REJECTED' ? (
                            <XCircle className="w-4 h-4 text-rose-400" />
                          ) : (
                            <Clock className="w-4 h-4 text-amber-400" />
                          )}
                          <span className="font-semibold text-slate-200">
                            Stage {sIdx + 1}: {stage.approverRole} Sign-off
                          </span>
                          {stage.approverName && (
                            <span className="text-slate-400">by {stage.approverName}</span>
                          )}
                        </div>

                        <div className="flex items-center gap-3">
                          {stage.comments && (
                            <span className="text-slate-400 italic flex items-center gap-1 text-[11px]">
                              <MessageSquare className="w-3 h-3" />
                              "{stage.comments}"
                            </span>
                          )}
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded font-mono font-semibold ${
                              stage.decision === 'APPROVED'
                                ? 'bg-emerald-500/20 text-emerald-300'
                                : stage.decision === 'REJECTED'
                                ? 'bg-rose-500/20 text-rose-300'
                                : 'bg-amber-500/20 text-amber-300'
                            }`}
                          >
                            {stage.decision || 'PENDING'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Box if Waiting for current persona */}
                {isActionable && !['APPROVED', 'REJECTED', 'CANCELLED'].includes(wf.currentStage) && (
                  <div className="mt-5 p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 space-y-3">
                    <div className="flex items-center gap-2 text-amber-300 text-xs font-semibold">
                      <AlertCircle className="w-4 h-4" />
                      <span>Action Required: Sign off as {currentUser?.role}</span>
                    </div>

                    <input
                      type="text"
                      placeholder="Add sign-off comments or rejection reason..."
                      value={actionComments[wf.id] || ''}
                      onChange={(e) =>
                        setActionComments({ ...actionComments, [wf.id]: e.target.value })
                      }
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                    />

                    <div className="flex items-center justify-end gap-2.5">
                      <Button
                        intent="destructive"
                        size="sm"
                        onClick={() => handleReject(wf.id)}
                      >
                        <XCircle className="w-3.5 h-3.5 mr-1" />
                        Reject Request
                      </Button>
                      <Button
                        intent="emerald"
                        size="sm"
                        onClick={() => handleApprove(wf.id)}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                        Approve & Advance
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
