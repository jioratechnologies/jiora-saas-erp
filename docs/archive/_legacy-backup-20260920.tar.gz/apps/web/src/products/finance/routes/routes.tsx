import { lazy } from 'react';
import type { RouteObject } from 'react-router-dom';
import { page } from '@/platform/routing/page';

const FinancePage = lazy(() => import('../pages/FinancePage'));

export const financeRoutes: RouteObject[] = [
  { path: 'finance', element: page('Finance & Accounts', <FinancePage />) },
];
