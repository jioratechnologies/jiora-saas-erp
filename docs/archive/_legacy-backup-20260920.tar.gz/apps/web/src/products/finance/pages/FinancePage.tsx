import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { apiClient } from '@/api';
import {
  Landmark,
  ArrowUpRight,
  TrendingUp,
  FileText,
  Building2,
  DollarSign,
  Plus,
  CheckCircle2,
  Receipt,
  CreditCard,
} from 'lucide-react';
import { Badge } from '@/shared/components/ui/Badge';
import { RecordChatter } from '@/shared/components/workspace/RecordChatter';

export default function FinancePage() {
  const { currentUser } = useAuth();
  const [coaData, setCoaData] = useState<any>(null);
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedInvoice, setSelectedInvoice] = useState<any | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newInvForm, setNewInvForm] = useState({
    invoiceNumber: `INV-2026-${Math.floor(100 + Math.random() * 900)}`,
    party: 'Global Sanitation Partner',
    type: 'RECEIVABLE' as 'RECEIVABLE' | 'PAYABLE',
    amount: 150000,
    dueDate: '2026-04-15',
    description: 'Grant disbursement installment 2',
  });

  useEffect(() => {
    fetchData();
  }, [currentUser]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [cRes, iRes] = await Promise.all([
        apiClient.getFinanceCOA(currentUser),
        apiClient.getFinanceInvoices(currentUser),
      ]);
      setCoaData(cRes);
      setInvoices(iRes.data || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handlePayInvoice = async (invoiceId: string) => {
    try {
      await apiClient.payInvoice(invoiceId, currentUser);
      await fetchData();
    } catch (err) {
      console.error('Failed to pay invoice:', err);
    }
  };

  const handleCreateInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiClient.createInvoice(newInvForm, currentUser);
      setShowCreateModal(false);
      await fetchData();
    } catch (err) {
      console.error('Failed to create invoice:', err);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>Finance, General Ledger & Invoicing</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
              General Ledger & Invoicing
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Multi-level Chart of Accounts (COA), automated HRIS payroll postings, Accounts Payable & Donor Receivables
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-indigo-600/20 transition self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Create Invoice / Bill
        </button>
      </div>

      {/* Financial Health Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl glass-card border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400">Total Assets</span>
          <div className="text-xl font-bold text-white font-mono">
            ₹ {(coaData?.summary?.totalAssets ?? 4850000).toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-emerald-400">Bank & Cash Liquid</span>
        </div>
        <div className="p-5 rounded-2xl glass-card border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400">Total Liabilities</span>
          <div className="text-xl font-bold text-white font-mono">
            ₹ {(coaData?.summary?.totalLiabilities ?? 820000).toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-amber-400">PF & Tax Withholdings</span>
        </div>
        <div className="p-5 rounded-2xl glass-card border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400">Grant Revenue</span>
          <div className="text-xl font-bold text-white font-mono">
            ₹ {(coaData?.summary?.totalRevenue ?? 12500000).toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-indigo-400">Institutional Donors</span>
        </div>
        <div className="p-5 rounded-2xl glass-card border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400">Operating Surplus</span>
          <div className="text-xl font-bold text-emerald-400 font-mono">
            ₹ {(coaData?.summary?.operatingSurplus ?? 5100000).toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-emerald-400">Audited & Reconciled</span>
        </div>
      </div>

      {/* Two Column: Chart of Accounts & AP/AR */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart of Accounts */}
        <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Multi-Level Chart of Accounts (COA)
          </h3>
          <div className="divide-y divide-slate-800/60 max-h-96 overflow-y-auto pr-1 text-xs">
            {coaData?.accounts?.map((acc: any) => (
              <div key={acc.code} className="py-2.5 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-white flex items-center gap-2">
                    <span className="font-mono text-indigo-400 text-[11px]">{acc.code}</span>
                    <span>{acc.name}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">{acc.category}</span>
                </div>
                <div className="text-right font-mono">
                  <span className="text-slate-200 font-semibold">₹ {(acc.balance ?? 0).toLocaleString('en-IN')}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Invoices & Grants */}
        <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Accounts Payable & Donor Invoices ({invoices.length})
          </h3>
          <div className="divide-y divide-slate-800/60 max-h-96 overflow-y-auto pr-1 text-xs">
            {invoices.map((inv: any) => (
              <div
                key={inv.id}
                onClick={() => setSelectedInvoice(inv)}
                className="py-3 flex items-center justify-between hover:bg-slate-800/30 px-2 rounded-xl transition cursor-pointer"
              >
                <div>
                  <div className="font-semibold text-white flex items-center gap-2">
                    <span className="font-mono text-amber-400 text-[11px]">{inv.invoiceNumber}</span>
                    <span>{inv.party}</span>
                    <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase ${
                      inv.type === 'RECEIVABLE' ? 'bg-indigo-500/20 text-indigo-300' : 'bg-rose-500/20 text-rose-300'
                    }`}>
                      {inv.type}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-0.5">{inv.description} • Due: {inv.dueDate}</span>
                </div>
                <div className="flex items-center gap-3 text-right">
                  <div>
                    <span className="font-mono text-slate-200 block font-bold">
                      ₹ {(inv.amount ?? 0).toLocaleString('en-IN')}
                    </span>
                    <Badge color={inv.status === 'PAID' ? 'emerald' : 'amber'} variant="soft" size="xs">
                      {inv.status}
                    </Badge>
                  </div>

                  {inv.status !== 'PAID' && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handlePayInvoice(inv.id);
                      }}
                      className="px-2.5 py-1 rounded-lg bg-emerald-600/20 hover:bg-emerald-600 text-emerald-300 hover:text-white text-[10px] font-bold transition border border-emerald-500/30"
                    >
                      Pay Now
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Selected Invoice Chatter Modal */}
      {selectedInvoice && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between pb-3 border-b border-slate-800">
              <div>
                <span className="text-[10px] font-mono text-amber-400 font-bold">{selectedInvoice.invoiceNumber}</span>
                <h3 className="text-base font-bold text-white">{selectedInvoice.party}</h3>
                <p className="text-xs text-slate-400">
                  Amount: ₹{(selectedInvoice.amount || 0).toLocaleString('en-IN')} • Status: {selectedInvoice.status}
                </p>
              </div>
              <button
                onClick={() => setSelectedInvoice(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <RecordChatter
              recordType="invoice"
              recordId={selectedInvoice.id}
              recordTitle={`Invoice: ${selectedInvoice.invoiceNumber} (${selectedInvoice.party})`}
            />
          </div>
        </div>
      )}

      {/* Create Invoice Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white">Create New Financial Voucher / Invoice</h3>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreateInvoice} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Invoice Number</label>
                <input
                  type="text"
                  value={newInvForm.invoiceNumber}
                  onChange={(e) => setNewInvForm({ ...newInvForm, invoiceNumber: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white font-mono"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Party / Vendor / Donor</label>
                <input
                  type="text"
                  value={newInvForm.party}
                  onChange={(e) => setNewInvForm({ ...newInvForm, party: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Voucher Type</label>
                  <select
                    value={newInvForm.type}
                    onChange={(e) => setNewInvForm({ ...newInvForm, type: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  >
                    <option value="RECEIVABLE">Receivable (Grant Inflow)</option>
                    <option value="PAYABLE">Payable (Vendor Bill)</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Amount (₹)</label>
                  <input
                    type="number"
                    value={newInvForm.amount}
                    onChange={(e) => setNewInvForm({ ...newInvForm, amount: parseInt(e.target.value) || 0 })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Due Date</label>
                <input
                  type="date"
                  value={newInvForm.dueDate}
                  onChange={(e) => setNewInvForm({ ...newInvForm, dueDate: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Description / Project Allocation</label>
                <input
                  type="text"
                  value={newInvForm.description}
                  onChange={(e) => setNewInvForm({ ...newInvForm, description: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg"
                >
                  Create Voucher
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
