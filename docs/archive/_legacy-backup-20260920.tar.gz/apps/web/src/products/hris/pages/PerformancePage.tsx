import React, { useState, useEffect } from 'react';
import {
  Award,
  TrendingUp,
  UserCheck,
  CheckCircle2,
  Clock,
  Sparkles,
  ChevronRight,
  BarChart3,
  ShieldCheck,
  Target,
  MessageSquare,
  HelpCircle,
} from 'lucide-react';
import { apiClient } from '@/api';
import { useAuth } from '@/context/AuthContext';
import { RecordChatter } from '@/shared/components/workspace/RecordChatter';
import { StatusPipelineRibbon } from '@/shared/components/workspace/StatusPipelineRibbon';

interface KraItem {
  id: string;
  title: string;
  weight: number;
  target: string;
  selfScore?: number;
  managerScore?: number;
}

interface AppraisalRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  department: string;
  designation: string;
  cycleYear: string;
  stage: 'SELF_REVIEW' | 'MANAGER_REVIEW' | 'PRESIDENT_CALIBRATION' | 'COMPLETED';
  kras: KraItem[];
  selfRating?: number;
  selfComments?: string;
  managerRating?: number;
  managerComments?: string;
  presidentRating?: number;
  presidentComments?: string;
  finalScore?: number;
}

const PERFORMANCE_STAGES = [
  { id: 'SELF_REVIEW', label: '1. Self Review' },
  { id: 'MANAGER_REVIEW', label: '2. Manager Review' },
  { id: 'PRESIDENT_CALIBRATION', label: '3. President Calibration' },
  { id: 'COMPLETED', label: '4. Completed' },
];

export default function PerformancePage() {
  const { currentUser } = useAuth();
  const [appraisals, setAppraisals] = useState<AppraisalRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAppraisal, setSelectedAppraisal] = useState<AppraisalRecord | null>(null);
  const [activeTab, setActiveTab] = useState<'kras' | 'chatter'>('kras');

  // Review Form States
  const [reviewRating, setReviewRating] = useState<number>(4);
  const [reviewComments, setReviewComments] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  useEffect(() => {
    loadAppraisals();
  }, [currentUser]);

  const loadAppraisals = async () => {
    try {
      setLoading(true);
      const res = await apiClient.getAppraisals(currentUser);
      if (res && res.success) {
        setAppraisals(res.data || []);
        if (res.data?.length > 0 && !selectedAppraisal) {
          setSelectedAppraisal(res.data[0]);
        }
      }
    } catch (err) {
      console.error('Failed to load appraisals:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectAppraisal = (item: AppraisalRecord) => {
    setSelectedAppraisal(item);
    setReviewComments('');
    setReviewRating(4);
  };

  const handleSubmitSelfReview = async () => {
    if (!selectedAppraisal) return;
    try {
      setSubmitting(true);
      await apiClient.submitSelfReview(selectedAppraisal.id, reviewRating, reviewComments, currentUser);
      setNotification({ type: 'success', message: 'Self-review submitted successfully!' });
      await loadAppraisals();
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message || 'Submission failed' });
    } finally {
      setSubmitting(false);
    }
  };

  const handleSubmitManagerReview = async () => {
    if (!selectedAppraisal) return;
    try {
      setSubmitting(true);
      await apiClient.submitManagerReview(selectedAppraisal.id, reviewRating, reviewComments, currentUser);
      setNotification({ type: 'success', message: 'Manager appraisal submitted successfully!' });
      await loadAppraisals();
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message || 'Submission failed' });
    } finally {
      setSubmitting(false);
    }
  };

  const handleSubmitPresidentCalibration = async () => {
    if (!selectedAppraisal) return;
    try {
      setSubmitting(true);
      await apiClient.submitPresidentCalibration(selectedAppraisal.id, reviewRating, reviewComments, currentUser);
      setNotification({ type: 'success', message: 'President calibration confirmed and score locked!' });
      await loadAppraisals();
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message || 'Submission failed' });
    } finally {
      setSubmitting(false);
    }
  };

  // Bell Curve Simulation for Calibrations
  const totalCalibrated = appraisals.filter((a) => a.presidentRating || a.finalScore).length;
  const topPerformers = appraisals.filter((a) => (a.presidentRating || a.finalScore || 0) >= 4.5).length;
  const solidPerformers = appraisals.filter(
    (a) => (a.presidentRating || a.finalScore || 0) >= 3.0 && (a.presidentRating || a.finalScore || 0) < 4.5
  ).length;
  const developmentNeeded = appraisals.filter((a) => (a.presidentRating || a.finalScore || 0) < 3.0 && (a.presidentRating || a.finalScore || 0) > 0).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900/60 p-6 rounded-2xl border border-slate-800">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white tracking-tight">Performance & SMART KRAs</h1>
              <p className="text-xs text-slate-400">
                Annual review cycle, multi-tier appraisal, and President bell-curve calibration
              </p>
            </div>
          </div>
        </div>

        {/* Global Cycle Metrics */}
        <div className="flex items-center gap-3 bg-slate-950/70 px-4 py-2.5 rounded-xl border border-slate-800 text-xs">
          <div className="text-center">
            <span className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold block">Cycle</span>
            <span className="text-indigo-400 font-bold">2026-Q1</span>
          </div>
          <div className="w-px h-6 bg-slate-800" />
          <div className="text-center">
            <span className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold block">Total Appraisals</span>
            <span className="text-white font-bold">{appraisals.length}</span>
          </div>
          <div className="w-px h-6 bg-slate-800" />
          <div className="text-center">
            <span className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold block">Calibrated</span>
            <span className="text-emerald-400 font-bold">{totalCalibrated}</span>
          </div>
        </div>
      </div>

      {/* Bell Curve Calibration Overview */}
      <div className="bg-slate-900/40 p-5 rounded-2xl border border-slate-800/80">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-purple-400" />
            President Bell Curve Calibration (Target: 20% Top / 70% Core / 10% Needs Development)
          </h3>
          <span className="text-[11px] text-slate-400">Statutory HR Policy 2026</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-amber-400 font-semibold">Exceeds Expectations (≥ 4.5)</span>
              <p className="text-lg font-bold text-white">{topPerformers} <span className="text-xs text-slate-500 font-normal">({totalCalibrated ? Math.round((topPerformers / totalCalibrated) * 100) : 0}%)</span></p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400">
              ⭐
            </div>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-indigo-400 font-semibold">Meets Expectations (3.0 - 4.4)</span>
              <p className="text-lg font-bold text-white">{solidPerformers} <span className="text-xs text-slate-500 font-normal">({totalCalibrated ? Math.round((solidPerformers / totalCalibrated) * 100) : 0}%)</span></p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400">
              🎯
            </div>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-rose-400 font-semibold">Needs Support (&lt; 3.0)</span>
              <p className="text-lg font-bold text-white">{developmentNeeded} <span className="text-xs text-slate-500 font-normal">({totalCalibrated ? Math.round((developmentNeeded / totalCalibrated) * 100) : 0}%)</span></p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-400">
              📈
            </div>
          </div>
        </div>
      </div>

      {notification && (
        <div
          className={`p-3 rounded-xl border text-xs flex items-center justify-between ${
            notification.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
          }`}
        >
          <span>{notification.message}</span>
          <button onClick={() => setNotification(null)} className="text-slate-400 hover:text-white">
            ✕
          </button>
        </div>
      )}

      {/* Master Detail Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Appraisal Cards List */}
        <div className="lg:col-span-4 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Appraisal Rosters ({appraisals.length})
            </h2>
          </div>

          <div className="space-y-2 max-h-[700px] overflow-y-auto pr-1">
            {appraisals.map((item) => {
              const isSelected = selectedAppraisal?.id === item.id;
              return (
                <div
                  key={item.id}
                  onClick={() => handleSelectAppraisal(item)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-indigo-600/15 border-indigo-500/50 shadow-md shadow-indigo-600/10'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="text-sm font-semibold text-white">{item.employeeName}</h4>
                      <p className="text-xs text-slate-400">{item.designation} • {item.department}</p>
                    </div>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                        item.stage === 'COMPLETED'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : item.stage === 'PRESIDENT_CALIBRATION'
                          ? 'bg-purple-500/20 text-purple-300'
                          : item.stage === 'MANAGER_REVIEW'
                          ? 'bg-amber-500/20 text-amber-300'
                          : 'bg-blue-500/20 text-blue-300'
                      }`}
                    >
                      {item.stage.replace('_', ' ')}
                    </span>
                  </div>

                  <div className="mt-3 flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800/80">
                    <span className="flex items-center gap-1">
                      <Target className="w-3.5 h-3.5 text-indigo-400" />
                      {item.kras?.length || 0} SMART KRAs
                    </span>
                    <span className="font-semibold text-slate-300">
                      Score: {item.finalScore ? `${item.finalScore}/5.0` : 'Pending'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Detailed Inspection & Actions */}
        <div className="lg:col-span-8">
          {selectedAppraisal ? (
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-6">
              {/* Top Banner with Pipeline Ribbon */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div>
                  <h3 className="text-lg font-bold text-white">{selectedAppraisal.employeeName}</h3>
                  <p className="text-xs text-slate-400">
                    {selectedAppraisal.designation} ({selectedAppraisal.department}) • Cycle {selectedAppraisal.cycleYear}
                  </p>
                </div>

                <StatusPipelineRibbon
                  stages={PERFORMANCE_STAGES}
                  currentStageId={selectedAppraisal.stage}
                />
              </div>

              {/* Tabs */}
              <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
                <button
                  onClick={() => setActiveTab('kras')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                    activeTab === 'kras' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  SMART KRAs & Reviews
                </button>
                <button
                  onClick={() => setActiveTab('chatter')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
                    activeTab === 'chatter' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  Appraisal Chatter
                </button>
              </div>

              {activeTab === 'kras' ? (
                <div className="space-y-6">
                  {/* SMART KRAs Table */}
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
                      <Target className="w-4 h-4 text-indigo-400" />
                      Key Result Areas (Weighted 100%)
                    </h4>
                    <div className="space-y-2">
                      {selectedAppraisal.kras?.map((kra, idx) => (
                        <div key={kra.id || idx} className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-semibold text-white">{kra.title}</span>
                            <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300">
                              Weight: {kra.weight}%
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400">Target: {kra.target}</p>
                          {(kra.selfScore || kra.managerScore) && (
                            <div className="mt-2 flex items-center gap-4 text-[10px] text-slate-400">
                              {kra.selfScore && <span>Self Rating: <strong className="text-slate-200">{kra.selfScore}/5</strong></span>}
                              {kra.managerScore && <span>Mgr Rating: <strong className="text-slate-200">{kra.managerScore}/5</strong></span>}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Previous Reviews Audit */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div className="bg-slate-950/40 p-3.5 rounded-xl border border-slate-800">
                      <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 block mb-1">
                        Self Review
                      </span>
                      <p className="text-base font-bold text-indigo-400">
                        {selectedAppraisal.selfRating ? `${selectedAppraisal.selfRating} / 5.0` : 'Not submitted'}
                      </p>
                      <p className="text-[11px] text-slate-400 mt-1 italic line-clamp-2">
                        "{selectedAppraisal.selfComments || 'No comments'}"
                      </p>
                    </div>

                    <div className="bg-slate-950/40 p-3.5 rounded-xl border border-slate-800">
                      <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 block mb-1">
                        Manager Review
                      </span>
                      <p className="text-base font-bold text-amber-400">
                        {selectedAppraisal.managerRating ? `${selectedAppraisal.managerRating} / 5.0` : 'Pending'}
                      </p>
                      <p className="text-[11px] text-slate-400 mt-1 italic line-clamp-2">
                        "{selectedAppraisal.managerComments || 'No comments'}"
                      </p>
                    </div>

                    <div className="bg-slate-950/40 p-3.5 rounded-xl border border-slate-800">
                      <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 block mb-1">
                        President Calibration
                      </span>
                      <p className="text-base font-bold text-purple-400">
                        {selectedAppraisal.presidentRating ? `${selectedAppraisal.presidentRating} / 5.0` : 'Pending'}
                      </p>
                      <p className="text-[11px] text-slate-400 mt-1 italic line-clamp-2">
                        "{selectedAppraisal.presidentComments || 'No comments'}"
                      </p>
                    </div>
                  </div>

                  {/* Dynamic Action Form based on Stage & Role */}
                  <div className="bg-slate-950/80 p-5 rounded-xl border border-slate-800 space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-200">
                        Submit Evaluation ({selectedAppraisal.stage.replace('_', ' ')})
                      </h4>
                      <span className="text-[11px] text-indigo-400 font-medium">
                        Simulating as {currentUser?.role}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-xs text-slate-400 font-medium block mb-1">
                          Rating (1.0 to 5.0)
                        </label>
                        <select
                          value={reviewRating}
                          onChange={(e) => setReviewRating(parseFloat(e.target.value))}
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                        >
                          <option value={5.0}>5.0 - Role Model / Exceeds All Expectations</option>
                          <option value={4.5}>4.5 - Outstanding Performer</option>
                          <option value={4.0}>4.0 - Consistently Meets Expectations</option>
                          <option value={3.5}>3.5 - Solid Contributor</option>
                          <option value={3.0}>3.0 - Meets Minimum Standards</option>
                          <option value={2.0}>2.0 - Improvement Needed</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-xs text-slate-400 font-medium block mb-1">
                          Review Feedback / Observations
                        </label>
                        <input
                          type="text"
                          value={reviewComments}
                          onChange={(e) => setReviewComments(e.target.value)}
                          placeholder="State key deliverables, strengths, and areas of growth..."
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-end gap-3 pt-2">
                      {selectedAppraisal.stage === 'SELF_REVIEW' && (
                        <button
                          onClick={handleSubmitSelfReview}
                          disabled={submitting}
                          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg transition"
                        >
                          {submitting ? 'Submitting...' : 'Submit Self Appraisal'}
                        </button>
                      )}

                      {selectedAppraisal.stage === 'MANAGER_REVIEW' && (
                        <button
                          onClick={handleSubmitManagerReview}
                          disabled={submitting}
                          className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold rounded-lg transition"
                        >
                          {submitting ? 'Submitting...' : 'Submit Manager Rating & Forward to President'}
                        </button>
                      )}

                      {selectedAppraisal.stage === 'PRESIDENT_CALIBRATION' && (
                        <button
                          onClick={handleSubmitPresidentCalibration}
                          disabled={submitting}
                          className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold rounded-lg transition flex items-center gap-2"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          {submitting ? 'Calibrating...' : 'Confirm President Calibration & Lock Score'}
                        </button>
                      )}

                      {selectedAppraisal.stage === 'COMPLETED' && (
                        <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                          <CheckCircle2 className="w-4 h-4" /> Final Appraisal Locked
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <RecordChatter
                  recordType="appraisal"
                  recordId={selectedAppraisal.id}
                  recordTitle={`Appraisal: ${selectedAppraisal.employeeName} (${selectedAppraisal.cycleYear})`}
                />
              )}
            </div>
          ) : (
            <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-12 text-center text-slate-500 text-xs">
              Select an appraisal record to review KRAs, ratings, and discussion history
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
