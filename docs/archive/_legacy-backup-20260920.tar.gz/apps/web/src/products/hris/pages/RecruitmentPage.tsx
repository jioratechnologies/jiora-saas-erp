import { useState, useEffect } from 'react';
import {
  Briefcase,
  Plus,
  UserCheck,
  Award,
  Calendar,
  AlertTriangle,
  FileCheck,
  ChevronRight,
  Send,
  MessageSquare,
  Sparkles,
} from 'lucide-react';
import { apiClient } from '@/api';
import { useAuth } from '@/context/AuthContext';
import { ViewSwitcher, ViewMode } from '@/shared/components/workspace/ViewSwitcher';
import { RecordSearchBar } from '@/shared/components/workspace/RecordSearchBar';
import { RecordChatter } from '@/shared/components/workspace/RecordChatter';
import { Badge } from '@/shared/components/ui/Badge';
import { Button } from '@/shared/components/ui/Button';

export default function RecruitmentPage() {
  const { currentUser } = useAuth();
  const [viewMode, setViewMode] = useState<ViewMode>('kanban');
  const [search, setSearch] = useState('');
  const [kanbanData, setKanbanData] = useState<any[]>([]);
  const [allCandidates, setAllCandidates] = useState<any[]>([]);
  const [requisitions, setRequisitions] = useState<any[]>([]);
  const [selectedCandidate, setSelectedCandidate] = useState<any | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showRefModal, setShowRefModal] = useState(false);
  const [showOfferModal, setShowOfferModal] = useState(false);

  // Form states
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newRole, setNewRole] = useState('');

  const [refereeName, setRefereeName] = useState('');
  const [refereeDesignation, setRefereeDesignation] = useState('');
  const [refereeFeedback, setRefereeFeedback] = useState('');

  const [offeredCtc, setOfferedCtc] = useState(750000);
  const [joiningDate, setJoiningDate] = useState('2026-10-15');

  const [errorMessage, setErrorMessage] = useState('');

  const loadData = async () => {
    try {
      const [candRes, reqRes] = await Promise.all([
        apiClient.getCandidates(currentUser),
        apiClient.getRequisitions(currentUser),
      ]);
      if (candRes && candRes.success) {
        setKanbanData(candRes.kanban || []);
        setAllCandidates(candRes.data || []);
        if (!selectedCandidate && candRes.data && candRes.data.length > 0) {
          setSelectedCandidate(candRes.data[0]);
        }
      }
      if (reqRes && reqRes.success) {
        setRequisitions(reqRes.data || []);
      }
    } catch (e) {
      console.error('Failed to load recruitment data:', e);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentUser]);

  const handleStageMove = async (candidateId: string, newStage: string) => {
    setErrorMessage('');
    try {
      const res = await apiClient.updateCandidateStage(candidateId, newStage, currentUser);
      if (res && res.success) {
        await loadData();
        if (selectedCandidate?.id === candidateId) {
          setSelectedCandidate(res.data);
        }
      } else if (res && res.error) {
        setErrorMessage(res.error.message || 'Failed to update candidate stage');
      }
    } catch (e: any) {
      setErrorMessage(e.message || 'Error advancing candidate stage');
    }
  };

  const handleAddCandidate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await apiClient.createCandidate(
        {
          name: newName,
          email: newEmail,
          phone: newPhone,
          appliedRole: newRole,
        },
        currentUser
      );
      if (res && res.success) {
        setShowAddModal(false);
        setNewName('');
        setNewEmail('');
        setNewPhone('');
        setNewRole('');
        await loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddReference = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCandidate) return;
    try {
      const res = await apiClient.completeReferenceCheck(
        selectedCandidate.id,
        {
          referee: refereeName,
          designation: refereeDesignation,
          feedback: refereeFeedback,
        },
        currentUser
      );
      if (res && res.success) {
        setShowRefModal(false);
        setRefereeName('');
        setRefereeDesignation('');
        setRefereeFeedback('');
        await loadData();
        setSelectedCandidate(res.data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleIssueOffer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCandidate) return;
    setErrorMessage('');
    try {
      const res = await apiClient.generateOffer(
        selectedCandidate.id,
        { offeredCtc, joiningDate },
        currentUser
      );
      if (res && res.success) {
        setShowOfferModal(false);
        await loadData();
        setSelectedCandidate(res.data);
      } else if (res && res.error) {
        setErrorMessage(res.error.message);
      }
    } catch (e: any) {
      setErrorMessage(e.message);
    }
  };

  const STAGE_LABELS: Record<string, string> = {
    SOURCED: 'Sourced',
    SCREENING: 'Initial Screening',
    INTERVIEW: 'Technical / Panel Interview',
    REFERENCE_CHECK: 'Reference Checks (2 Req.)',
    OFFER_SENT: 'Offer Sent',
    HIRED: 'Hired & Ready for Onboarding',
  };

  const STAGE_COLORS: Record<string, string> = {
    SOURCED: 'bg-slate-800 text-slate-300 border-slate-700',
    SCREENING: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    INTERVIEW: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
    REFERENCE_CHECK: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    OFFER_SENT: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    HIRED: 'bg-teal-500/10 text-teal-400 border-teal-500/30',
  };

  return (
    <div className="space-y-6">
      {/* Header Toolbar */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-bold text-white tracking-tight">Recruitment & Candidate Pipeline</h1>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 font-semibold">
              BRD Workflow #1 & #2
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Stage-based Kanban pipeline with statutory 2-reference check validation
          </p>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <ViewSwitcher currentView={viewMode} onViewChange={setViewMode} availableViews={['kanban', 'list']} />
          <Button intent="primary" size="sm" onClick={() => setShowAddModal(true)} className="flex items-center gap-1.5">
            <Plus className="w-3.5 h-3.5" />
            <span>Add Candidate</span>
          </Button>
        </div>
      </div>

      {/* Error Banner if BRD compliance check triggers */}
      {errorMessage && (
        <div className="flex items-center gap-3 p-3 rounded-xl bg-rose-500/10 border border-rose-500/40 text-rose-300 text-xs">
          <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Top Search & Filter Bar */}
      <RecordSearchBar
        searchQuery={search}
        onSearchChange={setSearch}
        placeholder="Search candidates by name, applied role, or referee..."
      />

      {/* Requisitions Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {requisitions.map((req) => (
          <div key={req.id} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-white">{req.jobTitle}</span>
                <Badge color={req.status === 'APPROVED' ? 'emerald' : 'amber'} size="xs">
                  {req.status}
                </Badge>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                {req.department} • Budget: {req.budgetBandAnnual} • Exp: {req.experienceRequired}
              </p>
            </div>
            <div className="text-right">
              <span className="text-lg font-black text-indigo-400">{req.openPositions}</span>
              <p className="text-[10px] text-slate-500 uppercase font-semibold">Positions</p>
            </div>
          </div>
        ))}
      </div>

      {/* Main Content Area (Kanban vs List + Right Chatter) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Pipeline Board / List View */}
        <div className="lg:col-span-2 space-y-4">
          {viewMode === 'kanban' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 overflow-x-auto pb-4">
              {kanbanData.map((col) => (
                <div key={col.stage} className="flex flex-col bg-slate-900/70 border border-slate-800/90 rounded-2xl p-3 min-w-[240px]">
                  {/* Stage Header */}
                  <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
                    <span className="text-xs font-bold text-slate-200">
                      {STAGE_LABELS[col.stage] || col.stage}
                    </span>
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400">
                      {col.count}
                    </span>
                  </div>

                  {/* Cards */}
                  <div className="space-y-3 flex-1">
                    {col.candidates.map((cand: any) => {
                      const isSelected = selectedCandidate?.id === cand.id;
                      const verifiedRefs = (cand.referenceChecks || []).filter((r: any) => r.verified).length;

                      return (
                        <div
                          key={cand.id}
                          onClick={() => setSelectedCandidate(cand)}
                          className={`p-3.5 rounded-xl border cursor-pointer transition-all duration-150 ${
                            isSelected
                              ? 'bg-indigo-600/15 border-indigo-500 shadow-md shadow-indigo-600/10'
                              : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-start justify-between">
                            <h4 className="text-xs font-bold text-white">{cand.name}</h4>
                            {cand.interviewScore && (
                              <span className="text-[10px] font-bold text-amber-400">
                                ★ {cand.interviewScore}
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-400 mt-1">{cand.appliedRole}</p>

                          {/* Reference Checks Status Pill */}
                          <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px]">
                            <span className="text-slate-500">Refs:</span>
                            <span className={`font-semibold ${verifiedRefs >= 2 ? 'text-emerald-400' : 'text-amber-400'}`}>
                              {verifiedRefs}/2 Verified {verifiedRefs >= 2 ? '✓' : ''}
                            </span>
                          </div>

                          {/* Action Advance Ribbon */}
                          <div className="mt-3 flex items-center gap-1.5">
                            {col.stage === 'SOURCED' && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleStageMove(cand.id, 'SCREENING');
                                }}
                                className="w-full text-center py-1 rounded bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 text-[10px] font-semibold border border-blue-500/30"
                              >
                                Move to Screening →
                              </button>
                            )}
                            {col.stage === 'SCREENING' && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleStageMove(cand.id, 'INTERVIEW');
                                }}
                                className="w-full text-center py-1 rounded bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 text-[10px] font-semibold border border-purple-500/30"
                              >
                                Schedule Interview →
                              </button>
                            )}
                            {col.stage === 'INTERVIEW' && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleStageMove(cand.id, 'REFERENCE_CHECK');
                                }}
                                className="w-full text-center py-1 rounded bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 text-[10px] font-semibold border border-amber-500/30"
                              >
                                Reference Check →
                              </button>
                            )}
                            {col.stage === 'REFERENCE_CHECK' && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedCandidate(cand);
                                  setShowOfferModal(true);
                                }}
                                className="w-full text-center py-1 rounded bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 text-[10px] font-semibold border border-emerald-500/30"
                              >
                                Issue Offer Letter →
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            /* List View */
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 uppercase tracking-wider text-[10px]">
                    <th className="p-3">Candidate</th>
                    <th className="p-3">Applied Role</th>
                    <th className="p-3">Stage</th>
                    <th className="p-3">Ref Checks</th>
                    <th className="p-3">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {allCandidates.map((cand) => (
                    <tr
                      key={cand.id}
                      onClick={() => setSelectedCandidate(cand)}
                      className={`hover:bg-slate-800/50 cursor-pointer ${
                        selectedCandidate?.id === cand.id ? 'bg-indigo-600/10' : ''
                      }`}
                    >
                      <td className="p-3 font-semibold text-white">{cand.name}</td>
                      <td className="p-3 text-slate-300">{cand.appliedRole}</td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${STAGE_COLORS[cand.stage]}`}>
                          {STAGE_LABELS[cand.stage] || cand.stage}
                        </span>
                      </td>
                      <td className="p-3 text-slate-300">
                        {(cand.referenceChecks || []).filter((r: any) => r.verified).length}/2 Completed
                      </td>
                      <td className="p-3">
                        <Button
                          intent="secondary"
                          size="xs"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedCandidate(cand);
                            setShowRefModal(true);
                          }}
                        >
                          + Ref Check
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Selected Candidate Detail Card */}
          {selectedCandidate && (
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-white">{selectedCandidate.name}</h3>
                  <p className="text-xs text-slate-400">
                    {selectedCandidate.appliedRole} • {selectedCandidate.email} • {selectedCandidate.phone || 'No phone'}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Button intent="secondary" size="xs" onClick={() => setShowRefModal(true)}>
                    + Verify Reference Check
                  </Button>
                  <Button intent="primary" size="xs" onClick={() => setShowOfferModal(true)}>
                    Issue Offer Letter
                  </Button>
                </div>
              </div>

              {/* Reference Checks Display */}
              <div>
                <h4 className="text-xs font-semibold text-slate-300 mb-2 flex items-center gap-2">
                  <FileCheck className="w-4 h-4 text-emerald-400" />
                  <span>Statutory Reference Checks (BRD Mandate: Minimum 2 Required)</span>
                </h4>
                {(!selectedCandidate.referenceChecks || selectedCandidate.referenceChecks.length === 0) ? (
                  <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800 text-slate-400 text-xs text-center">
                    No reference checks recorded yet. Add at least 2 checks before issuing an offer.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {selectedCandidate.referenceChecks.map((rc: any, i: number) => (
                      <div key={i} className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white">{rc.referee}</span>
                          <span className="text-emerald-400 font-bold text-[10px]">✓ VERIFIED</span>
                        </div>
                        <p className="text-[11px] text-slate-400">{rc.designation}</p>
                        <p className="text-[11px] text-slate-300 italic">"{rc.feedback}"</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Right 1 Col: Record Chatter */}
        <div className="lg:col-span-1 h-[650px]">
          {selectedCandidate ? (
            <RecordChatter
              recordType="candidate"
              recordId={selectedCandidate.id}
              recordTitle={selectedCandidate.name}
            />
          ) : (
            <div className="h-full rounded-2xl border border-slate-800 bg-slate-900/40 flex items-center justify-center text-slate-500 text-xs">
              Select a candidate to view discussion & activity history
            </div>
          )}
        </div>
      </div>

      {/* Add Candidate Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <form onSubmit={handleAddCandidate} className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-sm font-bold text-white">Source New Candidate</h3>
            <div>
              <label className="text-[10px] font-semibold text-slate-400 block mb-1">Full Name</label>
              <input
                type="text"
                required
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g. Rahul Varma"
                className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white"
              />
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-400 block mb-1">Email Address</label>
              <input
                type="email"
                required
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                placeholder="rahul@example.com"
                className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white"
              />
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-400 block mb-1">Phone</label>
              <input
                type="text"
                value={newPhone}
                onChange={(e) => setNewPhone(e.target.value)}
                placeholder="+91 98765 43210"
                className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white"
              />
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-400 block mb-1">Applied Role</label>
              <input
                type="text"
                required
                value={newRole}
                onChange={(e) => setNewRole(e.target.value)}
                placeholder="e.g. Senior M&E Coordinator"
                className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button intent="secondary" size="sm" onClick={() => setShowAddModal(false)}>
                Cancel
              </Button>
              <Button intent="primary" size="sm" type="submit">
                Create Candidate
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* Verify Reference Check Modal */}
      {showRefModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <form onSubmit={handleAddReference} className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-sm font-bold text-white">Record Reference Verification</h3>
            <p className="text-[11px] text-slate-400">
              For candidate: <strong className="text-white">{selectedCandidate?.name}</strong>
            </p>
            <div>
              <label className="text-[10px] font-semibold text-slate-400 block mb-1">Referee Name</label>
              <input
                type="text"
                required
                value={refereeName}
                onChange={(e) => setRefereeName(e.target.value)}
                placeholder="e.g. Dr. Rajesh Mehra (Former Director)"
                className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white"
              />
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-400 block mb-1">Referee Designation & Organization</label>
              <input
                type="text"
                value={refereeDesignation}
                onChange={(e) => setRefereeDesignation(e.target.value)}
                placeholder="e.g. Professor, Delhi University"
                className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white"
              />
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-400 block mb-1">Verification Remarks & Feedback</label>
              <textarea
                rows={3}
                required
                value={refereeFeedback}
                onChange={(e) => setRefereeFeedback(e.target.value)}
                placeholder="Professional conduct, integrity, role suitability..."
                className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button intent="secondary" size="sm" onClick={() => setShowRefModal(false)}>
                Cancel
              </Button>
              <Button intent="primary" size="sm" type="submit">
                Save & Verify Check
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* Issue Offer Modal */}
      {showOfferModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <form onSubmit={handleIssueOffer} className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-sm font-bold text-white">Generate President Appointment Offer</h3>
            <p className="text-[11px] text-slate-400">
              Issuing digitally signed offer to <strong className="text-white">{selectedCandidate?.name}</strong>
            </p>
            <div>
              <label className="text-[10px] font-semibold text-slate-400 block mb-1">Offered Annual CTC (INR)</label>
              <input
                type="number"
                required
                value={offeredCtc}
                onChange={(e) => setOfferedCtc(Number(e.target.value))}
                className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white"
              />
            </div>
            <div>
              <label className="text-[10px] font-semibold text-slate-400 block mb-1">Expected Joining Date</label>
              <input
                type="date"
                required
                value={joiningDate}
                onChange={(e) => setJoiningDate(e.target.value)}
                className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white"
              />
            </div>
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-[11px] leading-relaxed">
              • Offer will carry digital signature of Founder & President (Dr. Surbhi Singh).
              <br />
              • A secure digital acceptance link will be dispatched automatically.
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button intent="secondary" size="sm" onClick={() => setShowOfferModal(false)}>
                Cancel
              </Button>
              <Button intent="primary" size="sm" type="submit">
                Issue Appointment Offer
              </Button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
