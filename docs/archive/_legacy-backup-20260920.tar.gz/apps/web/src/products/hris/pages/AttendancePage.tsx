import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useUiStore } from '@/platform/state/uiStore';
import { apiClient } from '@/api';
import { AttendanceRecord } from '@/types';
import {
  Clock,
  CheckCircle2,
  AlertTriangle,
  Home,
  MapPin,
  Calendar,
  ShieldAlert,
  ArrowRight,
} from 'lucide-react';
import { Button } from '@/shared/components/ui/Button';
import { Badge } from '@/shared/components/ui/Badge';

export default function AttendancePage() {
  const { currentUser } = useAuth();
  const addNotification = useUiStore((s) => s.addNotification);
  const refreshKey = useUiStore((s) => s.refreshKey);
  const [attendanceLogs, setAttendanceLogs] = useState<AttendanceRecord[]>([]);
  const [userStats, setUserStats] = useState<any>(null);
  const [isWfh, setIsWfh] = useState(false);
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    fetchAttendance();
    const interval = setInterval(() => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('en-IN', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true,
        })
      );
    }, 1000);
    return () => clearInterval(interval);
  }, [currentUser, refreshKey]);

  const fetchAttendance = async () => {
    try {
      setLoading(true);
      const res = await apiClient.getAttendance(currentUser);
      if (res.success) {
        setAttendanceLogs(res.data);
        setUserStats(res.userStats);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handlePunchIn = async () => {
    try {
      const res = await apiClient.punchIn(isWfh, currentUser);
      if (res.success) {
        setFeedback(res.message);
        addNotification({
          type: res.message.includes('Late') ? 'warning' : 'success',
          title: 'Punch In Recorded',
          message: res.message,
        });
        setTimeout(() => setFeedback(null), 5000);
        fetchAttendance();
      } else {
        addNotification({
          type: 'error',
          title: 'Punch In Failed',
          message: res.message,
        });
      }
    } catch (e: any) {
      addNotification({
        type: 'error',
        title: 'Error',
        message: e?.message || 'Failed to punch in',
      });
    }
  };

  const handlePunchOut = async () => {
    try {
      const res = await apiClient.punchOut(currentUser);
      if (res.success) {
        setFeedback('Punch out recorded successfully.');
        addNotification({
          type: 'success',
          title: 'Punch Out Recorded',
          message: 'Work day logged successfully.',
        });
        setTimeout(() => setFeedback(null), 5000);
        fetchAttendance();
      } else {
        addNotification({
          type: 'error',
          title: 'Punch Out Failed',
          message: res.message,
        });
      }
    } catch (e: any) {
      addNotification({
        type: 'error',
        title: 'Error',
        message: e?.message || 'Failed to punch out',
      });
    }
  };

  const todayStr = new Date().toISOString().split('T')[0];
  const todayRecord = attendanceLogs.find(
    (a) => a.userId === currentUser?.id && a.date === todayStr
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
          <span>Daily Digital Attendance & Working Hours</span>
          <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
            BRD Rules Active
          </span>
        </h2>
        <p className="text-xs text-slate-400">
          Official hours start at 10:00 AM. 3rd late arrival in a calendar month triggers automatic half-day deduction.
        </p>
      </div>

      {feedback && (
        <div className="p-4 rounded-xl bg-indigo-950/30 border border-indigo-500/40 text-indigo-300 text-xs flex items-center gap-2 animate-fade-in-up">
          <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Main Punch Clock & Policy Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Punch Widget (1 Col) */}
        <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-5 text-center flex flex-col items-center justify-center">
          <div className="space-y-1">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Current Local Time (IST)
            </span>
            <div className="text-3xl sm:text-4xl font-mono font-bold text-white tracking-widest">
              {currentTime || '--:--:--'}
            </div>
            <div className="text-xs text-slate-400">Shift Window: 10:00 AM – 06:30 PM</div>
          </div>

          <div className="flex items-center gap-3 p-2 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-300">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isWfh}
                onChange={(e) => setIsWfh(e.target.checked)}
                className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 bg-slate-800 border-slate-700"
              />
              <span className="flex items-center gap-1.5">
                <Home className="w-3.5 h-3.5 text-indigo-400" />
                Work From Home (WFH Mode)
              </span>
            </label>
          </div>

          <div className="w-full flex flex-col gap-2.5">
            {!todayRecord || !todayRecord.checkInTime ? (
              <Button
                intent="primary"
                size="lg"
                onClick={handlePunchIn}
                className="w-full"
              >
                <Clock className="w-4 h-4 mr-1.5" />
                Punch In for Today
              </Button>
            ) : !todayRecord.checkOutTime ? (
              <Button
                intent="secondary"
                size="lg"
                onClick={handlePunchOut}
                className="w-full border-rose-500/40 text-rose-300 hover:bg-rose-500/15"
              >
                <Clock className="w-4 h-4 mr-1.5" />
                Punch Out (Check-in: {todayRecord.checkInTime})
              </Button>
            ) : (
              <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
                Completed Shift: {todayRecord.checkInTime} – {todayRecord.checkOutTime}
              </div>
            )}
          </div>
        </div>

        {/* Lateness Telemetry & Penalty Engine (2 Cols) */}
        <div className="lg:col-span-2 glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <span>Lateness Telemetry & Automated Deduction Rule</span>
            </h3>
            <Badge color="amber" variant="soft" size="xs">
              HRIS Policy
            </Badge>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-400 uppercase font-semibold">
                Monthly Late Punches (&gt;10:00 AM)
              </span>
              <div className="text-2xl font-bold text-amber-400 font-mono">
                {userStats?.latenessCount ?? 0} / 3 Allowed
              </div>
              <p className="text-[10px] text-slate-400">Current calendar month</p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-400 uppercase font-semibold">
                Deductions Triggered
              </span>
              <div className="text-2xl font-bold text-rose-400 font-mono">
                {userStats?.halfDayDeductions ?? 0} Half-Day
              </div>
              <p className="text-[10px] text-slate-400">Auto applied on 3rd late arrival</p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-400 uppercase font-semibold">
                WFH Days Logged
              </span>
              <div className="text-2xl font-bold text-indigo-400 font-mono">
                {userStats?.wfhDays ?? 0} Days
              </div>
              <p className="text-[10px] text-slate-400">Subject to supervisor consent</p>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-200/90 leading-relaxed">
            <strong>BRD Rule Matrix:</strong> Employees are permitted a maximum of two late punch-ins (between 10:01 AM and 10:30 AM) per month without financial deduction. On the <strong>3rd occurrence</strong>, a half-day salary deduction is automatically booked in the Payroll module.
          </div>
        </div>
      </div>

      {/* Attendance Logs Table */}
      <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider">
          Recent Biometric & Web Punches (Past 14 Days)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left text-slate-300">
            <thead className="text-[11px] uppercase bg-slate-950/60 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Check In</th>
                <th className="py-3 px-4">Check Out</th>
                <th className="py-3 px-4">Location / Mode</th>
                <th className="py-3 px-4">Lateness Status</th>
                <th className="py-3 px-4">Audit Record</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {attendanceLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/30 transition">
                  <td className="py-3 px-4 font-sans font-semibold text-white">{log.date}</td>
                  <td className="py-3 px-4 text-indigo-300">{log.checkInTime || '--:--'}</td>
                  <td className="py-3 px-4 text-slate-300">{log.checkOutTime || '--:--'}</td>
                  <td className="py-3 px-4 font-sans">
                    {log.isWfh ? (
                      <Badge color="indigo" variant="soft" size="xs">
                        WFH
                      </Badge>
                    ) : (
                      <Badge color="slate" variant="soft" size="xs">
                        Office
                      </Badge>
                    )}
                  </td>
                  <td className="py-3 px-4 font-sans">
                    {log.isLate ? (
                      <Badge color="rose" variant="soft" size="xs">
                        Late (&gt;10:00)
                      </Badge>
                    ) : (
                      <Badge color="emerald" variant="soft" size="xs">
                        On Time
                      </Badge>
                    )}
                  </td>
                  <td className="py-3 px-4 text-[11px] text-slate-400 font-sans">
                    {log.status === 'PRESENT' || log.status === 'WFH' ? (
                      <span className="text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Verified
                      </span>
                    ) : (
                      <span className="text-amber-400">{log.status}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
