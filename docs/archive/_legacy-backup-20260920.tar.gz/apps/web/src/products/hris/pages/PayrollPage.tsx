import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { apiClient } from '@/api';
import {
  Banknote,
  FileText,
  ShieldCheck,
  Download,
  CheckCircle2,
  Printer,
  TrendingUp,
  Percent,
} from 'lucide-react';
import { Button } from '@/shared/components/ui/Button';
import { Badge } from '@/shared/components/ui/Badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/shared/components/ui/Dialog';

export default function PayrollPage() {
  const { currentUser } = useAuth();
  const [payrollData, setPayrollData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activePayslip, setActivePayslip] = useState<any | null>(null);

  useEffect(() => {
    fetchPayroll();
  }, [currentUser]);

  const fetchPayroll = async () => {
    try {
      setLoading(true);
      const res = await apiClient.getPayrollSummary(currentUser);
      if (res.success) {
        setPayrollData(res);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenPayslip = async (userId: string) => {
    try {
      const res = await apiClient.getPayslip(userId, currentUser);
      if (res.success) {
        setActivePayslip(res.data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>Payroll & Statutory Benefits Engine</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              EPF 1952 & Gratuity 1972
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Monthly salary processing, 12% PF remittance, gratuity accruals, medical/accident insurance tracking
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            intent="primary"
            size="md"
            onClick={() => handleOpenPayslip(currentUser?.id || 'usr_emp_1')}
          >
            <FileText className="w-4 h-4 mr-1.5" />
            My Latest Payslip
          </Button>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl glass-card border border-emerald-500/30 bg-gradient-to-br from-emerald-950/40 to-slate-900/60">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Gross Monthly Disbursement</span>
            <Banknote className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">
            ₹ {(payrollData?.totalGrossDisbursement ?? 0).toLocaleString('en-IN')}
          </div>
          <p className="text-[11px] text-emerald-400 font-medium mt-1">
            Status: Approved for Bank Release by 5th
          </p>
        </div>

        <div className="p-5 rounded-2xl glass-card border border-blue-500/30 bg-gradient-to-br from-blue-950/40 to-slate-900/60">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Total EPF Remittance (12% + 12%)</span>
            <Percent className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">
            ₹ {(payrollData?.totalStatutoryPF ?? 0).toLocaleString('en-IN')}
          </div>
          <p className="text-[11px] text-blue-400 font-medium mt-1">
            100% EPFO Compliant with EPS allocation
          </p>
        </div>

        <div className="p-5 rounded-2xl glass-card border border-purple-500/30 bg-gradient-to-br from-purple-950/40 to-slate-900/60">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Total Gratuity Accrual Provision</span>
            <ShieldCheck className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">
            ₹ {(payrollData?.totalGratuityAccrued ?? 0).toLocaleString('en-IN')}
          </div>
          <p className="text-[11px] text-purple-400 font-medium mt-1">
            Formula: (15 × Basic × Tenure) ÷ 26
          </p>
        </div>
      </div>

      {/* Salary Register Table */}
      <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider">
          Current Month Salary Register (Sachhi Saheli Staff)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left text-slate-300">
            <thead className="text-[11px] uppercase bg-slate-950/60 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Employee</th>
                <th className="py-3 px-4">Basic Pay</th>
                <th className="py-3 px-4">HRA & Allowances</th>
                <th className="py-3 px-4">PF (12% Emp)</th>
                <th className="py-3 px-4">Lateness Deduction</th>
                <th className="py-3 px-4">Net Take-Home</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {((payrollData?.register || payrollData?.data) || []).map((row: any) => {
                const basic = row.basic ?? row.earnings?.basic ?? 0;
                const allowances = row.allowances ?? ((row.earnings?.hra || 0) + (row.earnings?.specialAllowance || 0));
                const pfDeduction = row.pfDeduction ?? row.deductions?.employeePF ?? 0;
                const latenessDeduction = row.latenessDeduction ?? 0;
                const netPay = row.netPay ?? row.netSalary ?? 0;

                return (
                  <tr key={row.userId} className="hover:bg-slate-800/30 transition">
                    <td className="py-3 px-4 font-sans">
                      <div className="font-bold text-white">{row.name}</div>
                      <div className="text-[11px] text-slate-400 font-mono">{row.employeeId}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-200">₹{basic.toLocaleString('en-IN')}</td>
                    <td className="py-3 px-4 text-slate-300">₹{allowances.toLocaleString('en-IN')}</td>
                    <td className="py-3 px-4 text-blue-300">₹{pfDeduction.toLocaleString('en-IN')}</td>
                    <td className="py-3 px-4 text-rose-300">
                      {latenessDeduction > 0 ? `₹${latenessDeduction.toLocaleString('en-IN')}` : '₹0'}
                    </td>
                    <td className="py-3 px-4 font-bold text-emerald-400">₹{netPay.toLocaleString('en-IN')}</td>
                    <td className="py-3 px-4 text-right font-sans">
                      <button
                        onClick={() => handleOpenPayslip(row.userId)}
                        className="px-2.5 py-1 rounded bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 hover:bg-indigo-600/40 transition text-[11px] font-semibold"
                      >
                        View Slip
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payslip Modal Dialog */}
      {activePayslip && (
        <Dialog open={!!activePayslip} onOpenChange={(open) => !open && setActivePayslip(null)}>
          <DialogContent size="lg">
            <DialogHeader>
              <div className="flex items-center justify-between">
                <div>
                  <DialogTitle>Monthly Salary Slip (Confidential)</DialogTitle>
                  <DialogDescription>
                    Sachhi Saheli NGO & SaaS ERP • Statutory Pay Slip for {activePayslip.month}
                  </DialogDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    intent="primary"
                    size="xs"
                    onClick={async () => {
                      try {
                        const blob = await apiClient.downloadPayslipPdf(
                          activePayslip.employeeId || 'EMP-DEL-001',
                          activePayslip.month,
                          currentUser
                        );
                        const url = window.URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `Payslip_${activePayslip.employeeId || 'EMP'}_${activePayslip.month || 'Current'}.pdf`;
                        document.body.appendChild(a);
                        a.click();
                        a.remove();
                        window.URL.revokeObjectURL(url);
                      } catch (err) {
                        console.error('Failed to download PDF:', err);
                      }
                    }}
                  >
                    <Download className="w-3.5 h-3.5 mr-1" />
                    Download Official PDF
                  </Button>
                  <Button intent="secondary" size="xs" onClick={() => window.print()}>
                    <Printer className="w-3.5 h-3.5 mr-1" />
                    Print
                  </Button>
                </div>
              </div>
            </DialogHeader>

            <div className="p-5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-4 font-mono text-xs">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 border-b border-slate-800 pb-3 text-slate-300 font-sans">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block font-mono">Employee</span>
                  <span className="font-bold text-white">{activePayslip.name}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block font-mono">ID / Designation</span>
                  <span>{activePayslip.employeeId} • {activePayslip.designation}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block font-mono">Department</span>
                  <span>{activePayslip.department}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block font-mono">PF UAN</span>
                  <span>{activePayslip.pfUan || 'UAN100984819'}</span>
                </div>
              </div>

              {/* Earnings & Deductions Tables */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2 font-sans">
                {/* Earnings */}
                <div className="space-y-2">
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">
                    Earnings & Allowances
                  </span>
                  <div className="divide-y divide-slate-800 text-xs">
                    <div className="py-1.5 flex justify-between">
                      <span className="text-slate-400">Basic Pay</span>
                      <span className="font-mono text-white">₹ {(activePayslip.basic ?? 0).toLocaleString('en-IN')}</span>
                    </div>
                    <div className="py-1.5 flex justify-between">
                      <span className="text-slate-400">House Rent Allowance (HRA)</span>
                      <span className="font-mono text-white">₹ {((activePayslip.basic ?? 0) * 0.4).toLocaleString('en-IN')}</span>
                    </div>
                    <div className="py-1.5 flex justify-between">
                      <span className="text-slate-400">Special Allowance</span>
                      <span className="font-mono text-white">₹ {Math.max((activePayslip.allowances ?? 0) - (activePayslip.basic ?? 0) * 0.4, 0).toLocaleString('en-IN')}</span>
                    </div>
                    <div className="py-2 flex justify-between font-bold border-t border-slate-700 text-white">
                      <span>Total Gross Earnings</span>
                      <span className="font-mono text-emerald-400">
                        ₹ {((activePayslip.grossEarnings ?? (activePayslip.basic ?? 0) + (activePayslip.allowances ?? 0))).toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Deductions */}
                <div className="space-y-2">
                  <span className="text-xs font-bold text-rose-400 uppercase tracking-wider block">
                    Statutory & Other Deductions
                  </span>
                  <div className="divide-y divide-slate-800 text-xs">
                    <div className="py-1.5 flex justify-between">
                      <span className="text-slate-400">Provident Fund (12% Employee)</span>
                      <span className="font-mono text-rose-300">₹ {(activePayslip.pfDeduction ?? 0).toLocaleString('en-IN')}</span>
                    </div>
                    <div className="py-1.5 flex justify-between">
                      <span className="text-slate-400">Professional Tax</span>
                      <span className="font-mono text-rose-300">₹ 200</span>
                    </div>
                    <div className="py-1.5 flex justify-between">
                      <span className="text-slate-400">Lateness Deduction (&gt;2 late punch-ins)</span>
                      <span className="font-mono text-rose-300">₹ {(activePayslip.latenessDeduction ?? 0).toLocaleString('en-IN')}</span>
                    </div>
                    <div className="py-2 flex justify-between font-bold border-t border-slate-700 text-white">
                      <span>Total Deductions</span>
                      <span className="font-mono text-rose-400">
                        ₹ {((activePayslip.totalDeductions ?? ((activePayslip.pfDeduction ?? 0) + 200 + (activePayslip.latenessDeduction ?? 0)))).toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Net Pay Banner */}
              <div className="p-4 rounded-xl bg-slate-900 border border-emerald-500/40 flex items-center justify-between font-sans">
                <div>
                  <span className="text-xs text-slate-400 uppercase tracking-wider block">Net Take-Home Pay</span>
                  <span className="text-xs text-slate-500">Transferred to Bank Account on File</span>
                </div>
                <div className="text-2xl font-bold font-mono text-emerald-400">
                  ₹ {(activePayslip.netPay ?? activePayslip.netPayable ?? 0).toLocaleString('en-IN')}
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
