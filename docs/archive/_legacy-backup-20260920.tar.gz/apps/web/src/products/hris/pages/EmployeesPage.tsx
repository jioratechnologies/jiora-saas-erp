import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { apiClient } from '@/api';
import {
  Users,
  Search,
  Building,
  Mail,
  FileText,
  ShieldCheck,
  CheckCircle,
  CreditCard,
  Briefcase,
} from 'lucide-react';
import { Badge } from '@/shared/components/ui/Badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/shared/components/ui/Dialog';
import { RecordChatter } from '@/shared/components/workspace/RecordChatter';

export default function EmployeesPage() {
  const { currentUser } = useAuth();
  const [employees, setEmployees] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEmployee, setSelectedEmployee] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchEmployees();
  }, [currentUser]);

  const fetchEmployees = async () => {
    try {
      setLoading(true);
      const res = await apiClient.getEmployees(currentUser);
      if (res.success) {
        setEmployees(res.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const filtered = employees.filter(
    (e) =>
      e.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.employeeId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header & Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>Employee Master & Statutory Records</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              {employees.length} Personnel
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Centralized employee records, 7-point document verification & statutory KYC
          </p>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by name, ID or department..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Grid of Employee Cards */}
      {loading ? (
        <div className="p-12 text-center text-xs text-slate-400">Loading employee master...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((emp) => (
            <div
              key={emp.id}
              onClick={() => setSelectedEmployee(emp)}
              className="p-5 rounded-2xl glass-card border border-slate-800/80 hover:border-indigo-500/50 cursor-pointer space-y-4"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center font-bold text-white shadow-md shadow-indigo-600/20">
                    {emp.name.charAt(0)}
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white flex items-center gap-1.5">
                      {emp.name}
                    </div>
                    <div className="text-xs text-indigo-400 font-mono">{emp.employeeId}</div>
                  </div>
                </div>

                <Badge
                  color={emp.status === 'ACTIVE' ? 'emerald' : emp.status === 'PROBATION' ? 'amber' : 'rose'}
                  variant="soft"
                  size="xs"
                >
                  {emp.status}
                </Badge>
              </div>

              <div className="space-y-1.5 text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <Briefcase className="w-3.5 h-3.5 text-slate-500" />
                  <span>{emp.designation}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Building className="w-3.5 h-3.5 text-slate-500" />
                  <span>{emp.department}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-slate-500" />
                  <span className="text-slate-400 truncate">{emp.email}</span>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                <span className="text-slate-400">Basic: ₹{(emp.basicSalary ?? emp.profile?.salaryStructure?.basicMonthly ?? 30000).toLocaleString('en-IN')}</span>
                <span className="text-indigo-400 font-semibold hover:underline">
                  View Full Dossier →
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Employee Dossier Dialog */}
      {selectedEmployee && (
        <Dialog open={!!selectedEmployee} onOpenChange={(open) => !open && setSelectedEmployee(null)}>
          <DialogContent size="lg">
            <DialogHeader>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center text-lg font-bold">
                  {selectedEmployee.name.charAt(0)}
                </div>
                <div>
                  <DialogTitle>{selectedEmployee.name}</DialogTitle>
                  <DialogDescription>
                    {selectedEmployee.employeeId} • {selectedEmployee.designation} ({selectedEmployee.department})
                  </DialogDescription>
                </div>
              </div>
            </DialogHeader>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs mt-4">
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
                <h4 className="font-semibold text-white uppercase text-[11px] flex items-center gap-2">
                  <CreditCard className="w-3.5 h-3.5 text-indigo-400" />
                  Statutory & Banking Details
                </h4>
                <div className="space-y-1 text-slate-300 font-mono text-[11px]">
                  <div>PF UAN: <span className="text-slate-100">{selectedEmployee.statutory?.pfUan || 'UAN100984819'}</span></div>
                  <div>ESIC: <span className="text-slate-100">{selectedEmployee.statutory?.esicNumber || 'ESIC8893123'}</span></div>
                  <div>PAN: <span className="text-slate-100">{selectedEmployee.statutory?.pan || 'ABCDE1234F'}</span></div>
                  <div>Bank: <span className="text-slate-100">{selectedEmployee.statutory?.bankAccount || 'HDFC •••• 4912'}</span></div>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
                <h4 className="font-semibold text-white uppercase text-[11px] flex items-center gap-2">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  7-Point KYC Verification Status
                </h4>
                <div className="space-y-1 text-slate-300">
                  <div className="flex items-center gap-1.5 text-emerald-400">
                    <CheckCircle className="w-3.5 h-3.5" /> <span>Aadhaar & Identity Verified</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-emerald-400">
                    <CheckCircle className="w-3.5 h-3.5" /> <span>PAN / Income Tax Validated</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-emerald-400">
                    <CheckCircle className="w-3.5 h-3.5" /> <span>Education Credentials Vetted</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-emerald-400">
                    <CheckCircle className="w-3.5 h-3.5" /> <span>Previous Employer Relieving Verified</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-300 mt-4">
              <h4 className="font-semibold text-white uppercase text-[11px] mb-2 flex items-center gap-2">
                <FileText className="w-3.5 h-3.5 text-purple-400" />
                Statutory Compliance & Gratuity Calculation Base
              </h4>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Eligible under Payment of Gratuity Act 1972 after 5 continuous years of tenure. Basic Salary of ₹{(selectedEmployee.basicSalary ?? selectedEmployee.profile?.salaryStructure?.basicMonthly ?? 30000).toLocaleString('en-IN')} is locked as calculation denominator for gratuity formula <code className="text-indigo-300 font-mono">(15 × Basic × Tenure) / 26</code>.
              </p>
            </div>

            {/* Record Chatter Integration */}
            <div className="mt-4 pt-4 border-t border-slate-800">
              <RecordChatter
                recordType="employee"
                recordId={selectedEmployee.id || selectedEmployee.employeeId}
                recordTitle={`Employee: ${selectedEmployee.name}`}
              />
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
