import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useUiStore } from '@/platform/state/uiStore';
import { apiClient } from '@/api';
import { ExitRecord } from '@/types';
import {
  LogOut,
  CheckCircle2,
  Clock,
  ShieldCheck,
  User,
  Laptop,
  Building,
  Banknote,
  FileCheck2,
  AlertCircle,
} from 'lucide-react';
import { Button } from '@/shared/components/ui/Button';
import { Badge } from '@/shared/components/ui/Badge';
import { EmptyState } from '@/shared/components/ui/EmptyState';

export default function ExitClearancePage() {
  const { currentUser } = useAuth();
  const addNotification = useUiStore((s) => s.addNotification);
  const refreshKey = useUiStore((s) => s.refreshKey);
  const [exitRecords, setExitRecords] = useState<ExitRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchExitRecords();
  }, [currentUser, refreshKey]);

  const fetchExitRecords = async () => {
    try {
      setLoading(true);
      const res = await apiClient.getExitRecords(currentUser);
      if (res.success) {
        setExitRecords(res.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleStep = async (exitId: string, stepNumber: number, currentVal: boolean) => {
    try {
      const res = await apiClient.updateExitChecklist(exitId, stepNumber, !currentVal, currentUser);
      if (res.success) {
        addNotification({
          type: 'info',
          title: 'Clearance Updated',
          message: `Step ${stepNumber} status changed.`,
        });
        fetchExitRecords();
      }
    } catch (e: any) {
      addNotification({
        type: 'error',
        title: 'Update Error',
        message: e?.message || 'Error updating clearance step',
      });
    }
  };

  const activeRecord = exitRecords[0];

  const getDeptIcon = (dept: string) => {
    switch (dept) {
      case 'IT':
        return <Laptop className="w-3.5 h-3.5 text-blue-400" />;
      case 'ADMIN':
        return <Building className="w-3.5 h-3.5 text-amber-400" />;
      case 'FINANCE':
        return <Banknote className="w-3.5 h-3.5 text-emerald-400" />;
      default:
        return <User className="w-3.5 h-3.5 text-rose-400" />;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
          <span>16-Step Employee Exit & F&F Clearance</span>
          <span className="text-xs px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
            BRD Section 4.2
          </span>
        </h2>
        <p className="text-xs text-slate-400">
          Departmental sign-offs (HR, IT, Admin, Finance), Full & Final settlement, and Relieving Letter issuance
        </p>
      </div>

      {loading ? (
        <div className="p-12 text-center text-xs text-slate-400">Loading exit records...</div>
      ) : !activeRecord ? (
        <EmptyState
          title="No Active Resignation Cases"
          description="All employee exits have been processed and clearances closed."
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* 16-Step Checklist (2 Cols) */}
          <div className="lg:col-span-2 glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white">
                  Exit Checklist — Amit Patel (SS-024)
                </h3>
                <p className="text-xs text-slate-400">
                  Last Working Date: <strong className="text-slate-200">{activeRecord.approvedLastWorkingDate}</strong>
                </p>
              </div>
              <Badge color="amber" variant="soft" size="sm">
                {activeRecord.status}
              </Badge>
            </div>

            {/* Checklist Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {(activeRecord.checklist16Steps || []).map((item) => (
                <div
                  key={item.stepNumber}
                  onClick={() => handleToggleStep(activeRecord.id, item.stepNumber, item.completed)}
                  className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition select-none ${
                    item.completed
                      ? 'bg-emerald-950/20 border-emerald-500/40 text-slate-200'
                      : 'bg-slate-950/40 border-slate-800/80 text-slate-400 hover:border-indigo-500/40'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      checked={item.completed}
                      readOnly
                      className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 bg-slate-800 border-slate-700 pointer-events-none"
                    />
                    <div>
                      <div className="text-xs font-semibold text-white">{item.task}</div>
                      <div className="text-[10px] text-slate-500 flex items-center gap-1">
                        {getDeptIcon(item.department)}
                        <span>{item.department} Department</span>
                      </div>
                    </div>
                  </div>

                  {item.completed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <Clock className="w-4 h-4 text-slate-600 shrink-0" />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Full & Final Settlement Summary (1 Col) */}
          <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Banknote className="w-4 h-4 text-emerald-400" />
              <span>Full & Final (F&F) Settlement</span>
            </h3>

            <div className="space-y-3 font-mono text-xs">
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1.5 font-sans">
                <div className="text-slate-400 text-[11px]">Gratuity Calculation (Tenure: 5.2 Yrs)</div>
                <div className="text-lg font-bold text-emerald-400 font-mono">₹ 1,18,269</div>
                <p className="text-[10px] text-slate-500 font-mono">
                  Formula: (15 × ₹34,000 × 5.2) ÷ 26
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1.5 font-sans">
                <div className="text-slate-400 text-[11px]">Unavailed Earned Leave Encashment</div>
                <div className="text-lg font-bold text-indigo-400 font-mono">₹ 24,500</div>
                <p className="text-[10px] text-slate-500 font-mono">18 Days Accrued EL @ Daily Basic Rate</p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1.5 font-sans">
                <div className="text-slate-400 text-[11px]">Notice Period Recovery / Deductions</div>
                <div className="text-lg font-bold text-slate-200 font-mono">₹ 0 (Waived)</div>
              </div>

              <div className="pt-2 border-t border-slate-800 flex justify-between items-center font-sans">
                <span className="text-xs font-semibold text-slate-300">Net F&F Payable</span>
                <span className="text-xl font-bold font-mono text-emerald-400">₹ 1,42,769</span>
              </div>
            </div>

            <Button
              intent="primary"
              size="md"
              className="w-full"
              disabled={!(activeRecord.checklist16Steps || []).every((c) => c.completed)}
              onClick={async () => {
                try {
                  const blob = await apiClient.downloadRelievingPdf(activeRecord.employeeId || 'EMP-DEL-001', currentUser);
                  const url = window.URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `Relieving_Certificate_${activeRecord.employeeId || 'EMP'}.pdf`;
                  document.body.appendChild(a);
                  a.click();
                  a.remove();
                  window.URL.revokeObjectURL(url);
                  addNotification({
                    type: 'success',
                    title: 'Relieving Letter Generated',
                    message: 'Statutory Experience & Relieving Certificate downloaded.',
                  });
                } catch (err: any) {
                  addNotification({
                    type: 'error',
                    title: 'Generation Failed',
                    message: err.message || 'Error generating relieving letter PDF.',
                  });
                }
              }}
            >
              <FileCheck2 className="w-4 h-4 mr-1.5" />
              Generate Relieving & Experience Letter
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
