import { lazy } from 'react';
import type { RouteObject } from 'react-router-dom';
import { page } from '@/platform/routing/page';

const EmployeesPage = lazy(() => import('../pages/EmployeesPage'));
const AttendancePage = lazy(() => import('../pages/AttendancePage'));
const LeavePage = lazy(() => import('../pages/LeavePage'));
const PayrollPage = lazy(() => import('../pages/PayrollPage'));
const ExitClearancePage = lazy(() => import('../pages/ExitClearancePage'));
const RecruitmentPage = lazy(() => import('../pages/RecruitmentPage'));
const OnboardingPage = lazy(() => import('../pages/OnboardingPage'));
const PerformancePage = lazy(() => import('../pages/PerformancePage'));
const TravelExpensesPage = lazy(() => import('../pages/TravelExpensesPage'));
const KioskPage = lazy(() => import('../pages/KioskPage'));

export const hrisRoutes: RouteObject[] = [
  { path: 'hris/employees', element: page('Employee Master', <EmployeesPage />) },
  { path: 'hris/attendance', element: page('Attendance & Bio', <AttendancePage />) },
  { path: 'hris/leave', element: page('Leave Management', <LeavePage />) },
  { path: 'hris/payroll', element: page('Payroll & Statutory', <PayrollPage />) },
  { path: 'hris/exit', element: page('Exit Clearance (16-Step)', <ExitClearancePage />) },
  { path: 'hris/recruitment', element: page('Recruitment & ATS', <RecruitmentPage />) },
  { path: 'hris/onboarding', element: page('Onboarding & Probation', <OnboardingPage />) },
  { path: 'hris/performance', element: page('Performance & KRAs', <PerformancePage />) },
  { path: 'hris/travel-expenses', element: page('Travel & Conveyance', <TravelExpensesPage />) },
  { path: 'hris/kiosk', element: page('Attendance Kiosk', <KioskPage />) },
];
