import React, { useState, useEffect } from 'react';
import {
  Clock,
  QrCode,
  UserCheck,
  CheckCircle2,
  AlertTriangle,
  Fingerprint,
  Maximize2,
  Minimize2,
  ShieldCheck,
  Sparkles,
  Search,
} from 'lucide-react';
import { apiClient } from '@/api';
import { useAuth } from '@/context/AuthContext';

export default function KioskPage() {
  const { currentUser } = useAuth();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [badgeId, setBadgeId] = useState('');
  const [recentLogs, setRecentLogs] = useState<any[]>([]);
  const [scanResult, setScanResult] = useState<{
    success: boolean;
    name: string;
    action: 'IN' | 'OUT';
    time: string;
    isLate: boolean;
    lateCount?: number;
  } | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
        setIsFullscreen(false);
      }
    }
  };

  const handleBadgeScan = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!badgeId.trim()) return;

    const hour = currentTime.getHours();
    const minute = currentTime.getMinutes();
    const isLate = hour > 10 || (hour === 10 && minute > 0);

    // Call API attendance checkin/checkout
    try {
      const res = await apiClient.checkIn({
        employeeId: badgeId.trim(),
        timestamp: new Date().toISOString(),
      });

      const logEntry = {
        id: Date.now().toString(),
        name: res.employeeName || `Employee (${badgeId})`,
        action: 'IN',
        time: currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        isLate,
      };

      setScanResult({
        success: true,
        name: logEntry.name,
        action: 'IN',
        time: logEntry.time,
        isLate,
        lateCount: isLate ? 1 : 0,
      });

      setRecentLogs((prev) => [logEntry, ...prev.slice(0, 7)]);
      setBadgeId('');

      // Auto dismiss success toast after 4s
      setTimeout(() => setScanResult(null), 4000);
    } catch (err: any) {
      setScanResult({
        success: false,
        name: `Badge ${badgeId}`,
        action: 'IN',
        time: currentTime.toLocaleTimeString(),
        isLate: false,
      });
      setTimeout(() => setScanResult(null), 4000);
    }
  };

  return (
    <div className="min-h-[85vh] flex flex-col justify-between p-4 md:p-8 bg-slate-950 text-white rounded-3xl border border-slate-800 shadow-2xl relative overflow-hidden">
      {/* Background ambient glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Bar */}
      <div className="flex items-center justify-between z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-500 via-indigo-600 to-purple-600 flex items-center justify-center text-lg shadow-lg shadow-indigo-600/30">
            🌸
          </div>
          <div>
            <h2 className="text-sm font-bold tracking-wider uppercase">Sachhi Saheli Kiosk</h2>
            <p className="text-[11px] text-slate-400">Biometric & Smart Attendance Station</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Scanner Active
          </div>
          <button
            onClick={toggleFullscreen}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-400 hover:text-white transition"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Center Hero: Digital Clock & Scan Terminal */}
      <div className="max-w-xl mx-auto w-full text-center py-8 z-10 space-y-6">
        {/* Clock Display */}
        <div className="space-y-1">
          <div className="text-5xl md:text-7xl font-mono font-bold tracking-tight bg-gradient-to-b from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
            {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
          </div>
          <p className="text-xs md:text-sm text-slate-400 font-medium tracking-wide">
            {currentTime.toLocaleDateString(undefined, {
              weekday: 'long',
              year: 'numeric',
              month: 'long',
              day: 'numeric',
            })}
          </p>
        </div>

        {/* Scan Input & Biometric Touch Area */}
        <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400 animate-pulse">
            <Fingerprint className="w-8 h-8" />
          </div>

          <div>
            <h3 className="text-base font-semibold text-white">Scan RFID Badge or Enter Employee ID</h3>
            <p className="text-xs text-slate-400">Official hours: 09:30 AM — Grace period ends at 10:00 AM</p>
          </div>

          <form onSubmit={handleBadgeScan} className="flex gap-2">
            <input
              type="text"
              value={badgeId}
              onChange={(e) => setBadgeId(e.target.value)}
              placeholder="e.g. EMP-DEL-001 or swipe card..."
              className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-center text-sm font-mono tracking-widest text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              autoFocus
            />
            <button
              type="submit"
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl text-xs shadow-lg shadow-indigo-600/20 transition flex items-center gap-1.5"
            >
              <UserCheck className="w-4 h-4" />
              Clock
            </button>
          </form>

          {/* Quick Demo Badges */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-2 text-[11px] text-slate-400">
            <span>Quick test:</span>
            <button
              onClick={() => {
                setBadgeId('EMP-DEL-001');
                setTimeout(() => handleBadgeScan(), 50);
              }}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-indigo-300 font-mono"
            >
              EMP-DEL-001 (Pooja)
            </button>
            <button
              onClick={() => {
                setBadgeId('EMP-DEL-002');
                setTimeout(() => handleBadgeScan(), 50);
              }}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-indigo-300 font-mono"
            >
              EMP-DEL-002 (Dr. Ananya)
            </button>
          </div>
        </div>

        {/* Live Feedback Toast */}
        {scanResult && (
          <div
            className={`p-4 rounded-2xl border flex items-center gap-3 text-left animate-in fade-in slide-in-from-bottom-3 duration-200 ${
              scanResult.success
                ? scanResult.isLate
                  ? 'bg-amber-500/15 border-amber-500/40 text-amber-300'
                  : 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                : 'bg-rose-500/15 border-rose-500/40 text-rose-300'
            }`}
          >
            {scanResult.success ? (
              scanResult.isLate ? (
                <AlertTriangle className="w-6 h-6 flex-shrink-0 text-amber-400" />
              ) : (
                <CheckCircle2 className="w-6 h-6 flex-shrink-0 text-emerald-400" />
              )
            ) : (
              <AlertTriangle className="w-6 h-6 flex-shrink-0 text-rose-400" />
            )}

            <div>
              <h4 className="text-sm font-bold text-white">
                {scanResult.success ? `Welcome, ${scanResult.name}!` : 'Authentication Error'}
              </h4>
              <p className="text-xs">
                {scanResult.success
                  ? scanResult.isLate
                    ? `Clock-in logged at ${scanResult.time}. Note: Recorded as LATE (>10:00 AM). 3 late arrivals incur a half-day CL deduction per statutory policy.`
                    : `Clock-in recorded on time at ${scanResult.time}. Have a productive day!`
                  : 'Employee badge ID not recognized in database.'}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Ticker: Recent Punches */}
      <div className="z-10 bg-slate-900/40 border border-slate-800/80 rounded-2xl p-4">
        <h4 className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-2">
          <Clock className="w-3.5 h-3.5 text-indigo-400" />
          Today's Live Biometric Log Stream
        </h4>
        <div className="flex gap-3 overflow-x-auto pb-1 text-xs">
          {recentLogs.length === 0 ? (
            <span className="text-slate-500 text-xs italic">Waiting for badges to punch in...</span>
          ) : (
            recentLogs.map((log) => (
              <div
                key={log.id}
                className="flex-shrink-0 bg-slate-950/70 border border-slate-800 px-3 py-2 rounded-xl flex items-center gap-2.5"
              >
                <div className={`w-2 h-2 rounded-full ${log.isLate ? 'bg-amber-400' : 'bg-emerald-400'}`} />
                <span className="text-white font-medium">{log.name}</span>
                <span className="text-slate-400 font-mono text-[11px]">{log.time}</span>
                {log.isLate && (
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300">
                    LATE
                  </span>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
