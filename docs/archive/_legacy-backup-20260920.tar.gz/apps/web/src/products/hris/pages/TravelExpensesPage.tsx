import React, { useState, useEffect } from 'react';
import {
  Plane,
  Receipt,
  MapPin,
  AlertCircle,
  CheckCircle2,
  DollarSign,
  Calendar,
  Clock,
  Plus,
  ArrowRight,
  ShieldAlert,
  FileText,
  CreditCard,
} from 'lucide-react';
import { apiClient } from '@/api';
import { useAuth } from '@/context/AuthContext';
import { RecordChatter } from '@/shared/components/workspace/RecordChatter';

interface TourItem {
  id: string;
  employeeId: string;
  employeeName: string;
  destination: string;
  cityTier: 'TIER_1' | 'TIER_2' | 'TIER_3';
  purpose: string;
  startDate: string;
  endDate: string;
  estimatedCost: number;
  advanceRequested: number;
  status: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED' | 'SETTLED';
}

interface ExpenseClaim {
  id: string;
  tourId?: string;
  employeeName: string;
  category: 'PER_DIEM' | 'HOTEL' | 'CONVEYANCE' | 'MEALS' | 'INCIDENTAL';
  amount: number;
  billDate: string;
  receiptUrl?: string;
  status: 'PENDING' | 'VERIFIED' | 'REIMBURSED';
}

export default function TravelExpensesPage() {
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState<'tours' | 'claims' | 'advance'>('tours');
  const [tours, setTours] = useState<TourItem[]>([]);
  const [claims, setClaims] = useState<ExpenseClaim[]>([]);
  const [loading, setLoading] = useState(true);

  // New Tour Modal State
  const [showNewTourModal, setShowNewTourModal] = useState(false);
  const [tourForm, setTourForm] = useState({
    destination: '',
    cityTier: 'TIER_1' as 'TIER_1' | 'TIER_2' | 'TIER_3',
    purpose: '',
    startDate: '',
    endDate: '',
    estimatedCost: 12000,
    advanceRequested: 8000,
  });

  // Emergency Advance State
  const [emergencyAdvanceAmount, setEmergencyAdvanceAmount] = useState<number>(50000);
  const [tenureMonths, setTenureMonths] = useState<number>(6);
  const [advanceReason, setAdvanceReason] = useState<string>('Medical emergency in family');
  const [advanceNotice, setAdvanceNotice] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  useEffect(() => {
    loadData();
  }, [currentUser]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [toursRes, claimsRes] = await Promise.all([
        apiClient.getTours(currentUser),
        apiClient.getExpenseClaims(currentUser),
      ]);
      if (toursRes && toursRes.success) setTours(toursRes.data || []);
      if (claimsRes && claimsRes.success) setClaims(claimsRes.data || []);
    } catch (err) {
      console.error('Failed to load travel data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTour = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiClient.createTour(
        {
          ...tourForm,
          employeeId: currentUser?.id || 'EMP-DEL-001',
          employeeName: currentUser?.name || 'Authorized Staff',
        },
        currentUser
      );
      setShowNewTourModal(false);
      await loadData();
    } catch (err) {
      console.error('Error creating tour:', err);
    }
  };

  const handleApplyAdvance = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await apiClient.applyEmergencyAdvance(
        {
          employeeId: currentUser?.id || 'EMP-DEL-001',
          amount: emergencyAdvanceAmount,
          tenureMonths,
          reason: advanceReason,
        },
        currentUser
      );

      if (res && res.success) {
        setAdvanceNotice({
          type: 'success',
          message: `Emergency Advance Request ₹${emergencyAdvanceAmount.toLocaleString('en-IN')} submitted! Monthly EMI: ₹${Math.round(emergencyAdvanceAmount / tenureMonths).toLocaleString('en-IN')}`,
        });
      } else {
        setAdvanceNotice({
          type: 'error',
          message: res.message || 'Advance application failed statutory policy check.',
        });
      }
    } catch (err: any) {
      setAdvanceNotice({
        type: 'error',
        message: err.message || 'Emergency advance rejected.',
      });
    }
  };

  // Statutory City Tier Entitlements
  const CITY_TIERS = {
    TIER_1: { name: 'Tier 1 (Metro: Delhi, Mumbai, Bengaluru, etc.)', da: '₹1,500/day', hotelCap: '₹3,500/night' },
    TIER_2: { name: 'Tier 2 (State Capitals & Major Cities)', da: '₹1,000/day', hotelCap: '₹2,200/night' },
    TIER_3: { name: 'Tier 3 (Field Locations & Towns)', da: '₹750/day', hotelCap: '₹1,500/night' },
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900/60 p-6 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-sky-500/10 border border-sky-500/20 text-sky-400">
            <Plane className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight">Travel, Tours & Conveyance</h1>
            <p className="text-xs text-slate-400">
              Statutory city-tier DA, tour approval workflows, conveyance settlements & emergency salary advances
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowNewTourModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-indigo-600/20 transition"
          >
            <Plus className="w-4 h-4" />
            New Tour Request
          </button>
        </div>
      </div>

      {/* City Tier Entitlement Reference Banner */}
      <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-800/80">
        <div className="flex items-center gap-2 mb-3 text-xs font-semibold uppercase tracking-wider text-slate-300">
          <MapPin className="w-4 h-4 text-sky-400" />
          BRD Travel Policy Schedule 2026 (Statutory Per-Diem Entitlements)
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          {Object.entries(CITY_TIERS).map(([key, item]) => (
            <div key={key} className="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
              <span className="font-bold text-sky-300">{item.name}</span>
              <div className="mt-2 flex items-center justify-between text-slate-400 text-[11px]">
                <span>Daily Allowance: <strong className="text-white">{item.da}</strong></span>
                <span>Hotel Cap: <strong className="text-white">{item.hotelCap}</strong></span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('tours')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition flex items-center gap-2 ${
            activeTab === 'tours' ? 'bg-sky-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Plane className="w-3.5 h-3.5" />
          Tour Authorizations ({tours.length})
        </button>
        <button
          onClick={() => setActiveTab('claims')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition flex items-center gap-2 ${
            activeTab === 'claims' ? 'bg-sky-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Receipt className="w-3.5 h-3.5" />
          Expense Claims & Conveyance ({claims.length})
        </button>
        <button
          onClick={() => setActiveTab('advance')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition flex items-center gap-2 ${
            activeTab === 'advance' ? 'bg-sky-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          <DollarSign className="w-3.5 h-3.5" />
          Emergency Salary Advance
        </button>
      </div>

      {/* Tab Contents */}
      {activeTab === 'tours' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {tours.map((tour) => (
              <div
                key={tour.id}
                className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-sky-500/20 text-sky-300">
                      {tour.cityTier.replace('_', ' ')}
                    </span>
                    <h3 className="text-base font-bold text-white mt-2">{tour.destination}</h3>
                    <p className="text-xs text-slate-400">{tour.employeeName}</p>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2.5 py-1 rounded-full uppercase ${
                      tour.status === 'APPROVED'
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : tour.status === 'SETTLED'
                        ? 'bg-indigo-500/20 text-indigo-300'
                        : 'bg-amber-500/20 text-amber-400'
                    }`}
                  >
                    {tour.status.replace('_', ' ')}
                  </span>
                </div>

                <p className="text-xs text-slate-300 mt-3 bg-slate-950/40 p-2.5 rounded-lg">
                  "{tour.purpose}"
                </p>

                <div className="mt-4 pt-3 border-t border-slate-800/80 space-y-1.5 text-xs text-slate-400">
                  <div className="flex justify-between">
                    <span>Duration:</span>
                    <span className="text-slate-200 font-medium">{tour.startDate} to {tour.endDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Est. Cost:</span>
                    <span className="text-slate-200 font-medium">₹{tour.estimatedCost.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Advance Issued:</span>
                    <span className="text-emerald-400 font-bold">₹{tour.advanceRequested.toLocaleString('en-IN')}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'claims' && (
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl overflow-hidden">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-300">
              Conveyance & Travel Reimbursement Registry
            </h3>
          </div>
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-950/60 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="p-3">Claim ID</th>
                <th className="p-3">Employee</th>
                <th className="p-3">Category</th>
                <th className="p-3">Bill Date</th>
                <th className="p-3">Amount</th>
                <th className="p-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {claims.map((c) => (
                <tr key={c.id} className="hover:bg-slate-800/40">
                  <td className="p-3 font-mono text-slate-400">{c.id}</td>
                  <td className="p-3 text-white font-medium">{c.employeeName}</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-medium">
                      {c.category}
                    </span>
                  </td>
                  <td className="p-3 text-slate-400">{c.billDate}</td>
                  <td className="p-3 font-bold text-emerald-400">
                    ₹{c.amount.toLocaleString('en-IN')}
                  </td>
                  <td className="p-3">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400">
                      {c.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'advance' && (
        <div className="max-w-2xl mx-auto bg-slate-900/60 border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
            <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Emergency Salary Advance Application</h3>
              <p className="text-xs text-slate-400">
                Statutory policy: Max 3x Gross Monthly Salary or ₹1,00,000 (whichever is lower), max 12-month EMI deduction
              </p>
            </div>
          </div>

          {advanceNotice && (
            <div
              className={`p-3 rounded-xl border text-xs flex items-center justify-between ${
                advanceNotice.type === 'success'
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                  : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
              }`}
            >
              <span>{advanceNotice.message}</span>
              <button onClick={() => setAdvanceNotice(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>
          )}

          <form onSubmit={handleApplyAdvance} className="space-y-4 text-xs">
            <div>
              <label className="text-slate-300 font-medium block mb-1">
                Requested Advance Amount (₹)
              </label>
              <input
                type="number"
                min={5000}
                max={100000}
                value={emergencyAdvanceAmount}
                onChange={(e) => setEmergencyAdvanceAmount(parseInt(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white font-semibold focus:outline-none focus:border-indigo-500"
              />
              <p className="text-[11px] text-slate-500 mt-1">Capped at ₹1,00,000 per statutory BRD guidelines.</p>
            </div>

            <div>
              <label className="text-slate-300 font-medium block mb-1">
                Repayment Tenure (Months)
              </label>
              <select
                value={tenureMonths}
                onChange={(e) => setTenureMonths(parseInt(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-indigo-500"
              >
                <option value={3}>3 Months (₹{Math.round(emergencyAdvanceAmount / 3).toLocaleString('en-IN')}/mo)</option>
                <option value={6}>6 Months (₹{Math.round(emergencyAdvanceAmount / 6).toLocaleString('en-IN')}/mo)</option>
                <option value={9}>9 Months (₹{Math.round(emergencyAdvanceAmount / 9).toLocaleString('en-IN')}/mo)</option>
                <option value={12}>12 Months (₹{Math.round(emergencyAdvanceAmount / 12).toLocaleString('en-IN')}/mo)</option>
              </select>
            </div>

            <div>
              <label className="text-slate-300 font-medium block mb-1">
                Reason / Emergency Context
              </label>
              <textarea
                rows={3}
                value={advanceReason}
                onChange={(e) => setAdvanceReason(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-indigo-500"
                placeholder="State the urgency (medical, education, household emergency)..."
                required
              />
            </div>

            <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-[11px] text-slate-400 block">Monthly Payroll Auto-Deduction:</span>
                <span className="text-base font-bold text-amber-400">
                  ₹{Math.round(emergencyAdvanceAmount / tenureMonths).toLocaleString('en-IN')} / month
                </span>
              </div>
              <button
                type="submit"
                className="px-5 py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold rounded-xl transition shadow-lg shadow-amber-600/20"
              >
                Submit for Multi-Tier Approval
              </button>
            </div>
          </form>
        </div>
      )}

      {/* New Tour Request Modal */}
      {showNewTourModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white">Create Official Tour Authorization</h3>
              <button
                onClick={() => setShowNewTourModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateTour} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Destination City</label>
                <input
                  type="text"
                  value={tourForm.destination}
                  onChange={(e) => setTourForm({ ...tourForm, destination: e.target.value })}
                  placeholder="e.g. Mumbai / Bangalore / Lucknow"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">City Tier Category</label>
                <select
                  value={tourForm.cityTier}
                  onChange={(e) => setTourForm({ ...tourForm, cityTier: e.target.value as any })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white"
                >
                  <option value="TIER_1">Tier 1 - Metros (Delhi, Mumbai, Bengaluru)</option>
                  <option value="TIER_2">Tier 2 - State Capitals</option>
                  <option value="TIER_3">Tier 3 - Towns & Rural Districts</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Start Date</label>
                  <input
                    type="date"
                    value={tourForm.startDate}
                    onChange={(e) => setTourForm({ ...tourForm, startDate: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">End Date</label>
                  <input
                    type="date"
                    value={tourForm.endDate}
                    onChange={(e) => setTourForm({ ...tourForm, endDate: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Estimated Cost (₹)</label>
                  <input
                    type="number"
                    value={tourForm.estimatedCost}
                    onChange={(e) => setTourForm({ ...tourForm, estimatedCost: parseInt(e.target.value) || 0 })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Advance Needed (₹)</label>
                  <input
                    type="number"
                    value={tourForm.advanceRequested}
                    onChange={(e) => setTourForm({ ...tourForm, advanceRequested: parseInt(e.target.value) || 0 })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Purpose of Visit</label>
                <textarea
                  rows={2}
                  value={tourForm.purpose}
                  onChange={(e) => setTourForm({ ...tourForm, purpose: e.target.value })}
                  placeholder="State project, meeting, or partner stakeholder engagement..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewTourModal(false)}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg"
                >
                  Submit Tour Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
