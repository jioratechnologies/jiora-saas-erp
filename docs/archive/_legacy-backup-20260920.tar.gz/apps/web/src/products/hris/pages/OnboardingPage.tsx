import { useState, useEffect } from 'react';
import {
  UserCheck,
  CheckCircle2,
  Circle,
  Clock,
  Laptop,
  Shield,
  FileCheck,
  Award,
  AlertCircle,
  Plus,
} from 'lucide-react';
import { apiClient } from '@/api';
import { useAuth } from '@/context/AuthContext';
import { RecordChatter } from '@/shared/components/workspace/RecordChatter';
import { Badge } from '@/shared/components/ui/Badge';
import { Button } from '@/shared/components/ui/Button';

export default function OnboardingPage() {
  const { currentUser } = useAuth();
  const [checklists, setChecklists] = useState<any[]>([]);
  const [selectedCase, setSelectedCase] = useState<any | null>(null);

  const loadData = async () => {
    try {
      const res = await apiClient.getOnboarding(currentUser);
      if (res && res.success) {
        setChecklists(res.data || []);
        if (!selectedCase && res.data && res.data.length > 0) {
          setSelectedCase(res.data[0]);
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentUser]);

  const handleToggleTask = async (caseId: string, taskId: string, currentStatus: boolean) => {
    try {
      const res = await apiClient.updateOnboardingTask(caseId, taskId, !currentStatus, currentUser);
      if (res && res.success) {
        await loadData();
        if (selectedCase?.id === caseId) {
          setSelectedCase({
            ...selectedCase,
            tasks: selectedCase.tasks.map((t: any) =>
              t.id === taskId ? { ...t, completed: !currentStatus } : t
            ),
          });
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleConfirmProbation = async (caseId: string) => {
    try {
      const res = await apiClient.confirmProbation(caseId, currentUser);
      if (res && res.success) {
        await loadData();
        if (selectedCase?.id === caseId) {
          setSelectedCase({ ...selectedCase, probationStatus: 'CONFIRMED', confirmationLetterIssued: true });
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  const getDepartmentIcon = (dept: string) => {
    switch (dept) {
      case 'IT':
        return <Laptop className="w-4 h-4 text-blue-400" />;
      case 'ADMIN':
        return <Shield className="w-4 h-4 text-amber-400" />;
      default:
        return <FileCheck className="w-4 h-4 text-emerald-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-bold text-white tracking-tight">Onboarding, Induction & Probation</h1>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30 font-semibold">
              BRD Workflow #3
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Checklist-driven joining process across Standard, Intern, and Contractual joiners with 6-month probation tracking
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Checklist Cases */}
        <div className="lg:col-span-2 space-y-4">
          {checklists.map((item) => {
            const isSelected = selectedCase?.id === item.id;
            return (
              <div
                key={item.id}
                onClick={() => setSelectedCase(item)}
                className={`p-5 rounded-2xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-slate-900 border-indigo-500 shadow-xl shadow-indigo-600/10'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-white">{item.employeeName}</h3>
                      <Badge color="indigo" size="xs">
                        {item.employeeCategory}
                      </Badge>
                      <Badge color={item.probationStatus === 'CONFIRMED' ? 'emerald' : 'amber'} size="xs">
                        {item.probationStatus}
                      </Badge>
                    </div>
                    <p className="text-xs text-slate-400 mt-1">
                      {item.designation} • {item.department} • Probation until {item.probationEndDate || 'N/A'}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold text-indigo-400">{item.progressPercent}% Done</span>
                    <p className="text-[10px] text-slate-500">{item.completedTasks}/{item.totalTasks} Tasks</p>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-teal-500 to-indigo-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${item.progressPercent}%` }}
                  />
                </div>

                {/* Tasks List */}
                <div className="mt-4 pt-3 border-t border-slate-800/80 space-y-2">
                  {item.tasks.map((task: any) => (
                    <div
                      key={task.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleToggleTask(item.id, task.id, task.completed);
                      }}
                      className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/40 hover:bg-slate-800/50 border border-slate-800/60 text-xs transition"
                    >
                      <div className="flex items-center gap-3">
                        <button className="text-slate-400 hover:text-indigo-400">
                          {task.completed ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          ) : (
                            <Circle className="w-4 h-4 text-slate-500" />
                          )}
                        </button>
                        <span className={`font-medium ${task.completed ? 'line-through text-slate-500' : 'text-slate-200'}`}>
                          {task.task}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                        {getDepartmentIcon(task.department)}
                        <span>{task.department}</span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Probation Confirmation Button */}
                {item.probationStatus !== 'CONFIRMED' && (
                  <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                    <span className="text-[11px] text-slate-400">
                      Standard 6-Month Probation Review Cycle
                    </span>
                    <Button
                      intent="primary"
                      size="xs"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleConfirmProbation(item.id);
                      }}
                    >
                      Issue President Confirmation Letter
                    </Button>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Right 1 Col: Record Chatter */}
        <div className="lg:col-span-1 h-[650px]">
          {selectedCase ? (
            <RecordChatter
              recordType="onboarding"
              recordId={selectedCase.id}
              recordTitle={`Onboarding: ${selectedCase.employeeName}`}
            />
          ) : (
            <div className="h-full rounded-2xl border border-slate-800 bg-slate-900/40 flex items-center justify-center text-slate-500 text-xs">
              Select an onboarding case to view discussion & audit history
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
