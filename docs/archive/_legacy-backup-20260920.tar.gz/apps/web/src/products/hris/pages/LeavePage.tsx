import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useUiStore } from '@/platform/state/uiStore';
import { apiClient } from '@/api';
import {
  Calendar,
  CheckCircle2,
  Clock,
  ShieldCheck,
  PlusCircle,
  AlertCircle,
  FileText,
} from 'lucide-react';
import { Button } from '@/shared/components/ui/Button';
import { Badge } from '@/shared/components/ui/Badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/shared/components/ui/Dialog';

export default function LeavePage() {
  const { currentUser } = useAuth();
  const addNotification = useUiStore((s) => s.addNotification);
  const refreshKey = useUiStore((s) => s.refreshKey);
  const [balances, setBalances] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState<string | null>(null);

  // Form State
  const [leaveType, setLeaveType] = useState('CASUAL_LEAVE');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [days, setDays] = useState(1);
  const [reason, setReason] = useState('');

  useEffect(() => {
    fetchBalances();
  }, [currentUser, refreshKey]);

  const fetchBalances = async () => {
    try {
      setLoading(true);
      const res = await apiClient.getLeaveBalances(currentUser);
      if (res.success) {
        setBalances(res.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleApply = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await apiClient.applyLeave(
        {
          leaveType,
          startDate,
          endDate,
          days: Number(days),
          reason,
          documentUrl: leaveType.includes('MATERNITY') ? '/docs/medical_cert.pdf' : undefined,
        },
        currentUser
      );

      if (res.success) {
        setSubmitSuccess(res.message);
        addNotification({
          type: 'success',
          title: 'Leave Request Created',
          message: res.message,
        });
        setShowModal(false);
        setReason('');
        setTimeout(() => setSubmitSuccess(null), 6000);
        fetchBalances();
      } else {
        addNotification({
          type: 'error',
          title: 'Application Error',
          message: res.message,
        });
      }
    } catch (err: any) {
      addNotification({
        type: 'error',
        title: 'Error',
        message: err.message || 'Error applying for leave',
      });
    }
  };

  const leaveCards = [
    {
      title: 'Casual Leave (CL)',
      quota: 10,
      used: balances?.casualLeave?.used ?? 0,
      remaining: balances?.casualLeave?.remaining ?? (loading ? '-' : 10),
      rule: 'No carryover. Approver: Reporting Manager.',
      color: 'from-blue-500/15 to-indigo-500/15 border-blue-500/30',
    },
    {
      title: 'Sick Leave (SL)',
      quota: 10,
      used: balances?.sickLeave?.used ?? 0,
      remaining: balances?.sickLeave?.remaining ?? (loading ? '-' : 10),
      rule: 'No carryover. Approver: Reporting Manager.',
      color: 'from-emerald-500/15 to-teal-500/15 border-emerald-500/30',
    },
    {
      title: 'Earned Leave (EL)',
      quota: 15,
      used: balances?.earnedLeave?.used ?? 0,
      remaining: balances?.earnedLeave?.remaining ?? (loading ? '-' : 15),
      carryForward: balances?.earnedLeave?.carryForward ?? 0,
      rule: 'Carryover max 30d. Min 6mo service & 15d notice required.',
      color: 'from-purple-500/15 to-fuchsia-500/15 border-purple-500/30',
    },
    {
      title: 'Maternity Benefit (ML)',
      quota: 182,
      used: balances?.maternityLeave?.used ?? 0,
      remaining: balances?.maternityLeave?.remaining ?? (loading ? '-' : 182),
      rule: '26 Weeks Paid (Maternity Benefit Act 2017). Sign-off: Mgr → HR → President.',
      color: 'from-rose-500/15 to-pink-500/15 border-rose-500/30',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>Leave Entitlements & Balance Ledger</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Maternity Benefit Act 2017 Ready
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Statutory leave rules, approval state machines and accrual engines
          </p>
        </div>

        <Button
          intent="primary"
          size="md"
          onClick={() => setShowModal(true)}
        >
          <PlusCircle className="w-4 h-4 mr-1.5" />
          Apply for Leave
        </Button>
      </div>

      {submitSuccess && (
        <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-fade-in-up">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{submitSuccess}</span>
        </div>
      )}

      {/* 4 Cards for Main Leave Balances */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {leaveCards.map((card, idx) => (
          <div
            key={idx}
            className={`p-5 rounded-2xl glass-card border bg-gradient-to-br ${card.color} space-y-3`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">{card.title}</span>
              <span className="text-[10px] text-slate-400 font-mono">
                Used: {card.used} / {card.quota}
              </span>
            </div>

            <div className="flex items-baseline gap-2">
              <div className="text-3xl font-extrabold text-white font-mono">
                {card.remaining}
              </div>
              <span className="text-xs text-slate-400">days available</span>
            </div>

            <div className="text-[10px] text-slate-400 pt-2 border-t border-slate-800/80 leading-relaxed">
              {card.rule}
            </div>
          </div>
        ))}
      </div>

      {/* Special Statutory Leave Details */}
      <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Special & Statutory Leave Categories (Indian Labour Code)</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
            <Badge color="indigo" variant="soft" size="xs">
              Maternity Leave (26 Weeks)
            </Badge>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              Up to 26 weeks paid leave for female employees for first 2 surviving children. Multi-level approval: Reporting Manager → HR Head → President.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
            <Badge color="emerald" variant="soft" size="xs">
              Paternity & Adoption (5 Days)
            </Badge>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              5 days granted upon childbirth or legal adoption of a child under 1 year of age. Requires manager verification and HR concurrence.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
            <Badge color="rose" variant="soft" size="xs">
              Compensatory Off & LWP
            </Badge>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              Compensatory Off for authorized weekend or holiday duty (must be availed within 30 days). Leave Without Pay (LWP) requires President sign-off.
            </p>
          </div>
        </div>
      </div>

      {/* Application Dialog Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent size="md">
          <DialogHeader>
            <DialogTitle>Submit Leave Application</DialogTitle>
            <DialogDescription>
              Leaves are routed through approval matrices according to the Sachhi Saheli BRD.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleApply} className="space-y-4 mt-2">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Leave Category</label>
              <select
                value={leaveType}
                onChange={(e) => setLeaveType(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="CASUAL_LEAVE">Casual Leave (CL)</option>
                <option value="SICK_LEAVE">Sick Leave (SL)</option>
                <option value="EARNED_LEAVE">Earned Leave (EL - 15d notice)</option>
                <option value="MATERNITY_LEAVE">Maternity Leave (26 Weeks - Manager → HR → President)</option>
                <option value="PATERNITY_LEAVE">Paternity Leave (5 Days)</option>
                <option value="COMPENSATORY_OFF">Compensatory Off (Weekend duty)</option>
                <option value="LEAVE_WITHOUT_PAY">Leave Without Pay (LWP)</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Start Date</label>
                <input
                  type="date"
                  required
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">End Date</label>
                <input
                  type="date"
                  required
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Total Days</label>
              <input
                type="number"
                min="0.5"
                step="0.5"
                required
                value={days}
                onChange={(e) => setDays(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Detailed Reason</label>
              <textarea
                required
                rows={3}
                placeholder="Specify reason for absence..."
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-indigo-500 placeholder-slate-500"
              />
            </div>

            <DialogFooter>
              <Button intent="secondary" size="sm" type="button" onClick={() => setShowModal(false)}>
                Cancel
              </Button>
              <Button intent="primary" size="sm" type="submit">
                Submit for Approval
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
