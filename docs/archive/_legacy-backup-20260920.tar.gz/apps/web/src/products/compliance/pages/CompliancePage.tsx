import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { apiClient } from '@/api';
import {
  ShieldAlert,
  Calculator,
  CheckCircle2,
  Clock,
  FileText,
  Lock,
  History,
} from 'lucide-react';
import { Badge } from '@/shared/components/ui/Badge';

export default function CompliancePage() {
  const { currentUser } = useAuth();
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Gratuity Calculator State
  const [gratuityBasic, setGratuityBasic] = useState(30000);
  const [gratuityTenure, setGratuityTenure] = useState(5.5);
  const [gratuityResult, setGratuityResult] = useState<any>(null);

  // PF Calculator State
  const [pfBasic, setPfBasic] = useState(25000);
  const [pfResult, setPfResult] = useState<any>(null);

  useEffect(() => {
    fetchAuditLogs();
    calculateGratuity(30000, 5.5);
    calculatePF(25000);
  }, [currentUser]);

  const fetchAuditLogs = async () => {
    try {
      setLoading(true);
      const res = await apiClient.getAuditLogs(currentUser);
      if (res.success) {
        setAuditLogs(res.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const calculateGratuity = async (basic: number, tenure: number) => {
    const res = await apiClient.calculateGratuity(basic, tenure);
    setGratuityResult(res);
  };

  const calculatePF = async (basic: number) => {
    const res = await apiClient.calculatePF(basic);
    setPfResult(res);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
          <span>Indian Statutory Labour Law & Audit Vault</span>
          <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
            6+ Years Immutable Retention
          </span>
        </h2>
        <p className="text-xs text-slate-400">
          Payment of Gratuity Act 1972, EPF Act 1952, Maternity Benefit Act 2017 & Immutable Audit Ledger
        </p>
      </div>

      {/* Two Interactive Calculators */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Gratuity Calculator */}
        <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
          <div className="flex items-center gap-2">
            <Calculator className="w-5 h-5 text-indigo-400" />
            <h3 className="text-sm font-bold text-white">Payment of Gratuity Act, 1972 Calculator</h3>
          </div>

          <p className="text-xs text-slate-400">
            Formula: <code className="text-indigo-300 font-mono">(15 × Last Drawn Basic × Completed Years) ÷ 26</code>
          </p>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">Last Drawn Basic (₹/month)</label>
              <input
                type="number"
                value={gratuityBasic}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setGratuityBasic(val);
                  calculateGratuity(val, gratuityTenure);
                }}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono"
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Tenure in Years</label>
              <input
                type="number"
                step="0.1"
                value={gratuityTenure}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setGratuityTenure(val);
                  calculateGratuity(gratuityBasic, val);
                }}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono"
              />
            </div>
          </div>

          {gratuityResult && (
            <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Statutory Eligibility:</span>
                <Badge color={gratuityResult.eligible ? 'emerald' : 'rose'} variant="soft" size="xs">
                  {gratuityResult.eligible ? 'ELIGIBLE (>= 5 Yrs Service)' : 'NOT ELIGIBLE (< 5 Yrs)'}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Calculated Gratuity Payable:</span>
                <span className="text-xl font-bold font-mono text-emerald-400">
                  ₹ {gratuityResult.gratuityPayable?.toLocaleString('en-IN')}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* PF Calculator */}
        <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
          <div className="flex items-center gap-2">
            <Calculator className="w-5 h-5 text-blue-400" />
            <h3 className="text-sm font-bold text-white">EPF & MP Act, 1952 Calculator (12% + 12%)</h3>
          </div>

          <p className="text-xs text-slate-400">
            Mandatory deduction: 12% Employee Contribution + 12% Employer Contribution on Basic + DA.
          </p>

          <div className="text-xs">
            <label className="text-slate-400 block mb-1">Basic Salary (₹/month)</label>
            <input
              type="number"
              value={pfBasic}
              onChange={(e) => {
                const val = Number(e.target.value);
                setPfBasic(val);
                calculatePF(val);
              }}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono"
            />
          </div>

          {pfResult && (
            <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2 text-xs">
              <div className="grid grid-cols-2 gap-2 pb-2 border-b border-slate-800">
                <div>
                  <span className="text-slate-400 text-[10px] block">12% Employee EPF</span>
                  <span className="text-sm font-bold font-mono text-blue-300">
                    ₹ {pfResult.employeePF?.toLocaleString('en-IN')}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">12% Employer Total</span>
                  <span className="text-sm font-bold font-mono text-indigo-300">
                    ₹ {pfResult.employerTotal?.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>
              <div className="flex justify-between items-center text-[11px] text-slate-400">
                <span>Employer EPS Allocation (8.33% capped @ ₹1,250):</span>
                <span className="font-mono text-slate-200">₹ {pfResult.employerEPS}</span>
              </div>
              <div className="flex justify-between items-center text-[11px] text-slate-400">
                <span>Employer EPF Remittance (3.67%):</span>
                <span className="font-mono text-slate-200">₹ {pfResult.employerEPF}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 6+ Year Immutable Audit Trail */}
      <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-purple-400" />
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Statutory Audit Vault (Immutable 6+ Year Retention)
            </h3>
          </div>
          <Badge color="purple" variant="soft" size="xs">
            Tamper-Proof Ledger
          </Badge>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left text-slate-300">
            <thead className="text-[11px] uppercase bg-slate-950/60 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-4">Timestamp (IST)</th>
                <th className="py-2.5 px-4">Event Category</th>
                <th className="py-2.5 px-4">Actor</th>
                <th className="py-2.5 px-4">Action Summary</th>
                <th className="py-2.5 px-4">Cryptographic Hash</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
              {auditLogs.map((log: any) => (
                <tr key={log.id} className="hover:bg-slate-800/30">
                  <td className="py-2.5 px-4 text-slate-400">{new Date(log.timestamp).toLocaleString()}</td>
                  <td className="py-2.5 px-4 font-sans font-semibold text-indigo-300">{log.category}</td>
                  <td className="py-2.5 px-4 font-sans text-white">{log.actor}</td>
                  <td className="py-2.5 px-4 font-sans text-slate-300">{log.action}</td>
                  <td className="py-2.5 px-4 text-slate-500">{log.hash || 'sha256:7f8a91c0e3b...'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
