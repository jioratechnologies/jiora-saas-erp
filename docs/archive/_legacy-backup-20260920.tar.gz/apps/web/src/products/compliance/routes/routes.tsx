import { lazy } from 'react';
import type { RouteObject } from 'react-router-dom';
import { page } from '@/platform/routing/page';

const CompliancePage = lazy(() => import('../pages/CompliancePage'));

export const complianceRoutes: RouteObject[] = [
  { path: 'compliance', element: page('Statutory Compliance & Legal Vault', <CompliancePage />) },
];
