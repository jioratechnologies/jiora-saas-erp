import React, { useState, useEffect } from 'react';
import {
  Network,
  Users,
  ChevronDown,
  ChevronRight,
  Mail,
  Shield,
  Briefcase,
  Building,
  UserCheck,
} from 'lucide-react';
import { apiClient } from '@/api';
import { useAuth } from '@/context/AuthContext';

interface OrgNode {
  id: string;
  name: string;
  role: string;
  designation: string;
  department: string;
  email: string;
  avatar?: string;
  reports?: OrgNode[];
}

const DEFAULT_ORG_TREE: OrgNode = {
  id: 'EMP-DEL-001',
  name: 'Pooja Sharma',
  role: 'PRESIDENT',
  designation: 'President & Executive Director',
  department: 'Executive Governance',
  email: 'president@sachhisaheli.org',
  reports: [
    {
      id: 'EMP-DEL-002',
      name: 'Dr. Ananya Roy',
      role: 'HR',
      designation: 'Head of Human Resources',
      department: 'HR & People Operations',
      email: 'hr.head@sachhisaheli.org',
      reports: [
        {
          id: 'EMP-DEL-005',
          name: 'Priya Mehra',
          role: 'HR',
          designation: 'Talent Acquisition & Compliance Officer',
          department: 'HR & People Operations',
          email: 'priya.hr@sachhisaheli.org',
        },
        {
          id: 'EMP-DEL-006',
          name: 'Sunil Verma',
          role: 'EMPLOYEE',
          designation: 'Onboarding & Induction Associate',
          department: 'HR & People Operations',
          email: 'sunil.v@sachhisaheli.org',
        },
      ],
    },
    {
      id: 'EMP-DEL-003',
      name: 'Rajesh Malhotra',
      role: 'FINANCE',
      designation: 'Chief Financial Officer & Comptroller',
      department: 'Finance & Treasury',
      email: 'finance.head@sachhisaheli.org',
      reports: [
        {
          id: 'EMP-DEL-007',
          name: 'Neha Kapoor',
          role: 'EMPLOYEE',
          designation: 'Senior Statutory & Payroll Accountant',
          department: 'Finance & Treasury',
          email: 'neha.k@sachhisaheli.org',
        },
      ],
    },
    {
      id: 'EMP-DEL-004',
      name: 'Vikram Singh',
      role: 'MANAGER',
      designation: 'Director of Programs & Operations',
      department: 'Programs & Delivery',
      email: 'ops.head@sachhisaheli.org',
      reports: [
        {
          id: 'EMP-DEL-008',
          name: 'Kavita Das',
          role: 'EMPLOYEE',
          designation: 'District Program Coordinator',
          department: 'Programs & Delivery',
          email: 'kavita.d@sachhisaheli.org',
        },
        {
          id: 'EMP-DEL-009',
          name: 'Amit Joshi',
          role: 'EMPLOYEE',
          designation: 'Field Monitoring & Evaluation Lead',
          department: 'Programs & Delivery',
          email: 'amit.j@sachhisaheli.org',
        },
      ],
    },
  ],
};

function OrgCard({ node, level = 0 }: { node: OrgNode; level?: number }) {
  const [collapsed, setCollapsed] = useState(false);
  const hasReports = node.reports && node.reports.length > 0;

  const roleColors: Record<string, { badge: string; border: string }> = {
    PRESIDENT: { badge: 'bg-purple-500/20 text-purple-300', border: 'border-purple-500/40' },
    HR: { badge: 'bg-indigo-500/20 text-indigo-300', border: 'border-indigo-500/40' },
    FINANCE: { badge: 'bg-emerald-500/20 text-emerald-300', border: 'border-emerald-500/40' },
    MANAGER: { badge: 'bg-amber-500/20 text-amber-300', border: 'border-amber-500/40' },
    EMPLOYEE: { badge: 'bg-slate-700 text-slate-300', border: 'border-slate-800' },
  };

  const style = roleColors[node.role] || roleColors.EMPLOYEE;

  return (
    <div className="flex flex-col items-center">
      {/* Node Box */}
      <div
        className={`w-64 bg-slate-900/90 border ${style.border} rounded-2xl p-4 shadow-xl backdrop-blur-md relative hover:scale-102 transition-transform duration-200`}
      >
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-slate-800 to-slate-700 flex items-center justify-center font-bold text-white text-sm shadow-inner">
              {node.name.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <h4 className="text-xs font-bold text-white tracking-tight">{node.name}</h4>
              <p className="text-[10px] text-slate-400 leading-tight line-clamp-1">{node.designation}</p>
            </div>
          </div>
          <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase ${style.badge}`}>
            {node.role}
          </span>
        </div>

        <div className="mt-3 pt-2.5 border-t border-slate-800/80 space-y-1 text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5 truncate">
            <Building className="w-3 h-3 text-slate-500 flex-shrink-0" />
            <span className="truncate">{node.department}</span>
          </div>
          <div className="flex items-center gap-1.5 truncate">
            <Mail className="w-3 h-3 text-slate-500 flex-shrink-0" />
            <span className="truncate">{node.email}</span>
          </div>
        </div>

        {hasReports && (
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="mt-3 w-full flex items-center justify-center gap-1 py-1 rounded-lg bg-slate-950/60 border border-slate-800 text-[10px] text-slate-300 hover:text-white hover:bg-slate-800 transition"
          >
            {collapsed ? <ChevronRight className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            {node.reports!.length} Direct {node.reports!.length === 1 ? 'Report' : 'Reports'}
          </button>
        )}
      </div>

      {/* Children Tree */}
      {hasReports && !collapsed && (
        <div className="flex flex-col items-center">
          {/* Vertical stem */}
          <div className="w-px h-6 bg-slate-700" />

          {/* Horizontal crossbar if multiple children */}
          <div className="relative flex justify-center">
            {node.reports!.length > 1 && (
              <div
                className="absolute top-0 h-px bg-slate-700"
                style={{
                  left: '132px',
                  right: '132px',
                }}
              />
            )}

            <div className="flex gap-8">
              {node.reports!.map((child) => (
                <div key={child.id} className="flex flex-col items-center">
                  <div className="w-px h-6 bg-slate-700" />
                  <OrgCard node={child} level={level + 1} />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function OrgChartPage() {
  const { currentUser } = useAuth();
  const [selectedDept, setSelectedDept] = useState<string>('ALL');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900/60 p-6 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
            <Network className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight">Enterprise Organization Chart</h1>
            <p className="text-xs text-slate-400">
              Interactive structural hierarchy, reporting lines & departmental governance
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Filter Department:</span>
          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
          >
            <option value="ALL">All Departments</option>
            <option value="HR & People Operations">HR & People Operations</option>
            <option value="Finance & Treasury">Finance & Treasury</option>
            <option value="Programs & Delivery">Programs & Delivery</option>
          </select>
        </div>
      </div>

      {/* Interactive Org Chart Canvas */}
      <div className="bg-slate-950/60 border border-slate-800 rounded-3xl p-8 overflow-x-auto min-h-[600px] flex justify-center items-start shadow-2xl">
        <div className="py-4">
          <OrgCard node={DEFAULT_ORG_TREE} />
        </div>
      </div>
    </div>
  );
}
