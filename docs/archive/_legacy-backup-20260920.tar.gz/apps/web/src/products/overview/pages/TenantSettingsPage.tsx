import React, { useState, useEffect } from 'react';
import {
  Palette,
  Building2,
  Globe,
  Sparkles,
  Save,
  CheckCircle2,
  RefreshCw,
  ShieldAlert,
  Layers,
  Eye,
  Sliders,
} from 'lucide-react';
import { useTenantBranding } from '@/context/TenantBrandingContext';
import { apiClient } from '@/api';
import { useAuth } from '@/context/AuthContext';

export default function TenantSettingsPage() {
  const { tenantConfig, activeTenantId, switchTenant, updateBranding, allTenants, loading } = useTenantBranding();
  const { currentUser } = useAuth();

  const [form, setForm] = useState({
    name: '',
    tagline: '',
    logoUrl: '',
    primaryColor: '#6366f1',
    accentColor: '#f43f5e',
    currency: 'INR',
    locale: 'en-IN',
  });

  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  useEffect(() => {
    if (tenantConfig) {
      setForm({
        name: tenantConfig.name || '',
        tagline: tenantConfig.tagline || '',
        logoUrl: tenantConfig.logoUrl || '',
        primaryColor: tenantConfig.primaryColor || '#6366f1',
        accentColor: tenantConfig.accentColor || '#f43f5e',
        currency: tenantConfig.currency || 'INR',
        locale: tenantConfig.locale || 'en-IN',
      });
    }
  }, [tenantConfig]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSaving(true);
      await updateBranding(form);
      setSuccessMsg('Tenant branding updated! CSS variables and UI refreshed in real-time.');
      setTimeout(() => setSuccessMsg(null), 4000);
    } catch (err: any) {
      console.error('Failed to update tenant branding:', err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900/60 p-6 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
            <Palette className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight">Tenant Whitelabeling & Branding</h1>
            <p className="text-xs text-slate-400">
              Customize logos, system nomenclature, primary/accent palettes, and statutory currencies per client organization
            </p>
          </div>
        </div>

        {/* Tenant Switcher Pill */}
        <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800 text-xs">
          <Building2 className="w-4 h-4 text-slate-400 ml-2" />
          <span className="text-slate-400 font-medium">Active Organization:</span>
          <select
            value={activeTenantId}
            onChange={(e) => switchTenant(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-indigo-300 font-semibold rounded-lg px-2.5 py-1 focus:outline-none cursor-pointer"
          >
            {allTenants.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name} ({t.id})
              </option>
            ))}
          </select>
        </div>
      </div>

      {successMsg && (
        <div className="p-3 bg-emerald-500/15 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Main 2-Column Grid: Form & Real-time Live Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Branding Form */}
        <div className="lg:col-span-7 bg-slate-900/60 border border-slate-800 rounded-2xl p-6">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-300 mb-4 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-indigo-400" />
            Brand Configuration Parameters
          </h3>

          <form onSubmit={handleSave} className="space-y-4 text-xs">
            <div>
              <label className="text-slate-300 font-medium block mb-1">Organization / Brand Name</label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white font-medium focus:outline-none focus:border-indigo-500"
                required
              />
            </div>

            <div>
              <label className="text-slate-300 font-medium block mb-1">Tagline / Subhead</label>
              <input
                type="text"
                value={form.tagline}
                onChange={(e) => setForm({ ...form, tagline: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white font-medium focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="text-slate-300 font-medium block mb-1">Logo URL or Emoji Icon</label>
              <input
                type="text"
                value={form.logoUrl}
                onChange={(e) => setForm({ ...form, logoUrl: e.target.value })}
                placeholder="e.g. 🌸 or https://storage.minio/..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white font-medium focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-slate-300 font-medium block mb-1">Primary Color (Hex)</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={form.primaryColor}
                    onChange={(e) => setForm({ ...form, primaryColor: e.target.value })}
                    className="w-10 h-10 rounded-xl border border-slate-700 bg-transparent cursor-pointer p-0.5"
                  />
                  <input
                    type="text"
                    value={form.primaryColor}
                    onChange={(e) => setForm({ ...form, primaryColor: e.target.value })}
                    className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-medium block mb-1">Accent / Highlight Color</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={form.accentColor}
                    onChange={(e) => setForm({ ...form, accentColor: e.target.value })}
                    className="w-10 h-10 rounded-xl border border-slate-700 bg-transparent cursor-pointer p-0.5"
                  />
                  <input
                    type="text"
                    value={form.accentColor}
                    onChange={(e) => setForm({ ...form, accentColor: e.target.value })}
                    className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-slate-300 font-medium block mb-1">Statutory Currency</label>
                <select
                  value={form.currency}
                  onChange={(e) => setForm({ ...form, currency: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
                >
                  <option value="INR">INR (₹ - Indian Rupee)</option>
                  <option value="USD">USD ($ - US Dollar)</option>
                  <option value="EUR">EUR (€ - Euro)</option>
                  <option value="GBP">GBP (£ - British Pound)</option>
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-medium block mb-1">Locale Formatting</label>
                <select
                  value={form.locale}
                  onChange={(e) => setForm({ ...form, locale: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
                >
                  <option value="en-IN">en-IN (Lakhs & Crores)</option>
                  <option value="en-US">en-US (Millions & Billions)</option>
                  <option value="en-GB">en-GB (International)</option>
                </select>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex justify-end">
              <button
                type="submit"
                disabled={saving}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl transition flex items-center gap-2 shadow-lg shadow-indigo-600/20"
              >
                <Save className="w-4 h-4" />
                {saving ? 'Applying...' : 'Save & Publish Tenant Branding'}
              </button>
            </div>
          </form>
        </div>

        {/* Right: Live Preview Panel */}
        <div className="lg:col-span-5 space-y-4">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-2">
            <Eye className="w-4 h-4 text-emerald-400" />
            Live Client Shell Preview
          </h3>

          {/* Simulated App Header Card */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center text-lg shadow-lg"
                style={{ backgroundColor: form.primaryColor }}
              >
                {form.logoUrl.length <= 4 ? form.logoUrl || '🏢' : '🌸'}
              </div>
              <div>
                <h4 className="text-sm font-bold text-white tracking-wide">{form.name || 'Organization Name'}</h4>
                <p className="text-[11px] text-slate-400">{form.tagline || 'Enterprise ERP Suite'}</p>
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between text-slate-400">
                <span>Primary Color Token:</span>
                <span className="font-mono text-white flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: form.primaryColor }} />
                  {form.primaryColor}
                </span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>Accent Color Token:</span>
                <span className="font-mono text-white flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: form.accentColor }} />
                  {form.accentColor}
                </span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>Currency Display:</span>
                <span className="font-semibold text-emerald-400">
                  {form.currency === 'INR' ? '₹ 1,50,000' : '$ 2,000'}
                </span>
              </div>
            </div>

            {/* Simulated Button in Tenant Colors */}
            <div className="pt-2 flex gap-2">
              <button
                className="flex-1 py-2 text-white font-semibold rounded-lg text-xs transition shadow-md"
                style={{ backgroundColor: form.primaryColor }}
              >
                Primary Tenant Action
              </button>
              <button
                className="px-3 py-2 text-white font-semibold rounded-lg text-xs"
                style={{ backgroundColor: form.accentColor }}
              >
                Accent Pill
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
