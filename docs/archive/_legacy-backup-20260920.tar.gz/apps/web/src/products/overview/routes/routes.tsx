import { lazy } from 'react';
import type { RouteObject } from 'react-router-dom';
import { page } from '@/platform/routing/page';

const OverviewPage = lazy(() => import('../pages/OverviewPage'));
const OrgChartPage = lazy(() => import('../pages/OrgChartPage'));
const TenantSettingsPage = lazy(() => import('../pages/TenantSettingsPage'));

export const overviewRoutes: RouteObject[] = [
  { index: true, element: page('Executive Overview', <OverviewPage />) },
  { path: 'org-chart', element: page('Enterprise Org Chart', <OrgChartPage />) },
  { path: 'tenant-settings', element: page('Tenant Whitelabeling', <TenantSettingsPage />) },
];
