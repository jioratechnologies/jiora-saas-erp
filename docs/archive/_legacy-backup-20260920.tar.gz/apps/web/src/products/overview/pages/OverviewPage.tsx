import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { useUiStore } from '@/platform/state/uiStore';
import { apiClient } from '@/api';
import {
  Users,
  Banknote,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Sparkles,
  ArrowUpRight,
  ChevronRight,
} from 'lucide-react';

export default function OverviewPage() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const refreshKey = useUiStore((s) => s.refreshKey);
  const [pendingCount, setPendingCount] = useState<number>(0);
  const [headcount, setHeadcount] = useState<number>(0);
  const [probationCount, setProbationCount] = useState<number>(0);
  const [payrollGross, setPayrollGross] = useState<number>(0);
  const [recentWorkflows, setRecentWorkflows] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    if (!currentUser) return;
    setLoading(true);

    Promise.all([
      apiClient.getInbox(currentUser).catch(() => ({ success: false, count: 0 })),
      apiClient.getEmployees(currentUser).catch(() => ({ success: false, data: [] })),
      apiClient.getPayrollSummary(currentUser).catch(() => ({ success: false, totalGrossDisbursement: 0 })),
      apiClient.getWorkflows(currentUser).catch(() => ({ success: false, data: [] })),
    ])
      .then(([inboxRes, empRes, payRes, wfRes]) => {
        if (inboxRes && inboxRes.success) setPendingCount(inboxRes.count || 0);
        
        if (empRes && empRes.success && Array.isArray(empRes.data)) {
          setHeadcount(empRes.data.length);
          const inProb = empRes.data.filter(
            (e: any) => e.profile?.jobDetails?.probationStatus === 'IN_PROBATION'
          ).length;
          setProbationCount(inProb);
        }

        if (payRes && payRes.success) {
          setPayrollGross(payRes.totalGrossDisbursement || 0);
        }

        if (wfRes && wfRes.success && Array.isArray(wfRes.data)) {
          setRecentWorkflows(wfRes.data.slice(0, 3));
        }
      })
      .finally(() => setLoading(false));
  }, [currentUser, refreshKey]);

  const kpis = [
    {
      title: 'Active Headcount',
      value: loading ? '...' : `${headcount} Personnel`,
      subtext: `${probationCount} In Probation`,
      icon: Users,
      trend: 'From Database',
      gradient: 'from-blue-500/15 to-indigo-500/15',
      border: 'border-blue-500/30',
      iconColor: 'text-blue-400',
    },
    {
      title: 'Monthly Payroll Run',
      value: loading ? '...' : `₹ ${payrollGross.toLocaleString('en-IN')}`,
      subtext: '100% PF & Tax Reconciled',
      icon: Banknote,
      trend: 'Disbursed by 5th',
      gradient: 'from-emerald-500/15 to-teal-500/15',
      border: 'border-emerald-500/30',
      iconColor: 'text-emerald-400',
    },
    {
      title: 'Pending Workflows',
      value: loading ? '...' : `${pendingCount} Items`,
      subtext: 'Requires Your Role Sign-off',
      icon: Clock,
      trend: pendingCount > 0 ? 'Action Required' : 'All Clear',
      gradient: 'from-amber-500/15 to-orange-500/15',
      border: 'border-amber-500/30',
      iconColor: 'text-amber-400',
    },
    {
      title: 'Statutory Compliance',
      value: '100% Audit Ready',
      subtext: 'Gratuity, PF, POSH, Retained 6+ Yrs',
      icon: ShieldCheck,
      trend: 'Compliant',
      gradient: 'from-purple-500/15 to-fuchsia-500/15',
      border: 'border-purple-500/30',
      iconColor: 'text-purple-400',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Hero Banner with subtle gradient and glass styling */}
      <div className="relative overflow-hidden rounded-3xl p-6 sm:p-8 bg-gradient-to-r from-indigo-950/70 via-slate-900/90 to-purple-950/70 border border-indigo-500/20 shadow-2xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>Sachhi Saheli HRIS & Enterprise ERP v2.0</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              Welcome back, {currentUser?.name}
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Serving in role <span className="font-semibold text-indigo-300">{currentUser?.role}</span> ({currentUser?.designation}) in the <span className="text-slate-200">{currentUser?.department}</span> department. The ERP is operating under Modular Monolith standards with full statutory compliance.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => navigate('/hris/attendance')}
              className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-lg shadow-indigo-600/30 transition flex items-center gap-2 cursor-pointer"
            >
              <Clock className="w-4 h-4" />
              <span>Digital Punch In / Out</span>
            </button>
            <button
              onClick={() => navigate('/hris/leave')}
              className="px-4 py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-slate-200 text-xs font-semibold transition flex items-center gap-2 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Apply Leave</span>
            </button>
          </div>
        </div>

        {/* Ambient Glow Graphic */}
        <div className="absolute top-0 right-0 -mr-24 -mt-24 w-96 h-96 rounded-full bg-indigo-600/15 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-24 w-64 h-64 rounded-full bg-rose-500/10 blur-3xl pointer-events-none" />
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi, idx) => {
          const Icon = kpi.icon;
          return (
            <div
              key={idx}
              className={`p-5 rounded-2xl glass-card border ${kpi.border} bg-gradient-to-br ${kpi.gradient} relative overflow-hidden`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-medium text-slate-400">{kpi.title}</span>
                <div className={`p-2 rounded-xl bg-slate-900/60 border border-slate-700/50 ${kpi.iconColor}`}>
                  <Icon className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-bold tracking-tight text-white mb-1">
                {kpi.value}
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 text-[11px]">{kpi.subtext}</span>
                <span className="text-indigo-300 font-medium text-[11px] flex items-center gap-0.5">
                  {kpi.trend}
                  <ArrowUpRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Two Column Layout: Quick Actions & Workflow Highlights */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Approvals Spotlight (2 Columns) */}
        <div className="lg:col-span-2 glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>Active 16-Workflow Pipeline</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  BRD Enforced
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Multi-level approval state machines (Employee → Manager → HR → Finance → President)
              </p>
            </div>
            <button
              onClick={() => navigate('/workflows')}
              className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 transition"
            >
              <span>View All</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3 pt-2">
            {recentWorkflows.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-500 rounded-2xl bg-slate-900/40 border border-slate-800/60">
                No active workflows pending approval.
              </div>
            ) : (
              recentWorkflows.map((wf) => (
                <div
                  key={wf.id}
                  onClick={() => navigate('/workflows')}
                  className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800/80 hover:border-indigo-500/40 transition cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/30 font-mono text-[10px]">
                        {wf.workflowType}
                      </span>
                      <span className="text-sm font-semibold text-white">
                        {wf.title} — {wf.requesterName}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400">
                      Current Stage: <span className="text-amber-400 font-medium">{wf.currentStage?.replace('_', ' ')}</span> ({wf.department})
                    </p>
                  </div>
                  <span className="text-xs px-3 py-1 rounded-lg bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 shrink-0 self-start sm:self-center">
                    Review Stage
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Indian Statutory Compliance Guard (1 Column) */}
        <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Statutory Engine</h3>
              <p className="text-[11px] text-slate-400">Indian Labour Law Rules</p>
            </div>
          </div>

          <div className="space-y-2.5 text-xs text-slate-300">
            <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="font-semibold text-white text-[11px] mb-0.5">Payment of Gratuity Act, 1972</div>
              <p className="text-[10px] text-slate-400">
                Formula: (15 × Basic × Tenure) ÷ 26. Enforced for &gt;= 5 years of service.
              </p>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="font-semibold text-white text-[11px] mb-0.5">EPF & MP Act, 1952</div>
              <p className="text-[10px] text-slate-400">
                12% Employee + 12% Employer on Basic + DA with EPS remittance.
              </p>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="font-semibold text-white text-[11px] mb-0.5">Attendance & Lateness Cap</div>
              <p className="text-[10px] text-slate-400">
                &gt;10:00 AM flagged. 3rd lateness automatically deducts half-day salary.
              </p>
            </div>
          </div>

          <button
            onClick={() => navigate('/compliance')}
            className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-slate-700 text-xs font-semibold transition"
          >
            Launch Statutory Calculators
          </button>
        </div>
      </div>
    </div>
  );
}
