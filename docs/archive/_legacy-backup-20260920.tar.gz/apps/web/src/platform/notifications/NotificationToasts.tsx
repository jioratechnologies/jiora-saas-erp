import { useEffect } from 'react';
import { CheckCircle2, XCircle, Info, AlertTriangle, X } from 'lucide-react';
import { useUiStore, Notification } from '@/platform/state/uiStore';

const ICONS = {
  success: <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />,
  error: <XCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />,
  warning: <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />,
  info: <Info className="w-4 h-4 text-indigo-400 flex-shrink-0" />,
};

const BORDER_COLORS = {
  success: 'border-emerald-500/40 bg-emerald-950/20',
  error: 'border-rose-500/40 bg-rose-950/20',
  warning: 'border-amber-500/40 bg-amber-950/20',
  info: 'border-indigo-500/40 bg-indigo-950/20',
};

function Toast({ id, type, title, message }: Notification) {
  const dismiss = useUiStore((s) => s.dismissNotification);

  useEffect(() => {
    const t = setTimeout(() => dismiss(id), 5000);
    return () => clearTimeout(t);
  }, [id, dismiss]);

  return (
    <div
      role="status"
      aria-live="polite"
      className={`flex items-start gap-3 px-4 py-3 min-w-[300px] max-w-sm rounded-xl border backdrop-blur-md bg-slate-900/90 shadow-2xl shadow-black/80 animate-fade-in-up transition-all ${BORDER_COLORS[type]}`}
    >
      <div className="mt-0.5">{ICONS[type]}</div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-semibold text-white tracking-wide">{title}</p>
        {message && <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">{message}</p>}
      </div>
      <button
        onClick={() => dismiss(id)}
        className="text-slate-500 hover:text-slate-300 p-0.5 rounded transition"
        aria-label="Dismiss notification"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}

export function NotificationToasts() {
  const notifications = useUiStore((s) => s.notifications);

  if (notifications.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2.5 pointer-events-none">
      {notifications.map((n) => (
        <div key={n.id} className="pointer-events-auto">
          <Toast {...n} />
        </div>
      ))}
    </div>
  );
}
