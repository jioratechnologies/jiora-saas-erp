import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/shared/components/ui/Dialog';
import { Kbd } from '@/shared/components/ui/Kbd';
import { useModalStore } from '@/platform/state/modalStore';

const SHORTCUT_GROUPS = [
  {
    group: 'Navigation Chords',
    items: [
      { keys: 'g o', description: 'Go to Overview Dashboard' },
      { keys: 'g a', description: 'Go to Approvals Inbox' },
      { keys: 'g e', description: 'Go to Employees Master' },
      { keys: 'g t', description: 'Go to Attendance & Punch' },
      { keys: 'g l', description: 'Go to Leaves & Balances' },
      { keys: 'g p', description: 'Go to Payroll & Payslips' },
      { keys: 'g x', description: 'Go to Exit Clearance (16-Step)' },
      { keys: 'g f', description: 'Go to Finance & Accounts' },
      { keys: 'g c', description: 'Go to Statutory Compliance' },
    ],
  },
  {
    group: 'General',
    items: [
      { keys: 'mod+b', description: 'Toggle Sidebar Collapse' },
      { keys: '?', description: 'Open this Shortcuts Dialog' },
      { keys: 'esc', description: 'Close active modal / dialog' },
    ],
  },
];

export function ShortcutHelpModal() {
  const top = useModalStore((s) => s.topModal());
  const close = useModalStore((s) => s.closeTopModal);
  const isOpen = top?.id === 'shortcuts-help';

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && close()}>
      <DialogContent size="lg">
        <DialogHeader>
          <DialogTitle>Keyboard Shortcuts</DialogTitle>
          <DialogDescription>
            Press shortcut chords quickly in sequence to navigate across ERP modules.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {SHORTCUT_GROUPS.map((section) => (
            <div key={section.group}>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                {section.group}
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {section.items.map((item) => (
                  <div
                    key={item.keys}
                    className="flex items-center justify-between p-2.5 rounded-lg bg-slate-800/40 border border-slate-700/50"
                  >
                    <span className="text-xs text-slate-300">{item.description}</span>
                    <div className="flex gap-1">
                      {item.keys.split(' ').map((k) => (
                        <Kbd key={k}>{k}</Kbd>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
