import { useNavigate } from 'react-router-dom';
import { useShortcut } from './ShortcutsProvider';
import { useUiStore } from '@/platform/state/uiStore';
import { useModalStore } from '@/platform/state/modalStore';

export function GlobalShortcuts() {
  const navigate = useNavigate();
  const toggleSidebar = useUiStore((s) => s.toggleSidebar);
  const openModal = useModalStore((s) => s.openModal);

  // Navigation chords
  useShortcut({
    keys: 'g o',
    label: 'Go to Overview',
    scope: 'global',
    handler: () => navigate('/'),
  });

  useShortcut({
    keys: 'g a',
    label: 'Go to Approvals Inbox',
    scope: 'global',
    handler: () => navigate('/workflows'),
  });

  useShortcut({
    keys: 'g e',
    label: 'Go to Employees',
    scope: 'global',
    handler: () => navigate('/hris/employees'),
  });

  useShortcut({
    keys: 'g t',
    label: 'Go to Attendance',
    scope: 'global',
    handler: () => navigate('/hris/attendance'),
  });

  useShortcut({
    keys: 'g l',
    label: 'Go to Leaves',
    scope: 'global',
    handler: () => navigate('/hris/leave'),
  });

  useShortcut({
    keys: 'g p',
    label: 'Go to Payroll',
    scope: 'global',
    handler: () => navigate('/hris/payroll'),
  });

  useShortcut({
    keys: 'g x',
    label: 'Go to Exit Clearance',
    scope: 'global',
    handler: () => navigate('/hris/exit'),
  });

  useShortcut({
    keys: 'g f',
    label: 'Go to Finance',
    scope: 'global',
    handler: () => navigate('/finance'),
  });

  useShortcut({
    keys: 'g c',
    label: 'Go to Compliance',
    scope: 'global',
    handler: () => navigate('/compliance'),
  });

  // UI Toggles
  useShortcut({
    keys: 'mod+b',
    label: 'Toggle Sidebar',
    scope: 'global-always',
    handler: () => toggleSidebar(),
  });

  useShortcut({
    keys: 'shift+?',
    label: 'Open Shortcuts Help',
    scope: 'global-always',
    handler: () => openModal({ id: 'shortcuts-help' }),
  });

  return null;
}
