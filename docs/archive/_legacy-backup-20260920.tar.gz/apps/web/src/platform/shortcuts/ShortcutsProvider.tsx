import * as React from 'react';
import { useModalStore } from '@/platform/state/modalStore';

export type ShortcutScope = 'global' | 'global-always' | 'page' | 'modal';

export interface ShortcutBinding {
  id: string;
  /** Either a single combo "shift+a", "mod+k" or a chord sequence "g o" */
  keys: string;
  label: string;
  scope?: ShortcutScope;
  group?: string;
  handler: (e: KeyboardEvent) => void;
  when?: () => boolean;
}

interface ShortcutContextValue {
  bindings: Map<string, ShortcutBinding>;
  register: (binding: ShortcutBinding) => () => void;
  list: () => ShortcutBinding[];
}

const ShortcutContext = React.createContext<ShortcutContextValue | null>(null);

export function useShortcutContext() {
  const v = React.useContext(ShortcutContext);
  if (!v) throw new Error('ShortcutsProvider missing');
  return v;
}

function isTypingTarget(target: EventTarget | null): boolean {
  if (!(target instanceof HTMLElement)) return false;
  const tag = target.tagName.toLowerCase();
  if (tag === 'input' || tag === 'textarea' || tag === 'select') return true;
  if (target.isContentEditable) return true;
  return false;
}

function normaliseKey(e: KeyboardEvent): string {
  const parts: string[] = [];
  if (e.metaKey || e.ctrlKey) parts.push('mod');
  if (e.shiftKey) parts.push('shift');
  if (e.altKey) parts.push('alt');
  const k = e.key.toLowerCase();
  if (['control', 'meta', 'shift', 'alt'].includes(k)) return '';
  parts.push(k);
  return parts.join('+');
}

export function ShortcutsProvider({ children }: { children: React.ReactNode }) {
  const bindingsRef = React.useRef(new Map<string, ShortcutBinding>());
  const sequenceRef = React.useRef<string[]>([]);
  const sequenceTimerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);

  const register = React.useCallback((binding: ShortcutBinding) => {
    bindingsRef.current.set(binding.id, binding);
    return () => {
      bindingsRef.current.delete(binding.id);
    };
  }, []);

  const list = React.useCallback(() => Array.from(bindingsRef.current.values()), []);

  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const modalsOpen = useModalStore.getState().stack.length > 0;
      if (isTypingTarget(e.target)) return;
      const key = normaliseKey(e);
      if (!key) return;

      // Append to sequence buffer for chords (e.g. g o)
      sequenceRef.current.push(key);
      const seq = sequenceRef.current.join(' ');

      if (sequenceTimerRef.current) clearTimeout(sequenceTimerRef.current);
      sequenceTimerRef.current = setTimeout(() => {
        sequenceRef.current = [];
      }, 750);

      for (const b of bindingsRef.current.values()) {
        const scope = b.scope ?? 'page';
        if (modalsOpen && scope !== 'global-always') continue;
        if (b.when && !b.when()) continue;

        const matchesSingle = b.keys === key;
        const matchesSeq = b.keys === seq;
        if (matchesSingle || matchesSeq) {
          e.preventDefault();
          b.handler(e);
          sequenceRef.current = [];
          return;
        }
      }

      // ESC always closes top modal
      if (key === 'escape' && modalsOpen) {
        useModalStore.getState().closeTopModal();
      }
    };

    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const value = React.useMemo<ShortcutContextValue>(
    () => ({ bindings: bindingsRef.current, register, list }),
    [register, list]
  );

  return <ShortcutContext.Provider value={value}>{children}</ShortcutContext.Provider>;
}

export function useShortcut(binding: Omit<ShortcutBinding, 'id'> & { id?: string }) {
  const ctx = useShortcutContext();
  const id = React.useMemo(() => binding.id ?? `sc_${Math.random().toString(36).slice(2)}`, [binding.id]);
  const handlerRef = React.useRef(binding.handler);
  handlerRef.current = binding.handler;

  React.useEffect(() => {
    return ctx.register({
      ...binding,
      id,
      handler: (e) => handlerRef.current(e),
    });
  }, [id, binding.keys, binding.scope, binding.label, binding.group, ctx]);
}
