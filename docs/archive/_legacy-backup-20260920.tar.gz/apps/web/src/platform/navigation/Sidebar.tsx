import { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  CheckSquare,
  Users,
  Clock,
  Calendar,
  FileText,
  UserMinus,
  Landmark,
  HeartHandshake,
  Briefcase,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Sparkles,
  Database,
  UserPlus,
  ClipboardCheck,
  Award,
  Plane,
  Monitor,
  Network,
  Palette,
  Building2,
} from 'lucide-react';
import { useUiStore } from '@/platform/state/uiStore';
import { useAuth } from '@/context/AuthContext';
import { useTenantBranding } from '@/context/TenantBrandingContext';
import { cn } from '@/shared/utils/utils';

interface NavItemProps {
  to: string;
  label: string;
  icon: any;
  exact?: boolean;
  collapsed: boolean;
  badgeCount?: number;
}

function NavItem({ to, label, icon: Icon, exact, collapsed, badgeCount }: NavItemProps) {
  const location = useLocation();
  const isActive = exact ? location.pathname === to : location.pathname.startsWith(to);

  return (
    <NavLink
      to={to}
      title={collapsed ? label : undefined}
      className={cn(
        'group flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium transition-all duration-150',
        isActive
          ? 'bg-indigo-600/15 text-indigo-300 border border-indigo-500/30 shadow-sm shadow-indigo-600/10'
          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
      )}
    >
      <div className="relative flex-shrink-0">
        <Icon
          className={cn(
            'w-4 h-4 transition-colors',
            isActive ? 'text-indigo-400' : 'text-slate-400 group-hover:text-slate-200'
          )}
        />
        {!!badgeCount && (
          <span className="absolute -top-1 -right-1.5 min-w-[15px] h-[15px] px-1 flex items-center justify-center rounded-full text-[9px] font-bold bg-amber-500 text-slate-950">
            {badgeCount > 9 ? '9+' : badgeCount}
          </span>
        )}
      </div>

      {!collapsed && <span className="truncate">{label}</span>}

      {!collapsed && !!badgeCount && (
        <span className="ml-auto text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
          {badgeCount}
        </span>
      )}
    </NavLink>
  );
}

function DomainGroup({
  label,
  icon: Icon,
  items,
  collapsed,
}: {
  label: string;
  icon: any;
  items: Array<{ to: string; label: string; icon: any; exact?: boolean; badgeCount?: number }>;
  collapsed: boolean;
}) {
  const [open, setOpen] = useState(true);

  return (
    <div className="space-y-1">
      {!collapsed && (
        <button
          onClick={() => setOpen((v) => !v)}
          className="w-full flex items-center gap-2 px-3 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider hover:text-slate-200 transition-colors"
        >
          <Icon className="w-3.5 h-3.5 flex-shrink-0 text-slate-400" />
          <span className="truncate">{label}</span>
          <ChevronDown
            className={cn('w-3 h-3 ml-auto transition-transform flex-shrink-0', !open && '-rotate-90')}
          />
        </button>
      )}

      {(open || collapsed) && (
        <div className="space-y-0.5">
          {items.map((item) => (
            <NavItem key={item.to} {...item} collapsed={collapsed} />
          ))}
        </div>
      )}
    </div>
  );
}

export function Sidebar({ pendingApprovalsCount = 0 }: { pendingApprovalsCount?: number }) {
  const collapsed = useUiStore((s) => s.sidebarCollapsed);
  const toggle = useUiStore((s) => s.toggleSidebar);
  const { currentUser } = useAuth();
  const { tenantConfig, activeTenantId, switchTenant, allTenants } = useTenantBranding();

  const HRIS_ITEMS = [
    { to: '/hris/recruitment', label: 'Recruitment & ATS', icon: UserPlus },
    { to: '/hris/onboarding', label: 'Onboarding & Induction', icon: ClipboardCheck },
    { to: '/hris/employees', label: 'Employees Master', icon: Users },
    { to: '/hris/attendance', label: 'Attendance & Bio', icon: Clock },
    { to: '/hris/kiosk', label: 'Attendance Kiosk', icon: Monitor },
    { to: '/hris/leave', label: 'Leave Management', icon: Calendar },
    { to: '/hris/performance', label: 'Performance & KRAs', icon: Award },
    { to: '/hris/travel-expenses', label: 'Travel & Conveyance', icon: Plane },
    { to: '/hris/payroll', label: 'Payroll & Statutory', icon: FileText },
    { to: '/hris/exit', label: 'Exit Clearance (16-Step)', icon: UserMinus },
  ];

  const ERP_ITEMS = [
    { to: '/finance', label: 'Finance & Invoicing', icon: Landmark },
    { to: '/crm', label: 'CRM & Donors', icon: HeartHandshake },
    { to: '/ppm', label: 'PPM & Projects', icon: Briefcase },
    { to: '/org-chart', label: 'Enterprise Org Chart', icon: Network },
    { to: '/compliance', label: 'Statutory Compliance', icon: ShieldCheck },
    { to: '/tenant-settings', label: 'Whitelabeling & Branding', icon: Palette },
  ];

  return (
    <aside
      className={cn(
        'flex flex-col h-screen bg-slate-900 border-r border-slate-800/90 transition-all duration-250 z-20 flex-shrink-0 select-none',
        collapsed ? 'w-16' : 'w-64'
      )}
    >
      {/* Brand Header with Dynamic Whitelabeling */}
      <div className="flex items-center gap-3 px-4 h-16 border-b border-slate-800/90 overflow-hidden">
        <div
          className="w-8 h-8 rounded-xl flex items-center justify-center text-base shadow-md flex-shrink-0"
          style={{ backgroundColor: tenantConfig?.primaryColor || '#6366f1' }}
        >
          {tenantConfig?.logoUrl && tenantConfig.logoUrl.length <= 4 ? tenantConfig.logoUrl : '🌸'}
        </div>
        {!collapsed && (
          <div className="overflow-hidden leading-tight flex-1">
            <h2 className="font-bold text-white text-xs tracking-wider uppercase truncate">
              {tenantConfig?.name || 'Sachhi Saheli'}
            </h2>
            <p className="text-[10px] text-slate-400 font-medium truncate">
              {tenantConfig?.tagline || 'Enterprise ERP Suite'}
            </p>
          </div>
        )}
      </div>

      {/* Navigation Groups */}
      <nav className="flex-1 px-2.5 py-4 space-y-4 overflow-y-auto overflow-x-hidden">
        {/* Top Level Items */}
        <div className="space-y-1">
          <NavItem to="/" label="Executive Overview" icon={LayoutDashboard} exact collapsed={collapsed} />
          <NavItem
            to="/workflows"
            label="Approvals & Workflows"
            icon={CheckSquare}
            collapsed={collapsed}
            badgeCount={pendingApprovalsCount}
          />
        </div>

        <div className="w-full h-px bg-slate-800/80 my-2" />

        {/* HRIS Domain */}
        <DomainGroup label="Core HRIS" icon={Users} items={HRIS_ITEMS} collapsed={collapsed} />

        <div className="w-full h-px bg-slate-800/80 my-2" />

        {/* Enterprise ERP Domains */}
        <DomainGroup label="Enterprise ERP" icon={Briefcase} items={ERP_ITEMS} collapsed={collapsed} />
      </nav>

      {/* Footer Info */}
      {!collapsed && (
        <div className="px-4 py-3 border-t border-slate-800 bg-slate-950/40 space-y-2">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-400">Current Role:</span>
            <span className="font-semibold text-indigo-300 capitalize">{currentUser?.role || 'Guest'}</span>
          </div>
          <div className="flex items-center gap-2 text-[10px] text-slate-400">
            <Database className="w-3 h-3 text-emerald-400" />
            <span>PostgreSQL & Redis Active</span>
          </div>
        </div>
      )}

      {/* Collapse Toggle */}
      <button
        onClick={toggle}
        className="flex items-center justify-center h-10 border-t border-slate-800 text-slate-400 hover:text-slate-100 hover:bg-slate-800/60 transition-colors"
        title={collapsed ? 'Expand sidebar (Ctrl+B)' : 'Collapse sidebar (Ctrl+B)'}
      >
        {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
      </button>
    </aside>
  );
}
