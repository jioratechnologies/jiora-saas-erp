import { create } from 'zustand';

export type ModalState =
  | { id: 'shortcuts-help' }
  | { id: 'apply-leave' }
  | { id: 'punch-attendance' }
  | { id: 'exit-checklist'; exitId: string }
  | { id: 'workflow-detail'; workflowId: string };

interface ModalStoreState {
  stack: ModalState[];
  openModal: (m: ModalState) => void;
  closeTopModal: () => void;
  closeAllModals: () => void;
  closeModalById: (id: ModalState['id']) => void;
  topModal: () => ModalState | undefined;
}

export const useModalStore = create<ModalStoreState>((set, get) => ({
  stack: [],
  openModal: (m) => set((s) => ({ stack: [...s.stack, m] })),
  closeTopModal: () => set((s) => ({ stack: s.stack.slice(0, -1) })),
  closeAllModals: () => set({ stack: [] }),
  closeModalById: (id) => set((s) => ({ stack: s.stack.filter((m) => m.id !== id) })),
  topModal: () => {
    const stack = get().stack;
    return stack[stack.length - 1];
  },
}));
