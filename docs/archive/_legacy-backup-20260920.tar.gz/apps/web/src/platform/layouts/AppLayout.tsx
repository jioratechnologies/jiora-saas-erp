import { useState, useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from '@/platform/navigation/Sidebar';
import { Navbar } from './Navbar';
import { GlobalShortcuts } from '@/platform/shortcuts/GlobalShortcuts';
import { ShortcutHelpModal } from '@/platform/shortcuts/ShortcutHelpModal';
import { NotificationToasts } from '@/platform/notifications/NotificationToasts';
import { useAuth } from '@/context/AuthContext';
import { useUiStore } from '@/platform/state/uiStore';
import { apiClient } from '@/api';

export default function AppLayout() {
  const { currentUser } = useAuth();
  const refreshKey = useUiStore((s) => s.refreshKey);
  const [pendingApprovalsCount, setPendingApprovalsCount] = useState<number>(0);

  useEffect(() => {
    if (currentUser) {
      fetchPendingCount();
    }
  }, [currentUser, refreshKey]);

  const fetchPendingCount = async () => {
    try {
      const inboxRes = await apiClient.getInbox(currentUser);
      if (inboxRes && inboxRes.success) {
        setPendingApprovalsCount(inboxRes.count || 0);
      }
    } catch (e) {
      console.error('Failed to fetch approval counts:', e);
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-slate-950 text-slate-100">
      <GlobalShortcuts />
      <Sidebar pendingApprovalsCount={pendingApprovalsCount} />

      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <Navbar pendingApprovalsCount={pendingApprovalsCount} />

        <main className="flex-1 overflow-y-auto p-4 md:p-8 max-w-7xl mx-auto w-full">
          <Outlet />
        </main>
      </div>

      <NotificationToasts />
      <ShortcutHelpModal />
    </div>
  );
}
