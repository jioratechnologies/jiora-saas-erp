import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Bell, RefreshCw, Command, UserCheck, Shield, Grid, Search } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useRealtime } from '@/context/RealtimeContext';
import { useUiStore } from '@/platform/state/uiStore';
import { useModalStore } from '@/platform/state/modalStore';
import { Badge } from '@/shared/components/ui/Badge';
import { Button } from '@/shared/components/ui/Button';
import { AppLauncherModal } from '@/shared/components/workspace/AppLauncherModal';
import { CommandPalette } from '@/shared/components/workspace/CommandPalette';

const PAGE_METADATA: Record<string, { title: string; sub: string }> = {
  '/': { title: 'Executive Overview', sub: 'Organization KPI telemetry & operational status' },
  '/workflows': { title: 'Approvals Inbox & Workflows', sub: 'The 16 BRD approval matrices & audit logs' },
  '/hris/employees': { title: 'Employee Master', sub: 'Personal, Statutory, and Salary profiles' },
  '/hris/recruitment': { title: 'Recruitment & ATS Kanban', sub: 'Candidate pipelines, statutory 2-reference checks & offers' },
  '/hris/onboarding': { title: 'Onboarding & Probation', sub: '3-tier induction checklists, IT provisioning & 6mo confirmation' },
  '/hris/attendance': { title: 'Daily Attendance & Biometrics', sub: 'Check-in, Check-out & Late arrival deductions' },
  '/hris/kiosk': { title: 'Smart Attendance Kiosk', sub: 'Fullscreen RFID badge scanner & 10:00 AM late rules' },
  '/hris/leave': { title: 'Leave Management', sub: 'Statutory balances, CL/SL/EL & Special maternity/paternity' },
  '/hris/performance': { title: 'Performance & SMART KRAs', sub: 'Annual appraisals, 360 reviews & President bell-curve calibration' },
  '/hris/travel-expenses': { title: 'Travel & Conveyance Claims', sub: 'City-tier per-diem allowances, tour advances & emergency loans' },
  '/hris/payroll': { title: 'Payroll & Statutory Ledger', sub: 'Salary registers, 12% PF & Gratuity Act 1972 formula' },
  '/hris/exit': { title: 'Exit Clearance & Settlement', sub: '16-step clearance checklist & Full & Final settlement' },
  '/finance': { title: 'Finance & Chart of Accounts', sub: 'General Ledger, Payroll auto-sync & Cost Centers' },
  '/crm': { title: 'CRM & Stakeholder Relations', sub: 'Beneficiaries, Donors, Grants & Partner pipelines' },
  '/ppm': { title: 'Project & Portfolio Management', sub: 'Programs, Objectives, Milestones & Timesheets' },
  '/org-chart': { title: 'Enterprise Org Chart', sub: 'Visual structural hierarchy & departmental reporting lines' },
  '/compliance': { title: 'Statutory Compliance & Legal Vault', sub: 'Indian Labour Laws, EPF 1952, Gratuity 1972, Maternity 2017' },
  '/tenant-settings': { title: 'Tenant Whitelabeling & Branding', sub: 'Custom logos, brand colors, currencies & client customization' },
};

export function Navbar({ pendingApprovalsCount = 0 }: { pendingApprovalsCount?: number }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { currentUser, personas, switchPersona, refreshUser } = useAuth();
  const { isConnected, connectionStatus } = useRealtime();
  const triggerRefresh = useUiStore((s) => s.triggerRefresh);
  const openModal = useModalStore((s) => s.openModal);

  const [showLauncher, setShowLauncher] = useState(false);
  const [showCommandPalette, setShowCommandPalette] = useState(false);

  const meta = PAGE_METADATA[location.pathname] ?? {
    title: 'Enterprise ERP',
    sub: 'Sachhi Saheli SaaS Platform',
  };

  const handleRefresh = async () => {
    triggerRefresh();
    await refreshUser();
  };

  return (
    <>
      <header className="h-16 flex items-center justify-between px-6 border-b border-slate-800/90 bg-slate-900/75 backdrop-blur-md sticky top-0 z-30 flex-shrink-0">
        {/* Left: 9-Dot Enterprise App Launcher & Title */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowLauncher(true)}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-indigo-600 border border-slate-700 hover:border-indigo-500 text-slate-300 hover:text-white transition shadow-sm group"
            title="Open Enterprise App Launcher"
          >
            <Grid className="w-4 h-4 group-hover:rotate-90 transition-transform duration-200" />
          </button>

          <div>
            <h1 className="font-semibold text-slate-100 text-sm tracking-tight flex items-center gap-2">
              {meta.title}
            </h1>
            <p className="text-[11px] text-slate-400">{meta.sub}</p>
          </div>
        </div>

        {/* Right Controls */}
        <div className="flex items-center gap-3">
          {/* Omni Search Button */}
          <button
            onClick={() => setShowCommandPalette(true)}
            className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-400 hover:text-slate-200 hover:border-slate-700 transition"
          >
            <Search className="w-3.5 h-3.5" />
            <span>Search apps & records...</span>
            <kbd className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-[10px] font-mono text-slate-400">
              ⌘K
            </kbd>
          </button>

          {/* Persona Switcher */}
          <div className="hidden sm:flex items-center gap-2 bg-slate-950/60 border border-slate-800 rounded-xl px-2.5 py-1.5 shadow-inner">
            <div className="w-6 h-6 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-xs font-bold">
              <UserCheck className="w-3.5 h-3.5" />
            </div>
            <div className="flex flex-col text-left">
              <span className="text-[10px] text-slate-400 font-medium leading-none">Simulating Persona:</span>
              {personas.length === 0 ? (
                <span className="text-[11px] text-amber-400 animate-pulse">Connecting to DB API...</span>
              ) : (
                <select
                  value={currentUser?.id || ''}
                  onChange={(e) => switchPersona(e.target.value)}
                  className="bg-transparent text-xs font-semibold text-indigo-300 focus:outline-none cursor-pointer pr-1"
                >
                  {personas.map((p) => (
                    <option key={p.id} value={p.id} className="bg-slate-900 text-slate-100">
                      {p.name} ({p.role})
                    </option>
                  ))}
                </select>
              )}
            </div>
            {currentUser && (
              <Badge color="indigo" variant="soft" size="xs" className="hidden lg:inline-flex">
                {currentUser.department}
              </Badge>
            )}
          </div>

          {/* Pending Approvals Bell */}
          <button
            onClick={() => navigate('/workflows')}
            className="relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800/80 border border-slate-700/80 hover:border-amber-500/50 hover:bg-slate-800 transition"
            title={`${pendingApprovalsCount} pending approvals`}
          >
            <Bell className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-amber-300 font-semibold">{pendingApprovalsCount}</span>
            {pendingApprovalsCount > 0 && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
            )}
          </button>

          {/* Refresh button */}
          <Button
            intent="secondary"
            size="sm"
            className="h-8 w-8 p-0"
            onClick={handleRefresh}
            title="Refresh ERP data"
          >
            <RefreshCw className="w-3.5 h-3.5 text-slate-400 hover:text-slate-200" />
          </Button>

          {/* Keyboard shortcuts help button */}
          <Button
            intent="ghost"
            size="sm"
            className="hidden md:flex h-8 w-8 p-0 text-slate-400 hover:text-slate-200"
            onClick={() => openModal({ id: 'shortcuts-help' })}
            title="Keyboard shortcuts (?)"
          >
            <Command className="w-3.5 h-3.5" />
          </Button>

          <div className="w-px h-5 bg-slate-800 mx-0.5" />

          {/* Live WebSockets Status Indicator */}
          <div
            className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-[10px] font-medium transition-all duration-200"
            style={{
              backgroundColor: isConnected ? 'rgba(16, 185, 129, 0.08)' : 'rgba(245, 158, 11, 0.08)',
              borderColor: isConnected ? 'rgba(16, 185, 129, 0.3)' : 'rgba(245, 158, 11, 0.3)',
              color: isConnected ? '#34d399' : '#fbbf24',
            }}
            title={isConnected ? 'Real-time WebSocket connection active (Socket.IO + Redis)' : 'Reconnecting to real-time engine...'}
          >
            <span className={`w-1.5 h-1.5 rounded-full ${isConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
            <span>{isConnected ? 'LIVE SYNC' : connectionStatus.toUpperCase()}</span>
          </div>

          {/* System Architecture pill */}
          <div className="hidden xl:flex items-center gap-2 px-2.5 py-1 rounded-lg bg-indigo-500/10 border border-indigo-500/30 text-[10px] font-medium text-indigo-400">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse" />
            <span>MODULAR MONOLITH</span>
          </div>
        </div>
      </header>

      {/* 9-Dot Enterprise App Launcher Modal */}
      <AppLauncherModal isOpen={showLauncher} onClose={() => setShowLauncher(false)} />

      {/* Global Command Palette */}
      <CommandPalette isOpen={showCommandPalette} onClose={() => setShowCommandPalette(false)} />
    </>
  );
}
