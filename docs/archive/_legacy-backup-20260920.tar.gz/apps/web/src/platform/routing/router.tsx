import { createBrowserRouter } from 'react-router-dom';
import AppLayout from '@/platform/layouts/AppLayout';
import { overviewRoutes } from '@/products/overview/routes/routes';
import { workflowsRoutes } from '@/products/workflows/routes/routes';
import { hrisRoutes } from '@/products/hris/routes/routes';
import { financeRoutes } from '@/products/finance/routes/routes';
import { crmRoutes } from '@/products/crm/routes/routes';
import { ppmRoutes } from '@/products/ppm/routes/routes';
import { complianceRoutes } from '@/products/compliance/routes/routes';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <AppLayout />,
    children: [
      ...overviewRoutes,
      ...workflowsRoutes,
      ...hrisRoutes,
      ...financeRoutes,
      ...crmRoutes,
      ...ppmRoutes,
      ...complianceRoutes,
    ],
  },
]);
