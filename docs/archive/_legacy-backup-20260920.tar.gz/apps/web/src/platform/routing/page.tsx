import type { ReactNode } from 'react';
import { RouteShell } from './RouteShell';
import { RequireRole } from './RouteGuard';
import { UserRole } from '@/types';

/** Page wrapper: error boundary + suspense + optional role guard */
export function page(label: string, node: ReactNode, allowedRoles?: UserRole[]) {
  return (
    <RouteShell label={label}>
      <RequireRole allowedRoles={allowedRoles}>{node}</RequireRole>
    </RouteShell>
  );
}
