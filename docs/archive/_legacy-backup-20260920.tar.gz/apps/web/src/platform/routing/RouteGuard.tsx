import React from 'react';
import { useAuth } from '@/context/AuthContext';
import { UserRole } from '@/types';
import { ShieldAlert } from 'lucide-react';

interface RequireRoleProps {
  allowedRoles?: UserRole[];
  children: React.ReactNode;
}

export const RequireRole: React.FC<RequireRoleProps> = ({ allowedRoles, children }) => {
  const { currentUser, loading } = useAuth();

  if (loading) return null;

  if (allowedRoles && currentUser && !allowedRoles.includes(currentUser.role)) {
    return (
      <div className="p-8 rounded-2xl border border-amber-500/30 bg-amber-500/10 text-center max-w-md mx-auto my-12">
        <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center mx-auto mb-3">
          <ShieldAlert className="w-6 h-6" />
        </div>
        <h3 className="text-base font-semibold text-slate-100 mb-1">Access Restricted</h3>
        <p className="text-xs text-slate-400 mb-2">
          Your current persona role (<span className="font-semibold text-amber-300">{currentUser.role}</span>) does not have permission to view this view.
        </p>
        <p className="text-[11px] text-slate-500">
          Use the persona switcher in the top navigation bar to switch to an authorized role.
        </p>
      </div>
    );
  }

  return <>{children}</>;
};
