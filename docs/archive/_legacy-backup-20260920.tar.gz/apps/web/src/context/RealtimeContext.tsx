import React, { createContext, useContext, useEffect, useState, useRef, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';
import { useAuth } from './AuthContext';

export interface RealtimeNotification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'activity';
  timestamp: string;
}

interface RealtimeContextType {
  socket: Socket | null;
  isConnected: boolean;
  connectionStatus: 'connected' | 'connecting' | 'disconnected';
  notifications: RealtimeNotification[];
  clearNotification: (id: string) => void;
  subscribeToRecord: (recordType: string, recordId: string, onEvent: (data: any) => void) => () => void;
  subscribeToWorkflow: (workflowId: string, onEvent: (data: any) => void) => () => void;
}

const RealtimeContext = createContext<RealtimeContextType | undefined>(undefined);

export function RealtimeProvider({ children }: { children: React.ReactNode }) {
  const { currentUser } = useAuth();
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'connecting' | 'disconnected'>('connecting');
  const [notifications, setNotifications] = useState<RealtimeNotification[]>([]);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    // In local Vite dev (port 3000), connect directly to API on port 4000 to avoid proxy EPIPE errors
    // In production / Docker / Kong (ports 8000, 3001, etc.), route through current origin
    const socketUrl = window.location.port === '3000'
      ? `${window.location.protocol}//${window.location.hostname}:4000`
      : window.location.origin;

    setConnectionStatus('connecting');

    const s = io(socketUrl, {
      transports: ['websocket', 'polling'],
      reconnectionAttempts: 10,
      reconnectionDelay: 2000,
      auth: {
        tenantId: currentUser?.tenantId || 'sachhi-saheli-delhi',
        userId: currentUser?.id || 'usr_super_admin',
        userName: currentUser?.name || 'Administrator',
        role: currentUser?.role || 'SUPER_ADMIN',
      },
      query: {
        tenantId: currentUser?.tenantId || 'sachhi-saheli-delhi',
        userId: currentUser?.id || 'usr_super_admin',
      },
    });

    s.on('connect', () => {
      setIsConnected(true);
      setConnectionStatus('connected');
    });

    s.on('disconnect', () => {
      setIsConnected(false);
      setConnectionStatus('disconnected');
    });

    s.on('connect_error', () => {
      setIsConnected(false);
      setConnectionStatus('disconnected');
    });

    // Company/Tenant-wide live notification broadcasts
    s.on('notification:activity_scheduled', (data: any) => {
      const newNotif: RealtimeNotification = {
        id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
        title: `New Activity Scheduled: ${data.activityType || 'TODO'}`,
        message: `${data.authorName || 'Team member'} scheduled an activity due on ${data.dueDate}`,
        type: 'activity',
        timestamp: new Date().toLocaleTimeString(),
      };
      setNotifications((prev) => [newNotif, ...prev.slice(0, 4)]);
    });

    // Domain event listener for multi-approver workflow transitions
    s.on('domain:event', (evt: any) => {
      if (evt?.eventType?.startsWith('WORKFLOW_')) {
        const newNotif: RealtimeNotification = {
          id: `notif_wf_${Date.now()}`,
          title: `Workflow Update: ${evt.eventType.replace(/_/g, ' ')}`,
          message: evt.payload?.title || 'An approval workflow advanced stages.',
          type: 'info',
          timestamp: new Date().toLocaleTimeString(),
        };
        setNotifications((prev) => [newNotif, ...prev.slice(0, 4)]);
      }
    });

    setSocket(s);
    socketRef.current = s;

    return () => {
      s.disconnect();
    };
  }, [currentUser?.id, currentUser?.tenantId]);

  const clearNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const subscribeToRecord = useCallback(
    (recordType: string, recordId: string, onEvent: (data: any) => void) => {
      const s = socketRef.current;
      if (!s || !recordType || !recordId) return () => {};

      s.emit('subscribe:record', { recordType, recordId });

      const handleNewMessage = (data: any) => {
        if (data.recordType === recordType && data.recordId === recordId) {
          onEvent(data);
        }
      };

      const handleNewActivity = (data: any) => {
        if (data.recordType === recordType && data.recordId === recordId) {
          onEvent(data);
        }
      };

      const handleUpdateActivity = (data: any) => {
        if (data.recordType === recordType && data.recordId === recordId) {
          onEvent(data);
        }
      };

      s.on('chatter:new_message', handleNewMessage);
      s.on('chatter:new_activity', handleNewActivity);
      s.on('chatter:update_activity', handleUpdateActivity);

      return () => {
        s.emit('unsubscribe:record', { recordType, recordId });
        s.off('chatter:new_message', handleNewMessage);
        s.off('chatter:new_activity', handleNewActivity);
        s.off('chatter:update_activity', handleUpdateActivity);
      };
    },
    []
  );

  const subscribeToWorkflow = useCallback(
    (workflowId: string, onEvent: (data: any) => void) => {
      const s = socketRef.current;
      if (!s || !workflowId) return () => {};

      s.emit('subscribe:workflow', { workflowId });

      const handleWorkflowTransition = (data: any) => {
        if (data.workflowId === workflowId) {
          onEvent(data);
        }
      };

      s.on('workflow:transition', handleWorkflowTransition);

      return () => {
        s.emit('unsubscribe:workflow', { workflowId });
        s.off('workflow:transition', handleWorkflowTransition);
      };
    },
    []
  );

  return (
    <RealtimeContext.Provider
      value={{
        socket,
        isConnected,
        connectionStatus,
        notifications,
        clearNotification,
        subscribeToRecord,
        subscribeToWorkflow,
      }}
    >
      {children}
      {/* Toast Notification HUD */}
      {notifications.length > 0 && (
        <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
          {notifications.map((notif) => (
            <div
              key={notif.id}
              className="pointer-events-auto bg-slate-900/95 border border-indigo-500/40 backdrop-blur-md rounded-2xl p-4 shadow-2xl shadow-indigo-950/50 flex items-start justify-between gap-3 text-xs animate-in slide-in-from-bottom-3 duration-200"
            >
              <div>
                <div className="flex items-center gap-1.5 font-bold text-white">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <span>{notif.title}</span>
                </div>
                <p className="text-slate-300 text-[11px] mt-1">{notif.message}</p>
                <span className="text-[10px] text-slate-500 font-mono mt-1 block">{notif.timestamp}</span>
              </div>
              <button
                onClick={() => clearNotification(notif.id)}
                className="text-slate-400 hover:text-white text-xs px-1"
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      )}
    </RealtimeContext.Provider>
  );
}

export function useRealtime() {
  const context = useContext(RealtimeContext);
  if (!context) {
    throw new Error('useRealtime must be used within a RealtimeProvider');
  }
  return context;
}
