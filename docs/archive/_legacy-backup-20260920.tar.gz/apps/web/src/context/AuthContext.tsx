import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { apiClient } from '../api';

interface AuthContextType {
  currentUser: User | null;
  personas: User[];
  loading: boolean;
  switchPersona: (userId: string) => void;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [personas, setPersonas] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPersonasAndUser();
  }, []);

  const loadPersonasAndUser = async () => {
    try {
      setLoading(true);
      const allPersonas = await apiClient.getPersonas();
      setPersonas(allPersonas);

      if (allPersonas.length === 0) {
        // Retry shortly if API container was booting
        setTimeout(loadPersonasAndUser, 2500);
        return;
      }

      // Check localStorage for preferred simulated persona or default to President
      const savedId = localStorage.getItem('sachhi_saheli_simulated_user_id');
      const initialUser = allPersonas.find((p) => p.id === savedId) || allPersonas[0];

      if (initialUser) {
        const fullUser = await apiClient.getMe(initialUser);
        setCurrentUser(fullUser || initialUser);
      }
    } catch (err) {
      console.error('Failed to load personas, retrying in 2.5s...', err);
      setTimeout(loadPersonasAndUser, 2500);
    } finally {
      setLoading(false);
    }
  };

  const switchPersona = async (userId: string) => {
    const target = personas.find((p) => p.id === userId);
    if (target) {
      localStorage.setItem('sachhi_saheli_simulated_user_id', target.id);
      try {
        const fullUser = await apiClient.getMe(target);
        setCurrentUser(fullUser || target);
      } catch (e) {
        setCurrentUser(target);
      }
    }
  };

  const refreshUser = async () => {
    if (currentUser) {
      const fullUser = await apiClient.getMe(currentUser);
      setCurrentUser(fullUser);
    }
  };

  return (
    <AuthContext.Provider value={{ currentUser, personas, loading, switchPersona, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
