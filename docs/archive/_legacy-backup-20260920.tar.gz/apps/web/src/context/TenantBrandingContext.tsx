import React, { createContext, useContext, useState, useEffect } from 'react';
import { apiClient } from '@/api';

export interface TenantBranding {
  id: string;
  name: string;
  slug: string;
  logoUrl?: string;
  faviconUrl?: string;
  primaryColor: string;
  accentColor: string;
  legalEntityType?: string;
  currency: string;
  tagline?: string;
  locale?: string;
}

interface TenantContextType {
  tenant: TenantBranding | null;
  tenantConfig: TenantBranding | null;
  activeTenantId: string;
  allTenants: TenantBranding[];
  loading: boolean;
  switchTenant: (tenantId: string) => Promise<void>;
  updateBranding: (updates: Partial<TenantBranding>) => Promise<boolean>;
  refreshBranding: () => Promise<void>;
}

const TenantContext = createContext<TenantContextType | undefined>(undefined);

export const TenantProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tenant, setTenant] = useState<TenantBranding | null>(null);
  const [allTenants, setAllTenants] = useState<TenantBranding[]>([]);
  const [loading, setLoading] = useState(true);

  const applyBrandingTheme = (t: TenantBranding) => {
    if (typeof document !== 'undefined') {
      document.documentElement.style.setProperty('--tenant-primary', t.primaryColor || '#4f46e5');
      document.documentElement.style.setProperty('--tenant-accent', t.accentColor || '#065f46');
      document.title = `${t.name} — Enterprise ERP`;
    }
  };

  const fetchBranding = async () => {
    try {
      const [brandingRes, allRes] = await Promise.all([
        apiClient.getTenantBranding(),
        apiClient.getAllTenants(),
      ]);

      if (brandingRes && brandingRes.success) {
        setTenant(brandingRes.data);
        applyBrandingTheme(brandingRes.data);
      }
      if (allRes && allRes.success) {
        setAllTenants(allRes.data || []);
      }
    } catch (err) {
      console.error('Failed to load tenant branding:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBranding();
  }, []);

  const switchTenant = async (tenantId: string) => {
    apiClient.setTenantId(tenantId);
    await fetchBranding();
  };

  const updateBranding = async (updates: Partial<TenantBranding>) => {
    try {
      const res = await apiClient.updateTenantBranding(updates);
      if (res && res.success) {
        setTenant(res.data);
        applyBrandingTheme(res.data);
        return true;
      }
      return false;
    } catch (err) {
      console.error('Failed to update tenant branding:', err);
      return false;
    }
  };

  return (
    <TenantContext.Provider
      value={{
        tenant,
        tenantConfig: tenant,
        activeTenantId: tenant?.id || 'sachhi-saheli-delhi',
        allTenants,
        loading,
        switchTenant,
        updateBranding,
        refreshBranding: fetchBranding,
      }}
    >
      {children}
    </TenantContext.Provider>
  );
};

export const useTenant = () => {
  const context = useContext(TenantContext);
  if (!context) {
    throw new Error('useTenant must be used within a TenantProvider');
  }
  return context;
};

export const useTenantBranding = useTenant;
export const TenantBrandingProvider = TenantProvider;
