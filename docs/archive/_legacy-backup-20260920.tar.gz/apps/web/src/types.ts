export type UserRole = 
  | 'SUPER_ADMIN'
  | 'APP_DEVELOPER'
  | 'PRESIDENT' 
  | 'HR' 
  | 'FINANCE' 
  | 'MANAGER' 
  | 'EMPLOYEE';

export interface User {
  id: string;
  tenantId?: string;
  employeeId: string;
  name: string;
  email: string;
  role: UserRole;
  department: string;
  designation: string;
  joiningDate: string;
  status: 'ACTIVE' | 'PROBATION' | 'NOTICE_PERIOD' | 'EXITED';
  profile?: any;
  leaveBalance?: any;
}

export type WorkflowStatus = 
  | 'DRAFT'
  | 'PENDING_MANAGER'
  | 'PENDING_HR'
  | 'PENDING_FINANCE'
  | 'PENDING_PRESIDENT'
  | 'APPROVED'
  | 'REJECTED'
  | 'CANCELLED';

export interface WorkflowInstance {
  id: string;
  workflowType: string;
  title: string;
  requesterId: string;
  requesterName: string;
  requesterRole: UserRole;
  department: string;
  currentStage: WorkflowStatus;
  stages: {
    stage: WorkflowStatus;
    approverRole: UserRole;
    approverId?: string;
    approverName?: string;
    decision?: 'APPROVED' | 'REJECTED';
    comments?: string;
    actionDate?: string;
  }[];
  payload: any;
  createdAt: string;
  updatedAt: string;
}

export interface AttendanceRecord {
  id: string;
  userId: string;
  userName: string;
  date: string;
  checkInTime: string;
  checkOutTime?: string;
  isLate: boolean;
  isWfh: boolean;
  halfDayDeduction: boolean;
  status: 'PRESENT' | 'ABSENT' | 'HALF_DAY' | 'WFH' | 'ON_LEAVE';
  ipAddress?: string;
}

export interface ExitRecord {
  id: string;
  userId: string;
  employeeId?: string;
  resignationDate: string;
  proposedLastWorkingDate: string;
  approvedLastWorkingDate: string;
  reason: string;
  status: string;
  checklist16Steps: {
    stepNumber: number;
    department: 'HR' | 'IT' | 'ADMIN' | 'FINANCE';
    task: string;
    completed: boolean;
    ownerName: string;
    completedAt?: string;
  }[];
  fnfDetails?: {
    unpaidSalaryDays: number;
    unpaidSalaryAmount: number;
    leaveEncashmentDays: number;
    leaveEncashmentAmount: number;
    gratuityAmount: number;
    recoveriesOrAdvances: number;
    netPayable: number;
    status: string;
    relievingLetterIssued: boolean;
  };
}
