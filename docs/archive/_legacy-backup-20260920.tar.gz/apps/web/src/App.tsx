import { RouterProvider } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { TenantBrandingProvider } from '@/context/TenantBrandingContext';
import { RealtimeProvider } from '@/context/RealtimeContext';
import { TooltipProvider } from '@/shared/components/ui/Tooltip';
import { ShortcutsProvider } from '@/platform/shortcuts/ShortcutsProvider';
import { router } from '@/platform/routing/router';

function AppInner() {
  const { loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center space-y-4">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-rose-500 via-indigo-600 to-purple-600 animate-pulse flex items-center justify-center text-2xl shadow-xl shadow-indigo-600/30">
          🌸
        </div>
        <div className="text-sm font-semibold text-slate-300">
          Initializing Sachhi Saheli SaaS ERP...
        </div>
      </div>
    );
  }

  return (
    <TooltipProvider delayDuration={250} skipDelayDuration={100}>
      <ShortcutsProvider>
        <RouterProvider router={router} />
      </ShortcutsProvider>
    </TooltipProvider>
  );
}

export function App() {
  return (
    <TenantBrandingProvider>
      <AuthProvider>
        <RealtimeProvider>
          <AppInner />
        </RealtimeProvider>
      </AuthProvider>
    </TenantBrandingProvider>
  );
}

export default App;
