import { User } from './types';

const API_BASE = '/api';

export const apiClient = {
  activeTenantId: 'sachhi-saheli-delhi',

  setTenantId(tenantId: string) {
    this.activeTenantId = tenantId;
  },

  getHeaders: (simulatedUser?: User | null) => {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'x-tenant-id': apiClient.activeTenantId,
    };
    if (simulatedUser) {
      headers['x-simulated-user-id'] = simulatedUser.id;
      headers['x-simulated-role'] = simulatedUser.role;
    }
    return headers;
  },

  // 1. Tenant & Dynamic Whitelabeling
  async getTenantBranding(): Promise<any> {
    const res = await fetch(`${API_BASE}/tenant/branding`, {
      headers: this.getHeaders(),
    });
    return res.json();
  },

  async getAllTenants(): Promise<any> {
    const res = await fetch(`${API_BASE}/tenant/all`, {
      headers: this.getHeaders(),
    });
    return res.json();
  },

  async updateTenantBranding(updates: any, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/tenant/branding`, {
      method: 'PATCH',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify(updates),
    });
    return res.json();
  },

  // 2. Auth & Personas
  async getPersonas(): Promise<User[]> {
    const res = await fetch(`${API_BASE}/auth/personas`, {
      headers: this.getHeaders(),
    });
    const data = await res.json();
    return data.data || [];
  },

  async getMe(simulatedUser?: User | null): Promise<User> {
    const res = await fetch(`${API_BASE}/auth/me`, {
      headers: this.getHeaders(simulatedUser),
    });
    const data = await res.json();
    return data.data;
  },

  // 3. Workflows & Approvals
  async getWorkflows(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/workflows`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async getInbox(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/workflows/inbox`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async approveWorkflow(id: string, comments: string, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/workflows/${id}/approve`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify({ comments }),
    });
    return res.json();
  },

  async rejectWorkflow(id: string, comments: string, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/workflows/${id}/reject`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify({ comments }),
    });
    return res.json();
  },

  // 4. Employees & Master Directory
  async getEmployees(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/employees`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  // 5. Attendance & Biometrics
  async getAttendance(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/attendance`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async punchIn(isWfh: boolean, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/attendance/check-in`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify({ isWfh }),
    });
    return res.json();
  },

  async checkIn(payload: any, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/attendance/check-in`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  async punchOut(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/attendance/check-out`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  // 6. Leave Management
  async getLeaveBalances(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/leave/balances`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async applyLeave(payload: any, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/leave/apply`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  // 7. Payroll & Statutory
  async getPayrollSummary(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/payroll/summary`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async getPayslip(userId: string, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/payroll/payslip/${userId}`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  // 8. Exit & Settlement
  async getExitRecords(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/exit`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async updateExitChecklist(exitId: string, stepNumber: number, completed: boolean, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/exit/${exitId}/checklist/${stepNumber}`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify({ completed }),
    });
    return res.json();
  },

  // 9. Recruitment & Candidates
  async getRequisitions(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/recruitment/requisitions`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async createRequisition(payload: any, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/recruitment/requisitions`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  async getCandidates(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/recruitment/candidates`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async createCandidate(payload: any, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/recruitment/candidates`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  async updateCandidateStage(id: string, stage: string, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/recruitment/candidates/${id}/stage`, {
      method: 'PATCH',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify({ stage }),
    });
    return res.json();
  },

  async completeReferenceCheck(candidateId: string, payload: any, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/recruitment/candidates/${candidateId}/reference-check`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  async generateOffer(candidateId: string, payload: any, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/recruitment/candidates/${candidateId}/generate-offer`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  // 10. Onboarding & Induction
  async getOnboarding(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/onboarding/checklists`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async createOnboarding(payload: any, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/onboarding/checklists`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  async updateOnboardingTask(checklistId: string, taskId: string, completed: boolean, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/onboarding/checklists/${checklistId}/task/${taskId}`, {
      method: 'PATCH',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify({ completed }),
    });
    return res.json();
  },

  async confirmProbation(checklistId: string, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/onboarding/checklists/${checklistId}/confirm-probation`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  // 11. Performance & SMART KRAs
  async getAppraisals(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/performance/appraisals`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async submitSelfReview(appraisalId: string, rating: number, comments: string, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/performance/appraisals/${appraisalId}/self-review`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify({ rating, comments }),
    });
    return res.json();
  },

  async submitManagerReview(appraisalId: string, rating: number, comments: string, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/performance/appraisals/${appraisalId}/manager-review`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify({ rating, comments }),
    });
    return res.json();
  },

  async submitPresidentCalibration(appraisalId: string, rating: number, comments: string, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/performance/appraisals/${appraisalId}/president-calibration`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify({ rating, comments }),
    });
    return res.json();
  },

  // 12. Travel & Reimbursements
  async getTours(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/travel/tours`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async createTour(payload: any, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/travel/tours`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  async getExpenseClaims(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/travel/claims`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async createExpenseClaim(payload: any, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/travel/claims`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  async applyEmergencyAdvance(payload: any, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/hris/travel/emergency-advance`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  // 13. Finance, Invoices & COA
  async getFinanceCOA(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/finance/coa`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async getFinanceInvoices(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/finance/invoices`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async createInvoice(payload: any, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/finance/invoices`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  async payInvoice(invoiceId: string, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/finance/invoices/${invoiceId}/pay`, {
      method: 'PATCH',
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  // 14. CRM & Stakeholders
  async getCrmPipeline(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/crm/pipeline`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async createCrmContact(payload: any, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/crm/contacts`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  async updateCrmStage(id: string, stage: string, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/crm/contacts/${id}/stage`, {
      method: 'PATCH',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify({ stage }),
    });
    return res.json();
  },

  // 15. PPM & Project Tasks
  async getPpmProjects(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/ppm/projects`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async getPpmTasks(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/ppm/tasks`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async createPpmTask(payload: any, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/ppm/tasks`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  async updatePpmTaskStage(id: string, stage: string, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/ppm/tasks/${id}/stage`, {
      method: 'PATCH',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify({ stage }),
    });
    return res.json();
  },

  async getPpmTimesheets(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/ppm/timesheets`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async logTimesheet(payload: any, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/ppm/timesheets`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  // 16. Record Chatter & Activity Stream
  async getChatter(recordType: string, recordId: string, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/chatter/${recordType}/${recordId}`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async postChatterNote(recordType: string, recordId: string, content: string, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/chatter/${recordType}/${recordId}/note`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify({ content }),
    });
    return res.json();
  },

  async scheduleChatterActivity(recordType: string, recordId: string, activityType: string, content: string, dueDate: string, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/chatter/${recordType}/${recordId}/activity`, {
      method: 'POST',
      headers: this.getHeaders(simulatedUser),
      body: JSON.stringify({ activityType, content, dueDate }),
    });
    return res.json();
  },

  async toggleChatterActivity(activityId: string, simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/chatter/activity/${activityId}/toggle`, {
      method: 'PATCH',
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  // 17. Statutory Compliance
  async getAuditLogs(simulatedUser?: User | null): Promise<any> {
    const res = await fetch(`${API_BASE}/compliance/audit-logs`, {
      headers: this.getHeaders(simulatedUser),
    });
    return res.json();
  },

  async calculateGratuity(basicSalary: number, tenureYears: number): Promise<any> {
    const res = await fetch(`${API_BASE}/compliance/calculate-gratuity`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ basicSalary, tenureYears }),
    });
    return res.json();
  },

  async calculatePF(basicPlusDA: number): Promise<any> {
    const res = await fetch(`${API_BASE}/compliance/calculate-pf`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ basicPlusDA }),
    });
    return res.json();
  },

  // 18. Document Generation (Worker Microservice)
  async downloadPayslipPdf(employeeId: string, monthYear?: string, simulatedUser?: User | null): Promise<Blob> {
    const url = new URL(`${API_BASE}/documents/payslip/${employeeId}`);
    if (monthYear) url.searchParams.append('monthYear', monthYear);
    const res = await fetch(url.toString(), {
      headers: this.getHeaders(simulatedUser),
    });
    if (!res.ok) throw new Error('Failed to generate payslip PDF');
    return res.blob();
  },

  async downloadRelievingPdf(employeeId: string, simulatedUser?: User | null): Promise<Blob> {
    const res = await fetch(`${API_BASE}/documents/relieving/${employeeId}`, {
      headers: this.getHeaders(simulatedUser),
    });
    if (!res.ok) throw new Error('Failed to generate relieving letter PDF');
    return res.blob();
  },
};
