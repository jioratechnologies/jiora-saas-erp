import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';

const app = createApp();

describe('Recruitment & Statutory 2-Reference Check Rule Enforcement', () => {
  let candidateId: string;

  it('should create a new candidate in SOURCED stage', async () => {
    const res = await request(app)
      .post('/api/hris/recruitment/candidates')
      .set('x-tenant-id', 'sachhi-saheli-delhi')
      .set('x-simulated-role', 'HR')
      .send({
        name: 'Tanvi Agarwal',
        email: 'tanvi.a@gmail.com',
        phone: '+91 99887 66554',
        appliedRole: 'Senior Program Associate',
      });

    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.data.stage).toBe('SOURCED');
    candidateId = res.body.data.id;
  });

  it('should reject offer generation if candidate has fewer than 2 verified reference checks', async () => {
    const res = await request(app)
      .post(`/api/hris/recruitment/candidates/${candidateId}/generate-offer`)
      .set('x-tenant-id', 'sachhi-saheli-delhi')
      .set('x-simulated-role', 'HR')
      .send({ offeredCtc: 650000, joiningDate: '2026-11-01' });

    expect(res.status).toBe(422);
    expect(res.body.success).toBe(false);
    expect(res.body.error.code).toBe('STATUTORY_COMPLIANCE_BREACH');
    expect(res.body.error.message).toContain('2 verified reference checks required');
  });

  it('should allow offer generation after 2 reference checks are completed', async () => {
    // 1st Reference Check
    await request(app)
      .post(`/api/hris/recruitment/candidates/${candidateId}/reference-check`)
      .set('x-tenant-id', 'sachhi-saheli-delhi')
      .set('x-simulated-role', 'HR')
      .send({ referee: 'Prof. S. Sen (TISS Mumbai)', designation: 'Dean', feedback: 'Diligent research skills.' });

    // 2nd Reference Check
    await request(app)
      .post(`/api/hris/recruitment/candidates/${candidateId}/reference-check`)
      .set('x-tenant-id', 'sachhi-saheli-delhi')
      .set('x-simulated-role', 'HR')
      .send({ referee: 'Meera Das (Oxfam India)', designation: 'Senior Manager', feedback: 'High integrity and dedication.' });

    // Generate Offer now
    const res = await request(app)
      .post(`/api/hris/recruitment/candidates/${candidateId}/generate-offer`)
      .set('x-tenant-id', 'sachhi-saheli-delhi')
      .set('x-simulated-role', 'HR')
      .send({ offeredCtc: 650000, joiningDate: '2026-11-01' });

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.stage).toBe('OFFER_SENT');
    expect(res.body.data.offerDetails.offeredCtc).toBe(650000);
  });
});
