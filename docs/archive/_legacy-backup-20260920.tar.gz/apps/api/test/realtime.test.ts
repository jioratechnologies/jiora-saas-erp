import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import http from 'http';
import { io as Client, Socket as ClientSocket } from 'socket.io-client';
import { initSocketServer, emitToTenant, emitToRecord } from '../src/core/realtime/socketServer.js';

describe('Enterprise Real-Time WebSocket Engine & Multi-Tenant Isolation', () => {
  let httpServer: http.Server;
  let serverPort: number;
  let client1: ClientSocket;
  let client2: ClientSocket;

  beforeAll(async () => {
    httpServer = http.createServer();
    initSocketServer(httpServer);

    await new Promise<void>((resolve) => {
      httpServer.listen(0, () => {
        const addr = httpServer.address() as any;
        serverPort = addr.port;
        resolve();
      });
    });
  });

  afterAll(async () => {
    if (client1?.connected) client1.disconnect();
    if (client2?.connected) client2.disconnect();
    await new Promise<void>((resolve) => httpServer.close(() => resolve()));
  });

  it('should allow multi-tenant client connection and handshake with tenant authentication', async () => {
    client1 = Client(`http://localhost:${serverPort}`, {
      transports: ['websocket'],
      auth: {
        tenantId: 'sachhi-saheli-delhi',
        userId: 'usr_emp_1',
        userName: 'Rohan Gupta',
        role: 'EMPLOYEE',
      },
    });

    await new Promise<void>((resolve, reject) => {
      client1.on('connect', () => resolve());
      client1.on('connect_error', (err) => reject(err));
    });

    expect(client1.connected).toBe(true);
  });

  it('should deliver broadcast events to clients belonging to the target tenant', async () => {
    const receivedPromise = new Promise<any>((resolve) => {
      client1.on('announcement:general', (data) => {
        resolve(data);
      });
    });

    emitToTenant('sachhi-saheli-delhi', 'announcement:general', {
      message: 'Staff meeting at 11:00 AM regarding Delhi Health Drive',
    });

    const received = await receivedPromise;
    expect(received.payload.message).toContain('Delhi Health Drive');
    expect(received.tenantId).toBe('sachhi-saheli-delhi');
  });

  it('should maintain strict tenant isolation (Tenant B client does NOT receive Tenant A broadcasts)', async () => {
    client2 = Client(`http://localhost:${serverPort}`, {
      transports: ['websocket'],
      auth: {
        tenantId: 'apex-global-tech',
        userId: 'usr_apex_dev',
        userName: 'Apex Dev',
        role: 'EMPLOYEE',
      },
    });

    await new Promise<void>((resolve) => {
      client2.on('connect', () => resolve());
    });

    let client2Received = false;
    client2.on('confidential:sachhi_saheli', () => {
      client2Received = true;
    });

    emitToTenant('sachhi-saheli-delhi', 'confidential:sachhi_saheli', {
      grantBudget: 5000000,
    });

    // Wait 150ms to ensure no event leaked to client2
    await new Promise((r) => setTimeout(r, 150));
    expect(client2Received).toBe(false);
  });

  it('should broadcast record chatter events specifically to subscribed record viewers', async () => {
    // Client1 subscribes to candidate record 'cand_001'
    client1.emit('subscribe:record', {
      recordType: 'candidate',
      recordId: 'cand_001',
    });

    // Give socket a brief moment to join room
    await new Promise((r) => setTimeout(r, 50));

    const recordMessagePromise = new Promise<any>((resolve) => {
      client1.on('chatter:new_message', (data) => {
        resolve(data);
      });
    });

    emitToRecord('sachhi-saheli-delhi', 'candidate', 'cand_001', 'chatter:new_message', {
      id: 'msg_999',
      content: 'Second reference check completed successfully.',
    });

    const chatterData = await recordMessagePromise;
    expect(chatterData.recordType).toBe('candidate');
    expect(chatterData.recordId).toBe('cand_001');
    expect(chatterData.payload.content).toContain('Second reference check');
  });
});
