import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';

const app = createApp();

describe('Indian Statutory Labour Law Compliance Engine', () => {
  it('should accurately calculate Payment of Gratuity Act 1972 formula: (15 * Basic * Years) / 26', async () => {
    const res = await request(app)
      .post('/api/compliance/calculate-gratuity')
      .send({ basicSalary: 30000, tenureYears: 6 });

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.isEligible).toBe(true);
    expect(res.body.gratuityAmount).toBe(103846);
    expect(res.body.formula).toBe('(15 * Last Drawn Basic Salary * Tenure in Completed Years) / 26');
  });

  it('should return ₹0 Gratuity if employee has less than 5 years of service', async () => {
    const res = await request(app)
      .post('/api/compliance/calculate-gratuity')
      .send({ basicSalary: 30000, tenureYears: 4.2 });

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.isEligible).toBe(false);
    expect(res.body.gratuityAmount).toBe(0);
    expect(res.body.condition).toContain('Minimum 5 continuous years of full-time service required');
  });

  it('should accurately calculate EPF & MP Act 1952 statutory contributions (12% employee + 12% employer)', async () => {
    const res = await request(app)
      .post('/api/compliance/calculate-pf')
      .send({ basicPlusDA: 30000 });

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.employeeContribution.amount).toBe(3600);
    expect(res.body.employerContribution.totalAmount).toBe(3600);
    expect(res.body.totalMonthlyPFDeposit).toBe(7200);
    expect(res.body.act).toContain('Employees Provident Funds');
  });
});
