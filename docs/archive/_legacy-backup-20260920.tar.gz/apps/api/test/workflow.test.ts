import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';

const app = createApp();

describe('16 BRD Workflows State Machine & Multi-Level Approvals', () => {
  it('should list pending approvals in inbox for President', async () => {
    const res = await request(app)
      .get('/api/workflows/inbox')
      .set('x-tenant-id', 'sachhi-saheli-delhi')
      .set('x-simulated-role', 'PRESIDENT');

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(Array.isArray(res.body.data)).toBe(true);
  });

  it('should advance workflow stage upon approval by authorized approver', async () => {
    // Approve Maternity Leave stage as HR
    const res = await request(app)
      .post('/api/workflows/wf_leave_001/approve')
      .set('x-tenant-id', 'sachhi-saheli-delhi')
      .set('x-simulated-user-id', 'usr_hr_head')
      .set('x-simulated-role', 'HR')
      .send({ comments: 'Verified medical documentation and doctor fitness.' });

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.currentStage).toBe('PENDING_PRESIDENT');
  });

  it('should block unauthorized employee from approving executive workflows', async () => {
    const res = await request(app)
      .post('/api/workflows/wf_advance_003/approve')
      .set('x-tenant-id', 'sachhi-saheli-delhi')
      .set('x-simulated-user-id', 'usr_emp_1')
      .set('x-simulated-role', 'EMPLOYEE')
      .send({ comments: 'Unauthorized attempt to self-approve.' });

    expect(res.status).toBe(403);
    expect(res.body.success).toBe(false);
    expect(res.body.error.code).toBe('FORBIDDEN_ACCESS');
  });
});
