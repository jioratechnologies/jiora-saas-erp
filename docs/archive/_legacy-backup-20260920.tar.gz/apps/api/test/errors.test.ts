import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';

const app = createApp();

describe('Standardized RFC 7807 Error Envelopes & Correlation IDs', () => {
  it('should return uniform error envelope and propagate X-Request-ID', async () => {
    const customReqId = 'req_test_correlation_123';
    const res = await request(app)
      .post('/api/hris/leave/apply')
      .set('x-tenant-id', 'sachhi-saheli-delhi')
      .set('x-request-id', customReqId)
      .send({}); // Empty payload triggers ValidationError

    expect(res.status).toBe(400);
    expect(res.headers['x-request-id']).toBe(customReqId);
    expect(res.body.success).toBe(false);
    expect(res.body.error).toBeDefined();
    expect(res.body.error.code).toBe('VALIDATION_ERROR');
    expect(res.body.error.requestId).toBe(customReqId);
    expect(typeof res.body.error.timestamp).toBe('string');
  });
});
