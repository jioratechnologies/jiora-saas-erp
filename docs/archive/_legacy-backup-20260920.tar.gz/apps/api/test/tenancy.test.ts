import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';

const app = createApp();

describe('Multi-Tenancy & Dynamic Whitelabeling Engine', () => {
  it('should fetch active tenant branding for Sachhi Saheli', async () => {
    const res = await request(app)
      .get('/api/tenant/branding')
      .set('x-tenant-id', 'sachhi-saheli-delhi');

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.name).toBe('Sachhi Saheli NGO');
    expect(res.body.data.primaryColor).toBe('#4f46e5');
    expect(res.body.data.currency).toBe('INR');
  });

  it('should allow whitelabel customization of colors, logo, and brand name', async () => {
    const res = await request(app)
      .patch('/api/tenant/branding')
      .set('x-tenant-id', 'sachhi-saheli-delhi')
      .set('x-simulated-role', 'PRESIDENT')
      .send({
        name: 'Sachhi Saheli Global Foundation',
        primaryColor: '#6366f1',
        accentColor: '#10b981',
      });

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.name).toBe('Sachhi Saheli Global Foundation');
    expect(res.body.data.primaryColor).toBe('#6366f1');
  });

  it('should return 400 TenantError when an invalid tenant ID is requested', async () => {
    const res = await request(app)
      .get('/api/tenant/branding')
      .set('x-tenant-id', 'non-existent-tenant-999');

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error.code).toBe('INVALID_TENANT');
  });
});
