-- =========================================================================
-- Sachhi Saheli SaaS ERP & HRIS — Multi-Tenant Seed Data
-- =========================================================================

-- 1. Tenants (Dynamic Whitelabel Organizations)
INSERT INTO tenants (id, name, slug, logo_url, favicon_url, primary_color, accent_color, legal_entity_type, currency, tagline)
VALUES 
(
  'sachhi-saheli-delhi',
  'Sachhi Saheli NGO',
  'sachhi-saheli',
  '/assets/logo-sachhi.svg',
  '/assets/favicon.ico',
  '#4f46e5',
  '#065f46',
  'Registered Non-Profit NGO',
  'INR',
  'Promoting Menstrual Health, Gender Equity & Adolescent Well-being'
),
(
  'apex-global-tech',
  'Apex Global Technology',
  'apex-tech',
  '/assets/logo-apex.svg',
  '/assets/favicon.ico',
  '#0284c7',
  '#0f766e',
  'Private Limited Enterprise',
  'USD',
  'Next-Gen Cloud Architecture & Enterprise Digital Solutions'
)
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, tagline = EXCLUDED.tagline;

-- 2. Users (3-Tier Hierarchy: Super Admin, App Developer, Client Roles)
INSERT INTO users (id, tenant_id, employee_id, name, email, role, department, designation, reporting_manager_id, joining_date, status)
VALUES
(
  'usr_super_admin',
  'sachhi-saheli-delhi',
  'SA-000',
  'Gaurav Sharma (Platform Operator)',
  'superadmin@jioratech.com',
  'SUPER_ADMIN',
  'Platform Infrastructure',
  'Global SaaS Super Administrator',
  NULL,
  '2024-01-01',
  'ACTIVE'
),
(
  'usr_app_dev',
  'sachhi-saheli-delhi',
  'DEV-001',
  'Devendra Rao (System Integrator)',
  'developer@jioratech.com',
  'APP_DEVELOPER',
  'Product & Integrations',
  'Lead Solutions Architect',
  'usr_super_admin',
  '2024-06-01',
  'ACTIVE'
),
(
  'usr_president',
  'sachhi-saheli-delhi',
  'SS-001',
  'Dr. Surbhi Singh',
  'president@sachhisaheli.org',
  'PRESIDENT',
  'Executive Leadership',
  'Founder & President',
  NULL,
  '2016-01-15',
  'ACTIVE'
),
(
  'usr_hr_head',
  'sachhi-saheli-delhi',
  'SS-002',
  'Pooja Sharma',
  'pooja.sharma@sachhisaheli.org',
  'HR',
  'Human Resources',
  'Head of People & Operations',
  'usr_president',
  '2020-03-01',
  'ACTIVE'
),
(
  'usr_finance_head',
  'sachhi-saheli-delhi',
  'SS-003',
  'Vikram Malhotra',
  'vikram.m@sachhisaheli.org',
  'FINANCE',
  'Finance & Accounts',
  'Finance Controller',
  'usr_president',
  '2020-07-15',
  'ACTIVE'
),
(
  'usr_manager',
  'sachhi-saheli-delhi',
  'SS-004',
  'Anjali Verma',
  'anjali.v@sachhisaheli.org',
  'MANAGER',
  'Programs & Outreach',
  'Director of Programs',
  'usr_president',
  '2021-02-10',
  'ACTIVE'
),
(
  'usr_emp_1',
  'sachhi-saheli-delhi',
  'SS-012',
  'Rohan Gupta',
  'rohan.g@sachhisaheli.org',
  'EMPLOYEE',
  'Programs & Outreach',
  'Senior Project Coordinator',
  'usr_manager',
  '2022-04-12',
  'ACTIVE'
),
(
  'usr_emp_2',
  'sachhi-saheli-delhi',
  'SS-019',
  'Priya Sen',
  'priya.s@sachhisaheli.org',
  'EMPLOYEE',
  'Communications & Advocacy',
  'Content & Media Specialist',
  'usr_manager',
  '2023-01-20',
  'ACTIVE'
),
(
  'usr_emp_3',
  'sachhi-saheli-delhi',
  'SS-024',
  'Amit Patel',
  'amit.p@sachhisaheli.org',
  'EMPLOYEE',
  'Field Operations',
  'Community Field Officer',
  'usr_manager',
  '2024-08-01',
  'PROBATION'
)
ON CONFLICT (id) DO NOTHING;

-- 3. Employee Master Profiles
INSERT INTO employee_profiles (id, tenant_id, user_id, personal_info, job_details, salary_structure, statutory_info, documents_verified, document_checklist)
VALUES
(
  'prof_rohan',
  'sachhi-saheli-delhi',
  'usr_emp_1',
  '{"dob": "1993-05-14", "gender": "MALE", "phone": "+91 98765 43210", "address": "B-42, Lajpat Nagar IV, New Delhi", "emergencyContact": "Sunita Gupta (+91 98765 43211)", "bloodGroup": "B+"}'::jsonb,
  '{"title": "Senior Project Coordinator", "department": "Programs & Outreach", "grade": "L2", "joiningDate": "2022-04-12", "probationEnd": "2022-10-12", "probationStatus": "CONFIRMED", "employmentType": "PERMANENT", "reportingManager": "Anjali Verma"}'::jsonb,
  '{"ctcAnnual": 720000, "basicMonthly": 30000, "hraMonthly": 15000, "specialAllowanceMonthly": 15000, "pfDeductionMonthly": 3600, "gratuityEligible": false, "medicalInsuranceCover": 300000, "accidentInsuranceCover": 500000}'::jsonb,
  '{"pan": "ABCDE1234F", "aadhaarMasked": "XXXX-XXXX-8921", "uan": "101298347192", "pfNumber": "DL/CPM/10293/012", "bankAccountNumber": "918237461928", "ifscCode": "HDFC0001234", "bankName": "HDFC Bank Ltd, New Delhi"}'::jsonb,
  true,
  '{"degreeCertificate": true, "clearanceLetterPrevEmployer": true, "prevPayslips": true, "photoId": true, "dobProof": true, "addressProof": true, "photographs": true}'::jsonb
),
(
  'prof_priya',
  'sachhi-saheli-delhi',
  'usr_emp_2',
  '{"dob": "1995-11-22", "gender": "FEMALE", "phone": "+91 98112 23344", "address": "Flat 302, Mayur Vihar Phase 1, Delhi", "emergencyContact": "Rajesh Sen (+91 98112 23345)", "bloodGroup": "O+"}'::jsonb,
  '{"title": "Content & Media Specialist", "department": "Communications & Advocacy", "grade": "L2", "joiningDate": "2023-01-20", "probationEnd": "2023-07-20", "probationStatus": "CONFIRMED", "employmentType": "PERMANENT", "reportingManager": "Anjali Verma"}'::jsonb,
  '{"ctcAnnual": 600000, "basicMonthly": 25000, "hraMonthly": 12500, "specialAllowanceMonthly": 12500, "pfDeductionMonthly": 3000, "gratuityEligible": false, "medicalInsuranceCover": 300000, "accidentInsuranceCover": 500000}'::jsonb,
  '{"pan": "XYZAB5678C", "aadhaarMasked": "XXXX-XXXX-4512", "uan": "101456789012", "pfNumber": "DL/CPM/10293/019", "bankAccountNumber": "002918273645", "ifscCode": "ICIC0000029", "bankName": "ICICI Bank, Mayur Vihar"}'::jsonb,
  true,
  '{"degreeCertificate": true, "clearanceLetterPrevEmployer": true, "prevPayslips": true, "photoId": true, "dobProof": true, "addressProof": true, "photographs": true}'::jsonb
)
ON CONFLICT (id) DO NOTHING;

-- 4. Leave Balances
INSERT INTO leave_balances (tenant_id, user_id, casual_leave, sick_leave, earned_leave, maternity_leave, paternity_leave, adoption_leave, leave_without_pay, comp_off)
VALUES
(
  'sachhi-saheli-delhi',
  'usr_emp_1',
  '{"total": 10, "used": 2, "remaining": 8}'::jsonb,
  '{"total": 10, "used": 1, "remaining": 9}'::jsonb,
  '{"total": 15, "used": 3, "remaining": 12, "carryForward": 5}'::jsonb,
  '{"totalDays": 182, "used": 0, "remaining": 182}'::jsonb,
  '{"total": 5, "used": 0, "remaining": 5}'::jsonb,
  '{"total": 5, "used": 0, "remaining": 5}'::jsonb,
  '{"used": 0}'::jsonb,
  '{"available": 1}'::jsonb
),
(
  'sachhi-saheli-delhi',
  'usr_emp_2',
  '{"total": 10, "used": 1, "remaining": 9}'::jsonb,
  '{"total": 10, "used": 2, "remaining": 8}'::jsonb,
  '{"total": 15, "used": 0, "remaining": 15, "carryForward": 0}'::jsonb,
  '{"totalDays": 182, "used": 0, "remaining": 182}'::jsonb,
  '{"total": 5, "used": 0, "remaining": 5}'::jsonb,
  '{"total": 5, "used": 0, "remaining": 5}'::jsonb,
  '{"used": 0}'::jsonb,
  '{"available": 2}'::jsonb
)
ON CONFLICT (tenant_id, user_id) DO NOTHING;

-- 5. Attendance Sample (10:00 AM Late rule demonstration)
INSERT INTO attendance_records (id, tenant_id, user_id, user_name, date, check_in_time, is_late, is_wfh, half_day_deduction, status, ip_address)
VALUES
('att_01', 'sachhi-saheli-delhi', 'usr_emp_1', 'Rohan Gupta', CURRENT_DATE, '09:45:00', false, false, false, 'PRESENT', '192.168.1.104'),
('att_02', 'sachhi-saheli-delhi', 'usr_emp_2', 'Priya Sen', CURRENT_DATE, '10:14:30', true, false, false, 'PRESENT', '192.168.1.118'),
('att_03', 'sachhi-saheli-delhi', 'usr_emp_3', 'Amit Patel', CURRENT_DATE, '09:30:00', false, true, false, 'WFH', '122.161.44.12')
ON CONFLICT (id) DO NOTHING;

-- 6. Recruitment Requisitions & Candidate Pipeline (5 stages & 2 reference checks)
INSERT INTO recruitment_requisitions (id, tenant_id, job_title, department, open_positions, budget_band_annual, experience_required, justification, status, requested_by)
VALUES
(
  'req_001',
  'sachhi-saheli-delhi',
  'Senior Monitoring & Evaluation (M&E) Lead',
  'Programs & Outreach',
  1,
  '₹ 8,00,000 - ₹ 9,50,000',
  '4-6 Years Social Sector',
  'Mandatory for tracking donor grant KPIs for 2026-2027 fiscal year.',
  'APPROVED',
  'usr_manager'
),
(
  'req_002',
  'sachhi-saheli-delhi',
  'Field Operations Coordinator - Lucknow',
  'Field Operations',
  2,
  '₹ 4,50,000 - ₹ 5,50,000',
  '2-3 Years Field Experience',
  'To support rural menstrual hygiene outreach across 20 schools in UP.',
  'PENDING_APPROVAL',
  'usr_manager'
)
ON CONFLICT (id) DO NOTHING;

INSERT INTO candidates (id, tenant_id, requisition_id, name, email, phone, applied_role, stage, interview_score, interview_feedback, reference_checks, offer_details)
VALUES
(
  'cand_01',
  'sachhi-saheli-delhi',
  'req_001',
  'Kavita Mathur',
  'kavita.m@gmail.com',
  '+91 98711 55667',
  'Senior M&E Lead',
  'OFFER_SENT',
  92,
  'Exceptional background in non-profit data evaluation and USAID projects.',
  '[{"referee": "Dr. V. Raman (Ex-Director, Pratham)", "designation": "Director", "feedback": "Highly dependable, outstanding analytical skills.", "verified": true, "verifiedDate": "2026-09-12"}, {"referee": "Anita Roy (Program Head, Care India)", "designation": "Program Head", "feedback": "Strong cross-functional leadership and integrity.", "verified": true, "verifiedDate": "2026-09-14"}]'::jsonb,
  '{"offeredCtc": 900000, "joiningDate": "2026-10-15", "status": "PENDING_ACCEPTANCE", "signedBy": "Dr. Surbhi Singh"}'::jsonb
),
(
  'cand_02',
  'sachhi-saheli-delhi',
  'req_001',
  'Nikhil Deshmukh',
  'nikhil.d@outlook.com',
  '+91 98220 44331',
  'Senior M&E Lead',
  'INTERVIEW',
  84,
  'Strong quantitative skills. Final round panel scheduled.',
  '[]'::jsonb,
  '{}'::jsonb
),
(
  'cand_03',
  'sachhi-saheli-delhi',
  'req_002',
  'Sunil Yadav',
  'sunil.yadav@gmail.com',
  '+91 97188 99001',
  'Field Operations Coordinator',
  'SCREENING',
  75,
  'Resume shortlisted for initial telephonic screening.',
  '[]'::jsonb,
  '{}'::jsonb
)
ON CONFLICT (id) DO NOTHING;

-- 7. Onboarding Checklists (Standard, Intern, Contractual)
INSERT INTO onboarding_checklists (id, tenant_id, user_id, employee_category, tasks, probation_end_date, probation_status, confirmation_letter_issued)
VALUES
(
  'onb_001',
  'sachhi-saheli-delhi',
  'usr_emp_3',
  'STANDARD',
  '[{"id": "t1", "department": "IT", "task": "Google Workspace & Slack account provisioned", "completed": true}, {"id": "t2", "department": "ADMIN", "task": "Laptop & ID Keycard issued", "completed": true}, {"id": "t3", "department": "HR", "task": "POSH & Child Protection policy sign-off", "completed": true}, {"id": "t4", "department": "MANAGER", "task": "Initial 30-day orientation plan set", "completed": false}]'::jsonb,
  '2025-02-01',
  'IN_PROBATION',
  false
)
ON CONFLICT (id) DO NOTHING;

-- 8. Performance & SMART KRAs
INSERT INTO appraisals (id, tenant_id, user_id, cycle_year, kras, self_rating, self_comments, manager_rating, manager_comments, president_calibrated_rating, president_comments, status)
VALUES
(
  'appr_001',
  'sachhi-saheli-delhi',
  'usr_emp_1',
  '2026-2027',
  '[{"kra": "Menstrual Hygiene Workshops", "metric": "Conduct 50 sessions across government schools", "weightage": 40, "achievement": 92}, {"kra": "Beneficiary Data Integrity", "metric": "Ensure 100% digital entry within 48h", "weightage": 30, "achievement": 95}, {"kra": "Volunteer Training", "metric": "Train 120 community mobilizers", "weightage": 30, "achievement": 88}]'::jsonb,
  4,
  'Surpassed outreach milestones in 4 key districts of Delhi NCR.',
  4,
  'Outstanding field initiative, strong stakeholder engagement.',
  5,
  'Calibrated to top 15% tier (Grade A performer). Recommended for promotion.',
  'PRESIDENT_CALIBRATED'
)
ON CONFLICT (id) DO NOTHING;

-- 9. Travel & Expense Claims
INSERT INTO travel_tours (id, tenant_id, user_id, destination, departure_date, return_date, purpose, city_tier, advance_requested, advance_disbursed, status)
VALUES
(
  'tour_001',
  'sachhi-saheli-delhi',
  'usr_emp_1',
  'Lucknow & Varanasi, Uttar Pradesh',
  '2026-09-24',
  '2026-09-28',
  'Launch of Project Kishori school sanitation baseline surveys.',
  'Tier-2',
  12000,
  true,
  'APPROVED'
)
ON CONFLICT (id) DO NOTHING;

INSERT INTO expense_claims (id, tenant_id, user_id, claim_type, items, total_amount, city_tier, status)
VALUES
(
  'exp_001',
  'sachhi-saheli-delhi',
  'usr_emp_1',
  'LOCAL_CONVEYANCE',
  '[{"date": "2026-09-17", "from": "Office", "to": "Govt Girls Sr Sec School, Rohini", "mode": "Auto/Metro", "amount": 340}, {"date": "2026-09-18", "from": "Office", "to": "District Magistrate Office, Delhi", "mode": "Cab", "amount": 460}]'::jsonb,
  800,
  'Tier-1',
  'APPROVED'
),
(
  'exp_002',
  'sachhi-saheli-delhi',
  'usr_emp_2',
  'HEALTH_CHECKUP',
  '[{"date": "2026-09-10", "facility": "Max Healthcare Diagnostics", "test": "Annual Comprehensive Wellness Panel", "amount": 2500}]'::jsonb,
  2500,
  'Tier-1',
  'APPROVED'
)
ON CONFLICT (id) DO NOTHING;

-- 10. Finance Chart of Accounts & Invoices (AR / AP)
INSERT INTO finance_coa (id, tenant_id, code, name, type, balance)
VALUES
('coa_1000', 'sachhi-saheli-delhi', '1000', 'Current Assets', 'ASSET', 4850000),
('coa_1010', 'sachhi-saheli-delhi', '1010', 'HDFC Operating Bank Account', 'ASSET', 3420000),
('coa_1020', 'sachhi-saheli-delhi', '1020', 'Petty Cash', 'ASSET', 50000),
('coa_1030', 'sachhi-saheli-delhi', '1030', 'Employee Travel Advances', 'ASSET', 45000),
('coa_2000', 'sachhi-saheli-delhi', '2000', 'Current Liabilities', 'LIABILITY', 820000),
('coa_2010', 'sachhi-saheli-delhi', '2010', 'Statutory Provident Fund Payable', 'LIABILITY', 215000),
('coa_2020', 'sachhi-saheli-delhi', '2020', 'TDS Withholding Tax Payable', 'LIABILITY', 140000),
('coa_4000', 'sachhi-saheli-delhi', '4000', 'Grants & Institutional Donations', 'REVENUE', 12500000),
('coa_5000', 'sachhi-saheli-delhi', '5000', 'Operating Expenses', 'EXPENSE', 7400000),
('coa_5010', 'sachhi-saheli-delhi', '5010', 'Payroll & Salaries (Synced from HRIS)', 'EXPENSE', 4200000),
('coa_5020', 'sachhi-saheli-delhi', '5020', 'Program Outreach & Community Workshops', 'EXPENSE', 2100000)
ON CONFLICT (id) DO NOTHING;

INSERT INTO invoices (id, tenant_id, invoice_type, invoice_number, party, description, amount, due_date, status)
VALUES
('inv_ar_01', 'sachhi-saheli-delhi', 'AR', 'GRANT-AR-001', 'Azim Premji Foundation (Tranche 2)', 'Adolescent Health Education Grant Q3', 2250000, '2026-09-30', 'DUE'),
('inv_ar_02', 'sachhi-saheli-delhi', 'AR', 'GRANT-AR-002', 'UNICEF India Milestone Grant', 'School WASH Sanitation Baseline Milestone', 1800000, '2026-10-15', 'PAID'),
('inv_ap_01', 'sachhi-saheli-delhi', 'AP', 'INV-AP-0921', 'Airtel Broadband & Telecom', 'Monthly lease-line & fiber bandwidth', 18450, '2026-09-25', 'APPROVED'),
('inv_ap_02', 'sachhi-saheli-delhi', 'AP', 'INV-AP-0922', 'Office Stationery & Printing Hub', 'Menstrual health awareness booklets (5000 copies)', 34200, '2026-09-28', 'PENDING_APPROVAL')
ON CONFLICT (id) DO NOTHING;

-- 11. CRM Contacts & Donor Pipeline
INSERT INTO crm_contacts (id, tenant_id, org_name, contact_person, stage, grant_amount, focus)
VALUES
('crm_01', 'sachhi-saheli-delhi', 'Azim Premji Foundation', 'Meera Nambiar', 'PARTNERED', 4500000, 'Adolescent Health Education'),
('crm_02', 'sachhi-saheli-delhi', 'UNICEF India', 'Arunav Sengupta', 'PROPOSAL_SUBMITTED', 6000000, 'Menstrual Health in Rural Schools'),
('crm_03', 'sachhi-saheli-delhi', 'Bill & Melinda Gates Foundation', 'Dr. Linda Vance', 'CONTACTED', 8500000, 'Gender Equity & Sanitation'),
('crm_04', 'sachhi-saheli-delhi', 'HCL Foundation', 'Saurabh Rastogi', 'LEAD', 2500000, 'Delhi NCR Urban Slum Outreach')
ON CONFLICT (id) DO NOTHING;

-- 12. PPM Projects & Tasks
INSERT INTO ppm_projects (id, tenant_id, code, name, budget, spent, manager, progress_percent, status)
VALUES
('ppm_01', 'sachhi-saheli-delhi', 'PRJ-2026-DEL', 'Project Saheli: Delhi NCR Health Drive', 3500000, 2150000, 'Anjali Verma', 68, 'ON_TRACK'),
('ppm_02', 'sachhi-saheli-delhi', 'PRJ-2026-UP', 'Project Kishori: Uttar Pradesh Outreach', 4200000, 1840000, 'Rohan Gupta', 45, 'ON_TRACK'),
('ppm_03', 'sachhi-saheli-delhi', 'PRJ-2026-RES', 'Annual National Menstrual Health Survey', 1500000, 950000, 'Pooja Sharma', 82, 'NEARING_COMPLETION')
ON CONFLICT (id) DO NOTHING;

INSERT INTO ppm_tasks (id, tenant_id, project_id, title, assignee_id, assignee_name, stage, priority, due_date)
VALUES
('tsk_01', 'sachhi-saheli-delhi', 'ppm_01', 'Finalize workshop logistics in East Delhi zone', 'usr_emp_1', 'Rohan Gupta', 'IN_PROGRESS', 'HIGH', '2026-09-22'),
('tsk_02', 'sachhi-saheli-delhi', 'ppm_01', 'Print 3,000 adolescent awareness guidebooks', 'usr_emp_2', 'Priya Sen', 'REVIEW', 'MEDIUM', '2026-09-24'),
('tsk_03', 'sachhi-saheli-delhi', 'ppm_02', 'Procure portable hygiene sanitary incinerators', 'usr_emp_3', 'Amit Patel', 'TO_DO', 'HIGH', '2026-09-30'),
('tsk_04', 'sachhi-saheli-delhi', 'ppm_03', 'Publish baseline statistical dataset report', 'usr_hr_head', 'Pooja Sharma', 'DONE', 'URGENT', '2026-09-15')
ON CONFLICT (id) DO NOTHING;

-- 13. Workflows (The 16 BRD Approval Workflows Sample)
INSERT INTO workflows (id, tenant_id, workflow_type, title, requester_id, requester_name, requester_role, department, current_stage, stages, payload)
VALUES
(
  'wf_leave_001',
  'sachhi-saheli-delhi',
  'LEAVE_SPECIAL',
  'Maternity Leave Application (26 Weeks Statutory Entitlement)',
  'usr_emp_2',
  'Priya Sen',
  'EMPLOYEE',
  'Communications & Advocacy',
  'PENDING_HR',
  '[{"stage": "PENDING_MANAGER", "approverRole": "MANAGER", "approverId": "usr_manager", "approverName": "Anjali Verma", "decision": "APPROVED", "comments": "Medical certificate verified. Work redistribution agreed.", "actionDate": "2026-09-15T11:20:00Z"}, {"stage": "PENDING_HR", "approverRole": "HR", "approverId": "usr_hr_head", "approverName": "Pooja Sharma"}, {"stage": "PENDING_PRESIDENT", "approverRole": "PRESIDENT", "approverId": "usr_president", "approverName": "Dr. Surbhi Singh"}]'::jsonb,
  '{"leaveType": "MATERNITY_LEAVE", "startDate": "2026-10-01", "endDate": "2027-03-31", "days": 182, "statutoryAct": "Maternity Benefit (Amendment) Act 2017"}'::jsonb
),
(
  'wf_recruitment_004',
  'sachhi-saheli-delhi',
  'RECRUITMENT_REQUISITION',
  'Requisition: Senior M&E Lead (Monitoring & Evaluation)',
  'usr_manager',
  'Anjali Verma',
  'MANAGER',
  'Programs & Outreach',
  'PENDING_PRESIDENT',
  '[{"stage": "PENDING_HR", "approverRole": "HR", "approverId": "usr_hr_head", "approverName": "Pooja Sharma", "decision": "APPROVED", "comments": "Level 3 budget band validated against salary scales.", "actionDate": "2026-09-16T12:00:00Z"}, {"stage": "PENDING_PRESIDENT", "approverRole": "PRESIDENT", "approverId": "usr_president", "approverName": "Dr. Surbhi Singh"}]'::jsonb,
  '{"jobTitle": "Senior M&E Lead", "openPositions": 1, "budgetBandAnnual": "₹ 8,00,000 - ₹ 9,50,000"}'::jsonb
),
(
  'wf_advance_003',
  'sachhi-saheli-delhi',
  'EMERGENCY_SALARY_ADVANCE',
  'Emergency Medical Advance (₹50,000 / 10-Month EMI)',
  'usr_emp_1',
  'Rohan Gupta',
  'EMPLOYEE',
  'Programs & Outreach',
  'PENDING_FINANCE',
  '[{"stage": "PENDING_MANAGER", "approverRole": "MANAGER", "approverId": "usr_manager", "approverName": "Anjali Verma", "decision": "APPROVED", "comments": "Confirmed genuine emergency.", "actionDate": "2026-09-16T16:00:00Z"}, {"stage": "PENDING_FINANCE", "approverRole": "FINANCE", "approverId": "usr_finance_head", "approverName": "Vikram Malhotra"}, {"stage": "PENDING_PRESIDENT", "approverRole": "PRESIDENT", "approverId": "usr_president", "approverName": "Dr. Surbhi Singh"}]'::jsonb,
  '{"requestedAmount": 50000, "tenureMonths": 10, "monthlyEMI": 5000}'::jsonb
)
ON CONFLICT (id) DO NOTHING;

-- 14. Exit Records (16-Step Clearance Checklist)
INSERT INTO exit_records (id, tenant_id, user_id, resignation_date, approved_lwd, reason, status, checklist_16_steps, fnf_details)
VALUES
(
  'exit_001',
  'sachhi-saheli-delhi',
  'usr_emp_3',
  '2026-09-01',
  '2026-10-01',
  'Relocating to hometown for personal commitments.',
  'CLEARANCE_IN_PROGRESS',
  '[
    {"stepNumber": 1, "department": "HR", "task": "Resignation accepted & notice period finalized", "completed": true, "ownerName": "Pooja Sharma", "completedAt": "2026-09-02"},
    {"stepNumber": 2, "department": "HR", "task": "Exit interview scheduled & questionnaire completed", "completed": true, "ownerName": "Pooja Sharma", "completedAt": "2026-09-05"},
    {"stepNumber": 3, "department": "HR", "task": "Handover plan documented with Reporting Manager", "completed": true, "ownerName": "Anjali Verma", "completedAt": "2026-09-10"},
    {"stepNumber": 4, "department": "ADMIN", "task": "Physical ID Card & Office Access Keycard returned", "completed": false, "ownerName": "Admin Desk"},
    {"stepNumber": 5, "department": "ADMIN", "task": "Office keys and stationery inventory surrendered", "completed": false, "ownerName": "Admin Desk"},
    {"stepNumber": 6, "department": "IT", "task": "Organization laptop and peripheral inspection", "completed": false, "ownerName": "IT Support"},
    {"stepNumber": 7, "department": "IT", "task": "Google Workspace email & data backup created", "completed": false, "ownerName": "IT Admin"},
    {"stepNumber": 8, "department": "IT", "task": "ERP / CRM / Slack account access revoked", "completed": false, "ownerName": "IT Admin"},
    {"stepNumber": 9, "department": "FINANCE", "task": "Travel advance reconciliation & outstanding expense bills cleared", "completed": false, "ownerName": "Vikram Malhotra"},
    {"stepNumber": 10, "department": "FINANCE", "task": "Salary advance / loan balance check", "completed": false, "ownerName": "Vikram Malhotra"},
    {"stepNumber": 11, "department": "FINANCE", "task": "Pending days salary calculation", "completed": false, "ownerName": "Vikram Malhotra"},
    {"stepNumber": 12, "department": "HR", "task": "Earned Leave encashment balance computation", "completed": false, "ownerName": "Pooja Sharma"},
    {"stepNumber": 13, "department": "FINANCE", "task": "Gratuity eligibility check (Payment of Gratuity Act 1972)", "completed": false, "ownerName": "Vikram Malhotra"},
    {"stepNumber": 14, "department": "FINANCE", "task": "F&F statement generation and President approval", "completed": false, "ownerName": "Dr. Surbhi Singh"},
    {"stepNumber": 15, "department": "FINANCE", "task": "Disbursement of final payment to bank account", "completed": false, "ownerName": "Accounts Team"},
    {"stepNumber": 16, "department": "HR", "task": "Relieving Letter & Experience Certificate issuance", "completed": false, "ownerName": "Dr. Surbhi Singh"}
  ]'::jsonb,
  '{"unpaidSalaryDays": 30, "unpaidSalaryAmount": 25000, "leaveEncashmentDays": 8, "leaveEncashmentAmount": 6667, "gratuityAmount": 0, "netPayable": 31667, "status": "DRAFT", "relievingLetterIssued": false}'::jsonb
)
ON CONFLICT (id) DO NOTHING;

-- 15. Audit Logs & Chatter Stream
INSERT INTO audit_logs (id, tenant_id, timestamp, user_id, user_name, user_role, action, module, details, ip_address)
VALUES
('aud_001', 'sachhi-saheli-delhi', NOW() - INTERVAL '2 days', 'usr_president', 'Dr. Surbhi Singh', 'PRESIDENT', 'POLICY_ACK_PUBLISHED', 'COMPLIANCE', 'Published Annual Prevention of Sexual Harassment (POSH) & Code of Conduct 2026.', '103.21.14.88'),
('aud_002', 'sachhi-saheli-delhi', NOW() - INTERVAL '1 day', 'usr_finance_head', 'Vikram Malhotra', 'FINANCE', 'PAYROLL_STATUTORY_PF_RECONCILED', 'PAYROLL', 'Reconciled EPF electronic challan receipt (ECR) for all active personnel.', '192.168.1.5'),
('aud_003', 'sachhi-saheli-delhi', NOW() - INTERVAL '6 hours', 'usr_hr_head', 'Pooja Sharma', 'HR', 'RECRUITMENT_OFFER_PREPARED', 'RECRUITMENT', 'Candidate Kavita Mathur reference checks completed & verified.', '192.168.1.12')
ON CONFLICT (id) DO NOTHING;

INSERT INTO chatter_messages (id, tenant_id, record_type, record_id, author_id, author_name, message_type, content, activity_type, due_date, completed)
VALUES
('cht_01', 'sachhi-saheli-delhi', 'candidate', 'cand_01', 'usr_hr_head', 'Pooja Sharma', 'NOTE', 'Completed 2 reference checks with Pratham and Care India directors. Candidate recommended for offer.', NULL, NULL, false),
('cht_02', 'sachhi-saheli-delhi', 'candidate', 'cand_01', 'usr_hr_head', 'Pooja Sharma', 'ACTIVITY', 'Follow up on signed appointment letter return and joining date confirmation.', 'CALL', CURRENT_DATE + INTERVAL '3 days', false),
('cht_03', 'sachhi-saheli-delhi', 'workflow', 'wf_leave_001', 'usr_manager', 'Anjali Verma', 'NOTE', 'Verified hospital medical fitness report. Approved manager stage.', NULL, NULL, true)
ON CONFLICT (id) DO NOTHING;
