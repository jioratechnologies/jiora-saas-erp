import http from 'http';
import { createApp } from './app.js';
import { initDb } from './core/database/db.js';
import { initSocketServer } from './core/realtime/socketServer.js';
import { logger } from './core/logging/logger.js';

const PORT = process.env.PORT || 4000;
const app = createApp();
const httpServer = http.createServer(app);

async function startServer() {
  await initDb();
  initSocketServer(httpServer);

  httpServer.listen(PORT, () => {
    logger.info(`Sachhi Saheli ERP API & Real-Time Engine running on port ${PORT}`, {
      port: PORT,
      healthEndpoint: `/health`,
      websocketEndpoint: `/socket.io/`,
      architecture: 'Modular Monolith (Kong Gateway & WebSockets Ready)',
    });
    console.log(`========================================================`);
    console.log(`🚀 Sachhi Saheli ERP - Modular Monolith API Started`);
    console.log(`📡 HTTP & WebSockets Port: ${PORT}`);
    console.log(`⚡ Real-Time Engine: Socket.IO with Redis Cluster Pub/Sub`);
    console.log(`🔗 Health Check: http://localhost:${PORT}/health`);
    console.log(`🏛️ Architecture: Modular Monolith with Multi-Tenancy & Kong`);
    console.log(`========================================================`);
  });
}

startServer();
