import express from 'express';
import cors from 'cors';
import { requestLogger } from './core/middleware/loggingMiddleware.js';
import { errorHandler } from './core/middleware/errorMiddleware.js';
import { authRouter } from './modules/auth/authRouter.js';
import { tenantRouter } from './modules/tenant/tenantRouter.js';
import { workflowRouter } from './modules/workflow/workflowRouter.js';
import { employeesRouter } from './modules/hris/employeesRouter.js';
import { attendanceRouter } from './modules/hris/attendanceRouter.js';
import { leaveRouter } from './modules/hris/leaveRouter.js';
import { payrollRouter } from './modules/hris/payrollRouter.js';
import { exitRouter } from './modules/hris/exitRouter.js';
import { recruitmentRouter } from './modules/hris/recruitmentRouter.js';
import { onboardingRouter } from './modules/hris/onboardingRouter.js';
import { performanceRouter } from './modules/hris/performanceRouter.js';
import { travelRouter } from './modules/hris/travelRouter.js';
import { documentsRouter } from './modules/documents/documentsRouter.js';
import { chatterRouter } from './modules/chatter/chatterRouter.js';
import { financeRouter } from './modules/finance/financeRouter.js';
import { crmRouter } from './modules/crm/crmRouter.js';
import { ppmRouter } from './modules/ppm/ppmRouter.js';
import { complianceRouter } from './modules/compliance/complianceRouter.js';

export const createApp = () => {
  const app = express();

  // 1. Cross-Origin Resource Sharing & Body parsing
  app.use(cors({ origin: true, credentials: true }));
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true }));

  // 2. Structured Request & Correlation Logging Middleware
  app.use(requestLogger);

  // 3. Health check endpoint (for Kong Gateway & orchestrator probes)
  const healthHandler = (_req: express.Request, res: express.Response) => {
    res.json({
      status: 'HEALTHY',
      service: 'Sachhi Saheli Modular Monolith API',
      gateway: 'Kong API Gateway Compatible',
      timestamp: new Date().toISOString(),
      version: '2.0.0',
    });
  };
  app.get('/health', healthHandler);
  app.get('/api/health', healthHandler);

  // 4. Wire decoupled domain modules
  app.use('/api/auth', authRouter);
  app.use('/api/tenant', tenantRouter);
  app.use('/api/workflows', workflowRouter);
  app.use('/api/hris/employees', employeesRouter);
  app.use('/api/hris/attendance', attendanceRouter);
  app.use('/api/hris/leave', leaveRouter);
  app.use('/api/hris/payroll', payrollRouter);
  app.use('/api/hris/exit', exitRouter);
  app.use('/api/hris/recruitment', recruitmentRouter);
  app.use('/api/hris/onboarding', onboardingRouter);
  app.use('/api/hris/performance', performanceRouter);
  app.use('/api/hris/travel', travelRouter);
  app.use('/api/documents', documentsRouter);
  app.use('/api/chatter', chatterRouter);
  app.use('/api/finance', financeRouter);
  app.use('/api/crm', crmRouter);
  app.use('/api/ppm', ppmRouter);
  app.use('/api/compliance', complianceRouter);

  // 5. Global Standardized Error Handling Middleware (RFC 7807)
  app.use(errorHandler);

  return app;
};
