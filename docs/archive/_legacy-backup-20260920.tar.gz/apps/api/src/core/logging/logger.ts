export type LogLevel = 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';

export interface LogContext {
  requestId?: string;
  tenantId?: string;
  userId?: string;
  userRole?: string;
  module?: string;
  action?: string;
  durationMs?: number;
  [key: string]: any;
}

class StructuredLogger {
  private formatLog(level: LogLevel, message: string, context?: LogContext, error?: Error): string {
    const entry = {
      timestamp: new Date().toISOString(),
      level,
      message,
      ...(context || {}),
      ...(error
        ? {
            errorName: error.name,
            errorMessage: error.message,
            stack: error.stack,
          }
        : {}),
    };
    return JSON.stringify(entry);
  }

  debug(message: string, context?: LogContext) {
    if (process.env.NODE_ENV !== 'production') {
      console.debug(this.formatLog('DEBUG', message, context));
    }
  }

  info(message: string, context?: LogContext) {
    console.info(this.formatLog('INFO', message, context));
  }

  warn(message: string, context?: LogContext, error?: Error) {
    console.warn(this.formatLog('WARN', message, context, error));
  }

  error(message: string, context?: LogContext, error?: Error) {
    console.error(this.formatLog('ERROR', message, context, error));
  }
}

export const logger = new StructuredLogger();
