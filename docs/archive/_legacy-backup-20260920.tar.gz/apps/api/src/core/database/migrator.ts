import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import pg from 'pg';
import { logger } from '../logging/logger.js';

const { Pool } = pg;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const connectionString = process.env.DATABASE_URL || 'postgresql://erp_user:erp_password@localhost:5432/sachhi_saheli_erp?schema=public';

export const migrationPool = new Pool({
  connectionString,
  connectionTimeoutMillis: 5000,
});

const MIGRATIONS_DIR = path.resolve(__dirname, '../../../migrations');

/**
 * Ensures schema_migrations tracking table exists
 */
async function ensureMigrationTable(client: pg.PoolClient) {
  await client.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version VARCHAR(255) PRIMARY KEY,
      applied_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );
  `);
}

/**
 * Returns list of applied migration versions
 */
async function getAppliedMigrations(client: pg.PoolClient): Promise<string[]> {
  await ensureMigrationTable(client);
  const res = await client.query('SELECT version FROM schema_migrations ORDER BY version ASC');
  return res.rows.map((r) => r.version);
}

/**
 * Gets all migration files from the migrations folder
 */
function getMigrationFiles(): string[] {
  if (!fs.existsSync(MIGRATIONS_DIR)) {
    return [];
  }
  return fs
    .readdirSync(MIGRATIONS_DIR)
    .filter((f) => f.endsWith('.sql'))
    .sort();
}

/**
 * Shows migration status
 */
export async function migrationStatus() {
  const client = await migrationPool.connect();
  try {
    const applied = await getAppliedMigrations(client);
    const files = getMigrationFiles();

    console.log('\n=== Database Migration Status ===');
    console.log('Migration Directory:', MIGRATIONS_DIR);
    console.log('---------------------------------------------------------');
    console.log('Migration File                         | Status');
    console.log('---------------------------------------------------------');

    for (const file of files) {
      const isApplied = applied.includes(file);
      const statusText = isApplied ? '\x1b[32mAPPLIED\x1b[0m' : '\x1b[33mPENDING\x1b[0m';
      console.log(`${file.padEnd(38)} | ${statusText}`);
    }
    console.log('---------------------------------------------------------\n');
  } finally {
    client.release();
  }
}

/**
 * Applies all pending migrations
 */
export async function migrateUp(): Promise<number> {
  const client = await migrationPool.connect();
  let appliedCount = 0;
  try {
    await ensureMigrationTable(client);
    const applied = await getAppliedMigrations(client);
    const files = getMigrationFiles();

    const pending = files.filter((f) => !applied.includes(f));

    if (pending.length === 0) {
      logger.info('Database is up to date. No pending migrations.');
      return 0;
    }

    for (const file of pending) {
      const filePath = path.join(MIGRATIONS_DIR, file);
      const sql = fs.readFileSync(filePath, 'utf8');

      logger.info(`Applying migration: ${file}...`);
      await client.query('BEGIN');
      try {
        await client.query(sql);
        await client.query('INSERT INTO schema_migrations (version) VALUES ($1)', [file]);
        await client.query('COMMIT');
        logger.info(`Successfully applied migration: ${file}`);
        appliedCount++;
      } catch (err: any) {
        await client.query('ROLLBACK');
        logger.error(`Failed to apply migration ${file}:`, { error: err.message });
        throw err;
      }
    }

    return appliedCount;
  } finally {
    client.release();
  }
}

/**
 * Seeds the database with dedicated Sachhi Saheli seed data
 */
export async function seedDatabase(): Promise<boolean> {
  const client = await migrationPool.connect();
  try {
    const seedFile = path.join(MIGRATIONS_DIR, '002_sachhi_saheli_seed.sql');
    if (!fs.existsSync(seedFile)) {
      throw new Error(`Seed file not found at ${seedFile}`);
    }

    const sql = fs.readFileSync(seedFile, 'utf8');
    logger.info('Seeding database with dedicated Sachhi Saheli enterprise dataset...');
    await client.query('BEGIN');
    await client.query(sql);
    await client.query('COMMIT');
    logger.info('Database seeded successfully.');
    return true;
  } catch (err: any) {
    await client.query('ROLLBACK');
    logger.error('Failed to seed database:', { error: err.message });
    throw err;
  } finally {
    client.release();
  }
}

/**
 * Resets the database schema and reapplies all migrations and seed
 */
export async function resetDatabase(): Promise<void> {
  const client = await migrationPool.connect();
  try {
    logger.warn('Resetting database schema (DROP public CASCADE)...');
    await client.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
    logger.info('Public schema reset.');
  } finally {
    client.release();
  }

  await migrateUp();
  await seedDatabase();
}

// CLI Execution Handler
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const command = process.argv[2] || 'status';

  (async () => {
    try {
      if (command === 'up') {
        await migrateUp();
      } else if (command === 'status') {
        await migrationStatus();
      } else if (command === 'seed') {
        await seedDatabase();
      } else if (command === 'reset') {
        await resetDatabase();
      } else {
        console.log(`Unknown command: ${command}`);
        console.log('Usage: npm run migrate:up | migrate:status | db:seed | db:reset');
      }
      process.exit(0);
    } catch (err: any) {
      if (err.code === 'ECONNREFUSED') {
        console.error(`\n[Database Migration Error]: Could not connect to PostgreSQL at ${err.address}:${err.port}.`);
        console.error('Please make sure PostgreSQL is running (e.g. run "docker compose up -d postgres") and retry.\n');
      } else {
        console.error('Migration command failed:', err.message || err);
      }
      process.exit(1);
    }
  })();
}
