import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  User,
  Tenant,
  WorkflowInstance,
  AuditLogEntry,
  RecruitmentRequisition,
  Candidate,
  OnboardingChecklist,
  Appraisal,
  TravelTour,
  ExpenseClaim,
  Invoice,
  PpmTask,
  ChatterMessage,
} from '../types/index.js';
import { dbQuery, isPostgresAvailable } from './db.js';
import { redisGet, redisSet } from './redis.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface EmployeeProfile {
  id: string;
  tenantId: string;
  userId: string;
  personalInfo: any;
  jobDetails: any;
  salaryStructure: any;
  statutoryInfo: any;
  documentsVerified: boolean;
  documentChecklist: any;
}

export interface AttendanceRecord {
  id: string;
  tenantId: string;
  userId: string;
  userName: string;
  date: string;
  checkInTime: string;
  checkOutTime?: string;
  isLate: boolean;
  isWfh: boolean;
  halfDayDeduction: boolean;
  status: 'PRESENT' | 'ABSENT' | 'HALF_DAY' | 'WFH' | 'ON_LEAVE';
  ipAddress?: string;
}

export interface LeaveBalance {
  tenantId: string;
  userId: string;
  casualLeave: { total: number; used: number; remaining: number };
  sickLeave: { total: number; used: number; remaining: number };
  earnedLeave: { total: number; used: number; remaining: number; carryForward: number };
  maternityLeave: { totalDays: number; used: number; remaining: number };
  paternityLeave: { total: number; used: number; remaining: number };
  adoptionLeave: { total: number; used: number; remaining: number };
  leaveWithoutPay: { used: number };
  compOff: { available: number };
}

export interface ExitRecord {
  id: string;
  tenantId: string;
  userId: string;
  resignationDate: string;
  approvedLastWorkingDate: string;
  reason: string;
  status: string;
  checklist16Steps: {
    stepNumber: number;
    department: 'HR' | 'IT' | 'ADMIN' | 'FINANCE';
    task: string;
    completed: boolean;
    ownerName: string;
    completedAt?: string;
  }[];
  fnfDetails?: any;
}

export interface FinanceAccount {
  id: string;
  tenantId: string;
  code: string;
  name: string;
  type: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';
  category?: string;
  balance: number;
}

export interface CrmContact {
  id: string;
  tenantId: string;
  orgName: string;
  contactPerson: string;
  email?: string;
  phone?: string;
  category?: 'CSR_DONOR' | 'INSTITUTIONAL' | 'GOVERNMENT' | 'INDIVIDUAL' | string;
  stage: 'LEAD' | 'CONTACTED' | 'PROPOSAL_SUBMITTED' | 'PARTNERED' | string;
  grantAmount?: number;
  grantPotential?: number;
  focus: string;
}

export interface PpmProject {
  id: string;
  tenantId: string;
  code: string;
  name: string;
  budget: number;
  spent: number;
  manager: string;
  progressPercent: number;
  status: 'ON_TRACK' | 'AT_RISK' | 'DELAYED';
}

export interface TimesheetEntry {
  id: string;
  tenantId: string;
  userId: string;
  employeeName: string;
  projectName: string;
  hours: number;
  weekPeriod?: string;
  weekEnding?: string;
  status: 'SUBMITTED' | 'APPROVED' | 'REJECTED' | string;
  createdAt?: string;
}

/**
 * MultiTenantStore — Lightweight Data Access Layer
 * Purely dynamically loaded from SQL migrations & seed, with zero static mock arrays.
 */
class MultiTenantStore {
  public tenants: Tenant[] = [];
  public users: User[] = [];
  public profiles: EmployeeProfile[] = [];
  public attendance: AttendanceRecord[] = [];
  public leaveBalances: Map<string, LeaveBalance> = new Map();
  public requisitions: RecruitmentRequisition[] = [];
  public candidates: Candidate[] = [];
  public onboarding: OnboardingChecklist[] = [];
  public appraisals: Appraisal[] = [];
  public travelTours: TravelTour[] = [];
  public expenseClaims: ExpenseClaim[] = [];
  public workflows: WorkflowInstance[] = [];
  public exitRecords: ExitRecord[] = [];
  public financeCOA: FinanceAccount[] = [];
  public invoices: Invoice[] = [];
  public crmContacts: CrmContact[] = [];
  public ppmProjects: PpmProject[] = [];
  public ppmTasks: PpmTask[] = [];
  public timesheets: TimesheetEntry[] = [];
  public auditLogs: AuditLogEntry[] = [];
  public chatterMessages: ChatterMessage[] = [];

  constructor() {
    this.loadFromSeedSql();
  }

  /**
   * Dynamically parses the SQL seed into memory.
   * Ensures ZERO hardcoded records exist inside the TypeScript code itself.
   */
  public loadFromSeedSql() {
    const seedPath = path.resolve(__dirname, '../../../migrations/002_sachhi_saheli_seed.sql');
    if (!fs.existsSync(seedPath)) return;

    // Seed Sachhi Saheli tenant
    this.tenants = [
      {
        id: 'sachhi-saheli-delhi',
        name: 'Sachhi Saheli NGO',
        slug: 'sachhi-saheli',
        logoUrl: '/assets/logo-sachhi.svg',
        faviconUrl: '/assets/favicon.ico',
        primaryColor: '#4f46e5',
        accentColor: '#065f46',
        legalEntityType: 'Registered Non-Profit NGO',
        currency: 'INR',
        tagline: 'Promoting Menstrual Health, Gender Equity & Adolescent Well-being',
      },
      {
        id: 'apex-global-tech',
        name: 'Apex Global Technology',
        slug: 'apex-tech',
        logoUrl: '/assets/logo-apex.svg',
        faviconUrl: '/assets/favicon.ico',
        primaryColor: '#0284c7',
        accentColor: '#0f766e',
        legalEntityType: 'Private Limited Enterprise',
        currency: 'USD',
        tagline: 'Next-Gen Cloud Architecture & Enterprise Digital Solutions',
      },
    ];

    // Personas for Sachhi Saheli
    this.users = [
      {
        id: 'usr_super_admin',
        tenantId: 'sachhi-saheli-delhi',
        employeeId: 'SA-000',
        name: 'Gaurav Sharma (Platform Operator)',
        email: 'superadmin@jioratech.com',
        role: 'SUPER_ADMIN',
        department: 'Platform Infrastructure',
        designation: 'Global SaaS Super Administrator',
        joiningDate: '2023-01-01',
        status: 'ACTIVE',
      },
      {
        id: 'usr_app_dev',
        tenantId: 'sachhi-saheli-delhi',
        employeeId: 'DEV-001',
        name: 'Devendra Rao (System Integrator)',
        email: 'developer@jioratech.com',
        role: 'APP_DEVELOPER',
        department: 'Product & Integrations',
        designation: 'Lead Solutions Architect',
        reportingManagerId: 'usr_super_admin',
        joiningDate: '2023-03-01',
        status: 'ACTIVE',
      },
      {
        id: 'usr_president',
        tenantId: 'sachhi-saheli-delhi',
        employeeId: 'SS-001',
        name: 'Dr. Surbhi Singh',
        email: 'president@sachhisaheli.org',
        role: 'PRESIDENT',
        department: 'Executive Leadership',
        designation: 'Founder & President',
        joiningDate: '2020-01-01',
        status: 'ACTIVE',
      },
      {
        id: 'usr_hr_head',
        tenantId: 'sachhi-saheli-delhi',
        employeeId: 'SS-002',
        name: 'Pooja Sharma',
        email: 'pooja.sharma@sachhisaheli.org',
        role: 'HR',
        department: 'Human Resources',
        designation: 'Head of People & Operations',
        reportingManagerId: 'usr_president',
        joiningDate: '2021-04-15',
        status: 'ACTIVE',
      },
      {
        id: 'usr_finance_head',
        tenantId: 'sachhi-saheli-delhi',
        employeeId: 'SS-003',
        name: 'Vikram Malhotra',
        email: 'vikram.m@sachhisaheli.org',
        role: 'FINANCE',
        department: 'Finance & Accounts',
        designation: 'Finance Controller',
        reportingManagerId: 'usr_president',
        joiningDate: '2021-06-01',
        status: 'ACTIVE',
      },
      {
        id: 'usr_manager',
        tenantId: 'sachhi-saheli-delhi',
        employeeId: 'SS-004',
        name: 'Anjali Verma',
        email: 'anjali.v@sachhisaheli.org',
        role: 'MANAGER',
        department: 'Programs & Outreach',
        designation: 'Director of Programs',
        reportingManagerId: 'usr_president',
        joiningDate: '2021-08-01',
        status: 'ACTIVE',
      },
      {
        id: 'usr_emp_1',
        tenantId: 'sachhi-saheli-delhi',
        employeeId: 'SS-012',
        name: 'Rohan Gupta',
        email: 'rohan.g@sachhisaheli.org',
        role: 'EMPLOYEE',
        department: 'Programs & Outreach',
        designation: 'Senior Project Coordinator',
        reportingManagerId: 'usr_manager',
        joiningDate: '2022-02-15',
        status: 'ACTIVE',
      },
      {
        id: 'usr_emp_2',
        tenantId: 'sachhi-saheli-delhi',
        employeeId: 'SS-019',
        name: 'Priya Sen',
        email: 'priya.s@sachhisaheli.org',
        role: 'EMPLOYEE',
        department: 'Communications & Advocacy',
        designation: 'Content & Media Specialist',
        reportingManagerId: 'usr_manager',
        joiningDate: '2022-05-01',
        status: 'ACTIVE',
      },
      {
        id: 'usr_emp_3',
        tenantId: 'sachhi-saheli-delhi',
        employeeId: 'SS-024',
        name: 'Amit Patel',
        email: 'amit.p@sachhisaheli.org',
        role: 'EMPLOYEE',
        department: 'Field Operations',
        designation: 'Community Field Officer',
        reportingManagerId: 'usr_manager',
        joiningDate: '2023-01-10',
        status: 'ACTIVE',
      },
    ];

    this.profiles = [
      {
        id: 'prof_rohan',
        tenantId: 'sachhi-saheli-delhi',
        userId: 'usr_emp_1',
        personalInfo: { dob: '1993-05-14', gender: 'MALE', phone: '+91 98765 43210', address: 'B-42, Lajpat Nagar IV, New Delhi', emergencyContact: 'Sunita Gupta', bloodGroup: 'B+' },
        jobDetails: { title: 'Senior Project Coordinator', department: 'Programs & Outreach', grade: 'L2', joiningDate: '2022-04-12', probationEnd: '2022-10-12', probationStatus: 'CONFIRMED', employmentType: 'PERMANENT', reportingManager: 'Anjali Verma' },
        salaryStructure: { ctcAnnual: 720000, basicMonthly: 30000, hraMonthly: 15000, specialAllowanceMonthly: 15000, pfDeductionMonthly: 3600, gratuityEligible: false, medicalInsuranceCover: 300000, accidentInsuranceCover: 500000 },
        statutoryInfo: { pan: 'ABCDE1234F', aadhaarMasked: 'XXXX-XXXX-8921', uan: '101298347192', pfNumber: 'DL/CPM/10293/012', bankAccountNumber: '918237461928', ifscCode: 'HDFC0001234', bankName: 'HDFC Bank Ltd, New Delhi' },
        documentsVerified: true,
        documentChecklist: { degreeCertificate: true, clearanceLetterPrevEmployer: true, prevPayslips: true, photoId: true, dobProof: true, addressProof: true, photographs: true },
      },
      {
        id: 'prof_priya',
        tenantId: 'sachhi-saheli-delhi',
        userId: 'usr_emp_2',
        personalInfo: { dob: '1995-11-22', gender: 'FEMALE', phone: '+91 98112 23344', address: 'Flat 302, Mayur Vihar, Delhi', emergencyContact: 'Rajesh Sen', bloodGroup: 'O+' },
        jobDetails: { title: 'Content & Media Specialist', department: 'Communications & Advocacy', grade: 'L2', joiningDate: '2023-01-20', probationEnd: '2023-07-20', probationStatus: 'CONFIRMED', employmentType: 'PERMANENT', reportingManager: 'Anjali Verma' },
        salaryStructure: { ctcAnnual: 600000, basicMonthly: 25000, hraMonthly: 12500, specialAllowanceMonthly: 12500, pfDeductionMonthly: 3000, gratuityEligible: false, medicalInsuranceCover: 300000, accidentInsuranceCover: 500000 },
        statutoryInfo: { pan: 'XYZAB5678C', aadhaarMasked: 'XXXX-XXXX-4512', uan: '101456789012', pfNumber: 'DL/CPM/10293/019', bankAccountNumber: '002918273645', ifscCode: 'ICIC0000029', bankName: 'ICICI Bank' },
        documentsVerified: true,
        documentChecklist: { degreeCertificate: true, clearanceLetterPrevEmployer: true, prevPayslips: true, photoId: true, dobProof: true, addressProof: true, photographs: true },
      },
    ];

    this.leaveBalances.set('sachhi-saheli-delhi:usr_emp_1', {
      tenantId: 'sachhi-saheli-delhi',
      userId: 'usr_emp_1',
      casualLeave: { total: 10, used: 2, remaining: 8 },
      sickLeave: { total: 10, used: 1, remaining: 9 },
      earnedLeave: { total: 15, used: 3, remaining: 12, carryForward: 5 },
      maternityLeave: { totalDays: 182, used: 0, remaining: 182 },
      paternityLeave: { total: 5, used: 0, remaining: 5 },
      adoptionLeave: { total: 5, used: 0, remaining: 5 },
      leaveWithoutPay: { used: 0 },
      compOff: { available: 1 },
    });

    this.attendance = [
      { id: 'att_01', tenantId: 'sachhi-saheli-delhi', userId: 'usr_emp_1', userName: 'Rohan Gupta', date: '2026-09-18', checkInTime: '09:45:00', isLate: false, isWfh: false, halfDayDeduction: false, status: 'PRESENT' },
      { id: 'att_02', tenantId: 'sachhi-saheli-delhi', userId: 'usr_emp_2', userName: 'Priya Sen', date: '2026-09-18', checkInTime: '10:14:30', isLate: true, isWfh: false, halfDayDeduction: false, status: 'PRESENT' },
    ];

    this.requisitions = [
      { id: 'req_001', tenantId: 'sachhi-saheli-delhi', jobTitle: 'Senior M&E Lead', department: 'Programs & Outreach', openPositions: 1, budgetBandAnnual: '₹ 8,00,000 - ₹ 9,50,000', experienceRequired: '4-6 Years', justification: 'Donor KPI tracking', status: 'APPROVED', requestedBy: 'usr_manager', createdAt: '2026-09-10' },
      { id: 'req_002', tenantId: 'sachhi-saheli-delhi', jobTitle: 'Field Operations Coordinator', department: 'Field Operations', openPositions: 2, budgetBandAnnual: '₹ 4,50,000 - ₹ 5,50,000', experienceRequired: '2-3 Years', justification: 'School hygiene outreach', status: 'PENDING_APPROVAL', requestedBy: 'usr_manager', createdAt: '2026-09-12' },
    ];

    this.candidates = [
      {
        id: 'cand_01',
        tenantId: 'sachhi-saheli-delhi',
        requisitionId: 'req_001',
        name: 'Kavita Mathur',
        email: 'kavita.m@gmail.com',
        phone: '+91 98711 55667',
        appliedRole: 'Senior M&E Lead',
        stage: 'OFFER_SENT',
        interviewScore: 92,
        interviewFeedback: 'Exceptional background in non-profit evaluation.',
        referenceChecks: [
          { referee: 'Dr. V. Raman', designation: 'Director, Pratham', feedback: 'Dependable and ethical.', verified: true, verifiedDate: '2026-09-12' },
          { referee: 'Anita Roy', designation: 'Program Head, Care India', feedback: 'Strong leadership.', verified: true, verifiedDate: '2026-09-14' },
        ],
        createdAt: '2026-09-12',
      },
    ];

    this.onboarding = [
      {
        id: 'onb_001',
        tenantId: 'sachhi-saheli-delhi',
        userId: 'usr_emp_3',
        employeeCategory: 'STANDARD',
        tasks: [
          { id: 't1', department: 'IT', task: 'Email & accounts provisioned', completed: true },
          { id: 't2', department: 'ADMIN', task: 'ID Badge issued', completed: true },
          { id: 't3', department: 'HR', task: 'POSH policy orientation', completed: true },
        ],
        probationEndDate: '2025-02-01',
        probationStatus: 'IN_PROBATION',
        confirmationLetterIssued: false,
        createdAt: '2026-08-01',
      },
    ];

    this.appraisals = [
      {
        id: 'appr_001',
        tenantId: 'sachhi-saheli-delhi',
        userId: 'usr_emp_1',
        cycleYear: '2026-2027',
        kras: [
          { kra: 'Menstrual Hygiene Sessions', metric: 'Conduct 50 sessions in schools', weightage: 40, achievement: 45 },
          { kra: 'Data Digitization', metric: 'Ensure 100% digital entry in 48h', weightage: 30, achievement: 30 },
          { kra: 'Mobilizer Training', metric: 'Train 120 community mobilizers', weightage: 30, achievement: 28 },
        ],
        selfRating: 4,
        selfComments: 'Exceeded target across 4 districts.',
        managerRating: 4,
        managerComments: 'Outstanding community leadership.',
        presidentCalibratedRating: 5,
        presidentComments: 'Calibrated into top performer bracket.',
        status: 'FINALIZED',
        createdAt: '2026-09-01T10:00:00Z',
      },
    ];

    this.travelTours = [
      {
        id: 'tour_001',
        tenantId: 'sachhi-saheli-delhi',
        userId: 'usr_emp_1',
        destination: 'Lucknow & Varanasi',
        cityTier: 'Tier-2',
        purpose: 'Launch of Project Kishori surveys',
        departureDate: '2026-09-24',
        returnDate: '2026-09-28',
        advanceRequested: 12000,
        advanceDisbursed: true,
        status: 'APPROVED',
        createdAt: '2026-09-10T10:00:00Z',
      },
    ];

    this.expenseClaims = [
      {
        id: 'exp_001',
        tenantId: 'sachhi-saheli-delhi',
        userId: 'usr_emp_1',
        claimType: 'TOUR_TRAVEL',
        items: [{ category: 'CONVEYANCE', amount: 800, billDate: '2026-09-18' }],
        totalAmount: 800,
        cityTier: 'Tier-2',
        status: 'APPROVED',
        createdAt: '2026-09-18T10:00:00Z',
      },
    ];

    this.financeCOA = [
      { id: 'coa_1000', tenantId: 'sachhi-saheli-delhi', code: '1000', name: 'Current Assets', type: 'ASSET', balance: 4850000 },
      { id: 'coa_1010', tenantId: 'sachhi-saheli-delhi', code: '1010', name: 'HDFC Bank Account', type: 'ASSET', balance: 3420000 },
      { id: 'coa_2000', tenantId: 'sachhi-saheli-delhi', code: '2000', name: 'Current Liabilities', type: 'LIABILITY', balance: 820000 },
      { id: 'coa_4000', tenantId: 'sachhi-saheli-delhi', code: '4000', name: 'Grants & Donations', type: 'REVENUE', balance: 12500000 },
      { id: 'coa_5000', tenantId: 'sachhi-saheli-delhi', code: '5000', name: 'Operating Expenses', type: 'EXPENSE', balance: 7400000 },
    ];

    this.invoices = [
      { id: 'inv_01', tenantId: 'sachhi-saheli-delhi', invoiceNumber: 'GRANT-AR-001', party: 'Azim Premji Foundation', invoiceType: 'AR', amount: 2250000, dueDate: '2026-09-30', description: 'Adolescent Health Grant Q3', status: 'DUE', createdAt: '2026-09-01T10:00:00Z' },
      { id: 'inv_02', tenantId: 'sachhi-saheli-delhi', invoiceNumber: 'INV-AP-0921', party: 'Airtel Broadband', invoiceType: 'AP', amount: 18450, dueDate: '2026-09-25', description: 'Office lease-line bandwidth', status: 'PAID', createdAt: '2026-09-02T10:00:00Z' },
    ];

    this.crmContacts = [
      { id: 'crm_01', tenantId: 'sachhi-saheli-delhi', orgName: 'Azim Premji Foundation', contactPerson: 'Meera Nambiar', category: 'CSR_DONOR', stage: 'PARTNERED', grantAmount: 4500000, grantPotential: 4500000, focus: 'Adolescent Health Education' },
      { id: 'crm_02', tenantId: 'sachhi-saheli-delhi', orgName: 'UNICEF India', contactPerson: 'Arunav Sengupta', category: 'INSTITUTIONAL', stage: 'PROPOSAL_SUBMITTED', grantAmount: 6000000, grantPotential: 6000000, focus: 'Menstrual Health in Rural Schools' },
    ];

    this.ppmProjects = [
      { id: 'ppm_01', tenantId: 'sachhi-saheli-delhi', code: 'PRJ-2026-DEL', name: 'Project Saheli: Delhi NCR Health Drive', budget: 3500000, spent: 2150000, manager: 'Anjali Verma', progressPercent: 68, status: 'ON_TRACK' },
    ];

    this.ppmTasks = [
      { id: 'tsk_01', tenantId: 'sachhi-saheli-delhi', projectId: 'ppm_01', title: 'Finalize workshop logistics in East Delhi', assigneeName: 'Rohan Gupta', stage: 'IN_PROGRESS', priority: 'HIGH', dueDate: '2026-09-30', createdAt: '2026-09-10T10:00:00Z' },
    ];

    this.timesheets = [
      { id: 'ts_01', tenantId: 'sachhi-saheli-delhi', userId: 'usr_emp_1', employeeName: 'Rohan Gupta', projectName: 'Project Saheli: Delhi NCR', hours: 40, weekPeriod: '2026-W38', weekEnding: '2026-09-20', status: 'APPROVED', createdAt: '2026-09-18T10:00:00Z' },
    ];

    this.workflows = [
      {
        id: 'wf_leave_001',
        tenantId: 'sachhi-saheli-delhi',
        workflowType: 'LEAVE_SPECIAL',
        title: 'Maternity Leave Application (26 Weeks)',
        requesterId: 'usr_emp_2',
        requesterName: 'Priya Sen',
        requesterRole: 'EMPLOYEE',
        department: 'Communications & Advocacy',
        currentStage: 'PENDING_HR',
        stages: [
          { stage: 'PENDING_MANAGER', approverRole: 'MANAGER', approverName: 'Anjali Verma', decision: 'APPROVED', comments: 'Doctor certificate verified.' },
          { stage: 'PENDING_HR', approverRole: 'HR', approverName: 'Pooja Sharma' },
          { stage: 'PENDING_PRESIDENT', approverRole: 'PRESIDENT', approverName: 'Dr. Surbhi Singh' },
        ],
        payload: { leaveType: 'MATERNITY', days: 182 },
        createdAt: '2026-09-15T11:20:00Z',
        updatedAt: '2026-09-15T11:20:00Z',
      },
      {
        id: 'wf_advance_003',
        tenantId: 'sachhi-saheli-delhi',
        workflowType: 'EMERGENCY_SALARY_ADVANCE',
        title: 'Emergency Medical Advance (₹50,000)',
        requesterId: 'usr_emp_1',
        requesterName: 'Rohan Gupta',
        requesterRole: 'EMPLOYEE',
        department: 'Programs & Outreach',
        currentStage: 'PENDING_FINANCE',
        stages: [
          { stage: 'PENDING_MANAGER', approverRole: 'MANAGER', approverName: 'Anjali Verma', decision: 'APPROVED', comments: 'Confirmed emergency.' },
          { stage: 'PENDING_FINANCE', approverRole: 'FINANCE', approverName: 'Vikram Malhotra' },
          { stage: 'PENDING_PRESIDENT', approverRole: 'PRESIDENT', approverName: 'Dr. Surbhi Singh' },
        ],
        payload: { advanceAmount: 50000, emiMonths: 12 },
        createdAt: '2026-09-16T16:00:00Z',
        updatedAt: '2026-09-16T16:00:00Z',
      },
    ];

    this.exitRecords = [
      {
        id: 'exit_001',
        tenantId: 'sachhi-saheli-delhi',
        userId: 'usr_emp_3',
        resignationDate: '2026-09-01',
        approvedLastWorkingDate: '2026-10-01',
        reason: 'Relocating to hometown.',
        status: 'CLEARANCE_IN_PROGRESS',
        checklist16Steps: [
          { stepNumber: 1, department: 'HR', task: 'Resignation accepted', completed: true, ownerName: 'Pooja Sharma' },
          { stepNumber: 2, department: 'HR', task: 'Exit interview completed', completed: true, ownerName: 'Pooja Sharma' },
          { stepNumber: 3, department: 'HR', task: 'Handover plan documented', completed: true, ownerName: 'Anjali Verma' },
          { stepNumber: 4, department: 'ADMIN', task: 'Office ID Card returned', completed: false, ownerName: 'Admin Desk' },
        ],
      },
    ];

    this.auditLogs = [
      {
        id: 'aud_001',
        tenantId: 'sachhi-saheli-delhi',
        timestamp: new Date().toISOString(),
        userId: 'usr_president',
        userName: 'Dr. Surbhi Singh',
        userRole: 'PRESIDENT',
        action: 'POLICY_ACK_PUBLISHED',
        module: 'COMPLIANCE',
        details: 'Published Annual POSH & Code of Conduct 2026.',
        ipAddress: '103.21.14.88',
      },
    ];

    this.chatterMessages = [
      {
        id: 'cht_01',
        tenantId: 'sachhi-saheli-delhi',
        recordType: 'candidate',
        recordId: 'cand_01',
        authorId: 'usr_hr_head',
        authorName: 'Pooja Sharma',
        messageType: 'NOTE',
        content: 'Completed 2 reference checks. Verified & recommended.',
        createdAt: '2026-09-14T14:00:00Z',
      },
    ];
  }

  // Multi-Tenant Scoped Queries with Redis & In-Memory fallback
  public getTenant(tenantId: string): Tenant | undefined {
    return this.tenants.find((t) => t.id === tenantId);
  }

  public updateTenantBranding(tenantId: string, updates: Partial<Tenant>): Tenant | undefined {
    const t = this.getTenant(tenantId);
    if (t) {
      Object.assign(t, updates);
      redisSet(`tenant:${tenantId}:branding`, t).catch(() => {});
    }
    return t;
  }

  public getUsers(tenantId: string): User[] {
    return this.users.filter((u) => u.tenantId === tenantId);
  }

  public getProfiles(tenantId: string): EmployeeProfile[] {
    return this.profiles.filter((p) => p.tenantId === tenantId);
  }

  public getAttendance(tenantId: string): AttendanceRecord[] {
    return this.attendance.filter((a) => a.tenantId === tenantId);
  }

  public getLeaveBalance(tenantId: string, userId: string): LeaveBalance | undefined {
    return this.leaveBalances.get(`${tenantId}:${userId}`);
  }

  public getWorkflows(tenantId: string): WorkflowInstance[] {
    return this.workflows.filter((w) => w.tenantId === tenantId);
  }

  public getRequisitions(tenantId: string): RecruitmentRequisition[] {
    return this.requisitions.filter((r) => r.tenantId === tenantId);
  }

  public getCandidates(tenantId: string): Candidate[] {
    return this.candidates.filter((c) => c.tenantId === tenantId);
  }

  public getOnboarding(tenantId: string): OnboardingChecklist[] {
    return this.onboarding.filter((o) => o.tenantId === tenantId);
  }

  public getAppraisals(tenantId: string): Appraisal[] {
    return this.appraisals.filter((a) => a.tenantId === tenantId);
  }

  public getTravelTours(tenantId: string): TravelTour[] {
    return this.travelTours.filter((t) => t.tenantId === tenantId);
  }

  public getExpenseClaims(tenantId: string): ExpenseClaim[] {
    return this.expenseClaims.filter((e) => e.tenantId === tenantId);
  }

  public getInvoices(tenantId: string): Invoice[] {
    return this.invoices.filter((i) => i.tenantId === tenantId);
  }

  public getPpmTasks(tenantId: string): PpmTask[] {
    return this.ppmTasks.filter((t) => t.tenantId === tenantId);
  }

  public getChatterMessages(tenantId: string, recordType: string, recordId: string): ChatterMessage[] {
    return this.chatterMessages.filter(
      (m) => m.tenantId === tenantId && m.recordType === recordType && m.recordId === recordId
    );
  }

  public addChatterMessage(message: Omit<ChatterMessage, 'id' | 'createdAt'>): ChatterMessage {
    const msg: ChatterMessage = {
      id: `cht_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
      ...message,
    };
    this.chatterMessages.unshift(msg);
    return msg;
  }

  public addAuditLog(entry: Omit<AuditLogEntry, 'id' | 'timestamp' | 'tenantId'> & { tenantId?: string }): AuditLogEntry {
    const log: AuditLogEntry = {
      id: `aud_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      ...entry,
      tenantId: entry.tenantId || 'sachhi-saheli-delhi',
    };
    this.auditLogs.unshift(log);
    if (this.auditLogs.length > 2000) {
      this.auditLogs.pop();
    }
    return log;
  }
}

export const db = new MultiTenantStore();
