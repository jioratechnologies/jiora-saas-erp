import { Redis } from 'ioredis';
import { logger } from '../logging/logger.js';

const redisUrl = process.env.REDIS_URL || 'redis://localhost:6379';

let redisClient: Redis | null = null;
let isRedisAvailable = false;

try {
  redisClient = new Redis(redisUrl, {
    maxRetriesPerRequest: 1,
    retryStrategy: (times) => {
      if (times > 3) return null; // stop retrying quickly if offline
      return Math.min(times * 200, 1000);
    },
    enableOfflineQueue: false,
    lazyConnect: true,
  });

  redisClient.on('connect', () => {
    isRedisAvailable = true;
    logger.info('Redis cache connection established successfully.');
  });

  redisClient.on('error', (err) => {
    isRedisAvailable = false;
    // Silent warn, do not throw
  });
} catch (e: any) {
  isRedisAvailable = false;
}

export async function redisGet<T = any>(key: string): Promise<T | null> {
  if (!isRedisAvailable || !redisClient) return null;
  try {
    const raw = await redisClient.get(key);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export async function redisSet(key: string, value: any, ttlSeconds: number = 300): Promise<void> {
  if (!isRedisAvailable || !redisClient) return;
  try {
    const serialized = JSON.stringify(value);
    if (ttlSeconds > 0) {
      await redisClient.set(key, serialized, 'EX', ttlSeconds);
    } else {
      await redisClient.set(key, serialized);
    }
  } catch {
    // Ignore cache write failure
  }
}

export async function redisDel(key: string): Promise<void> {
  if (!isRedisAvailable || !redisClient) return;
  try {
    await redisClient.del(key);
  } catch {
    // Ignore cache delete failure
  }
}

export { redisClient, isRedisAvailable };
