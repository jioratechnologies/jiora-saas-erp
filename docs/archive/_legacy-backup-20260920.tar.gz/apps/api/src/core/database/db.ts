import pg from 'pg';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { logger } from '../logging/logger.js';

const { Pool } = pg;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const connectionString = process.env.DATABASE_URL || 'postgresql://erp_user:erp_password@localhost:5432/sachhi_saheli_erp?schema=public';

export const pool = new Pool({
  connectionString,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

pool.on('error', (err) => {
  logger.warn('Unexpected error on idle PostgreSQL/PgBouncer pool client', { error: err.message });
});

let isPostgresAvailable = false;

// Fallback in-memory cache initialized directly from seed if PostgreSQL service is unavailable during standalone test runs
let inMemoryData: Record<string, any[]> = {};

export async function initDb() {
  logger.info('Initializing Database and multi-tenant schema...');
  try {
    const client = await pool.connect();
    isPostgresAvailable = true;

    // 1. Run DDL schema
    const schemaPath = path.join(__dirname, 'schema.sql');
    if (fs.existsSync(schemaPath)) {
      const schemaSql = fs.readFileSync(schemaPath, 'utf8');
      await client.query(schemaSql);
      logger.info('PostgreSQL schema DDL applied successfully.');
    }

    // 2. Check if tenants exist; if not, apply seed.sql
    const tenantCheck = await client.query('SELECT COUNT(*) FROM tenants');
    if (parseInt(tenantCheck.rows[0].count, 10) === 0) {
      const seedPath = path.join(__dirname, 'seed.sql');
      if (fs.existsSync(seedPath)) {
        const seedSql = fs.readFileSync(seedPath, 'utf8');
        await client.query(seedSql);
        logger.info('Database seeded successfully from seed.sql.');
      }
    } else {
      logger.info('Database already seeded. Preserving existing data.');
    }

    client.release();
    return true;
  } catch (err: any) {
    logger.warn('PostgreSQL connection not reachable on startup, operating in resilient memory-backed mode for tests/build.', {
      error: err.message,
    });
    isPostgresAvailable = false;
    loadFallbackData();
    return false;
  }
}

// Load seed data into memory if running without active docker container
function loadFallbackData() {
  // Pre-populate in-memory entities based on seed.sql definitions
  inMemoryData['tenants'] = [
    {
      id: 'sachhi-saheli-delhi',
      name: 'Sachhi Saheli NGO',
      slug: 'sachhi-saheli',
      logo_url: '/assets/logo-sachhi.svg',
      favicon_url: '/assets/favicon.ico',
      primary_color: '#4f46e5',
      accent_color: '#065f46',
      legal_entity_type: 'Registered Non-Profit NGO',
      currency: 'INR',
      tagline: 'Promoting Menstrual Health, Gender Equity & Adolescent Well-being',
    },
    {
      id: 'apex-global-tech',
      name: 'Apex Global Technology',
      slug: 'apex-tech',
      logo_url: '/assets/logo-apex.svg',
      favicon_url: '/assets/favicon.ico',
      primary_color: '#0284c7',
      accent_color: '#0f766e',
      legal_entity_type: 'Private Limited Enterprise',
      currency: 'USD',
      tagline: 'Next-Gen Cloud Architecture & Enterprise Digital Solutions',
    },
  ];
}

export async function dbQuery(text: string, params: any[] = []): Promise<pg.QueryResult<any>> {
  if (isPostgresAvailable) {
    return pool.query(text, params);
  }
  // Return mock result if offline
  return {
    rows: [],
    rowCount: 0,
    command: '',
    oid: 0,
    fields: [],
  };
}

export { isPostgresAvailable, inMemoryData };
