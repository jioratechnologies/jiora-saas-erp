-- =========================================================================
-- Sachhi Saheli SaaS ERP & HRIS — Multi-Tenant PostgreSQL Schema DDL
-- =========================================================================

-- 1. Tenants & Whitelabel Branding
CREATE TABLE IF NOT EXISTS tenants (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(64) UNIQUE NOT NULL,
    logo_url TEXT,
    favicon_url TEXT,
    primary_color VARCHAR(16) DEFAULT '#4f46e5',
    accent_color VARCHAR(16) DEFAULT '#065f46',
    legal_entity_type VARCHAR(64) DEFAULT 'NGO',
    currency VARCHAR(8) DEFAULT 'INR',
    tagline VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. Users & Personas (with 3-tier hierarchy: Super Admin, App Dev, Client Roles)
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    employee_id VARCHAR(32) NOT NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    role VARCHAR(32) NOT NULL,
    department VARCHAR(128),
    designation VARCHAR(128),
    reporting_manager_id VARCHAR(64),
    joining_date DATE,
    status VARCHAR(32) DEFAULT 'ACTIVE',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_users_tenant ON users(tenant_id);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(tenant_id, email);

-- 3. Employee Master Profiles with Statutory Data
CREATE TABLE IF NOT EXISTS employee_profiles (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    personal_info JSONB NOT NULL DEFAULT '{}'::jsonb,
    job_details JSONB NOT NULL DEFAULT '{}'::jsonb,
    salary_structure JSONB NOT NULL DEFAULT '{}'::jsonb,
    statutory_info JSONB NOT NULL DEFAULT '{}'::jsonb,
    documents_verified BOOLEAN DEFAULT FALSE,
    document_checklist JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_profiles_tenant_user ON employee_profiles(tenant_id, user_id);

-- 4. Attendance & Working Hours (10 AM Late Rule & WFH Capping)
CREATE TABLE IF NOT EXISTS attendance_records (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    user_name VARCHAR(255),
    date DATE NOT NULL,
    check_in_time TIME,
    check_out_time TIME,
    is_late BOOLEAN DEFAULT FALSE,
    is_wfh BOOLEAN DEFAULT FALSE,
    half_day_deduction BOOLEAN DEFAULT FALSE,
    status VARCHAR(32) DEFAULT 'PRESENT',
    ip_address VARCHAR(45),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_attendance_tenant_date ON attendance_records(tenant_id, date);

-- 5. Leave Balances (8 Statutory Leave Types)
CREATE TABLE IF NOT EXISTS leave_balances (
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    casual_leave JSONB NOT NULL,
    sick_leave JSONB NOT NULL,
    earned_leave JSONB NOT NULL,
    maternity_leave JSONB NOT NULL,
    paternity_leave JSONB NOT NULL,
    adoption_leave JSONB NOT NULL,
    leave_without_pay JSONB NOT NULL,
    comp_off JSONB NOT NULL,
    PRIMARY KEY (tenant_id, user_id)
);

-- 6. Recruitment Requisitions
CREATE TABLE IF NOT EXISTS recruitment_requisitions (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    job_title VARCHAR(255) NOT NULL,
    department VARCHAR(128) NOT NULL,
    open_positions INT DEFAULT 1,
    budget_band_annual VARCHAR(128),
    experience_required VARCHAR(128),
    justification TEXT,
    status VARCHAR(32) DEFAULT 'PENDING_APPROVAL',
    requested_by VARCHAR(64),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_requisitions_tenant ON recruitment_requisitions(tenant_id);

-- 7. Candidates & 5-Stage Recruitment Pipeline
CREATE TABLE IF NOT EXISTS candidates (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    requisition_id VARCHAR(64) REFERENCES recruitment_requisitions(id) ON DELETE SET NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(32),
    applied_role VARCHAR(128),
    stage VARCHAR(32) DEFAULT 'SOURCED',
    interview_score INT,
    interview_feedback TEXT,
    reference_checks JSONB DEFAULT '[]'::jsonb,
    offer_details JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_candidates_tenant_stage ON candidates(tenant_id, stage);

-- 8. Onboarding Checklists (Standard, Intern, Contractual)
CREATE TABLE IF NOT EXISTS onboarding_checklists (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    employee_category VARCHAR(32) NOT NULL,
    tasks JSONB NOT NULL DEFAULT '[]'::jsonb,
    probation_end_date DATE,
    probation_status VARCHAR(32) DEFAULT 'IN_PROBATION',
    confirmation_letter_issued BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_onboarding_tenant ON onboarding_checklists(tenant_id, user_id);

-- 9. Performance & SMART KRAs
CREATE TABLE IF NOT EXISTS appraisals (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    cycle_year VARCHAR(16) NOT NULL,
    kras JSONB NOT NULL DEFAULT '[]'::jsonb,
    self_rating INT,
    self_comments TEXT,
    manager_rating INT,
    manager_comments TEXT,
    president_calibrated_rating INT,
    president_comments TEXT,
    status VARCHAR(32) DEFAULT 'SELF_REVIEW',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_appraisals_tenant ON appraisals(tenant_id, user_id);

-- 10. Travel & Tours
CREATE TABLE IF NOT EXISTS travel_tours (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    destination VARCHAR(255) NOT NULL,
    departure_date DATE NOT NULL,
    return_date DATE NOT NULL,
    purpose TEXT,
    city_tier VARCHAR(16) DEFAULT 'Tier-2',
    advance_requested NUMERIC(12, 2) DEFAULT 0,
    advance_disbursed BOOLEAN DEFAULT FALSE,
    status VARCHAR(32) DEFAULT 'PENDING_APPROVAL',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_travel_tenant ON travel_tours(tenant_id, user_id);

-- 11. Expense Claims & Local Conveyance
CREATE TABLE IF NOT EXISTS expense_claims (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    claim_type VARCHAR(32) NOT NULL,
    items JSONB NOT NULL DEFAULT '[]'::jsonb,
    total_amount NUMERIC(12, 2) NOT NULL,
    city_tier VARCHAR(16),
    status VARCHAR(32) DEFAULT 'PENDING_APPROVAL',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_claims_tenant ON expense_claims(tenant_id, user_id);

-- 12. 16 BRD Workflow Instances
CREATE TABLE IF NOT EXISTS workflows (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    workflow_type VARCHAR(64) NOT NULL,
    title VARCHAR(255) NOT NULL,
    requester_id VARCHAR(64) NOT NULL,
    requester_name VARCHAR(255),
    requester_role VARCHAR(32),
    department VARCHAR(128),
    current_stage VARCHAR(64) NOT NULL,
    stages JSONB NOT NULL,
    payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_workflows_tenant_stage ON workflows(tenant_id, current_stage);

-- 13. Exit Clearance (16-Step Checklist & F&F Settlement)
CREATE TABLE IF NOT EXISTS exit_records (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    resignation_date DATE,
    approved_lwd DATE,
    reason TEXT,
    status VARCHAR(32) DEFAULT 'CLEARANCE_IN_PROGRESS',
    checklist_16_steps JSONB NOT NULL,
    fnf_details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_exit_tenant ON exit_records(tenant_id, user_id);

-- 14. Finance & Chart of Accounts
CREATE TABLE IF NOT EXISTS finance_coa (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    code VARCHAR(32) NOT NULL,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(32) NOT NULL,
    balance NUMERIC(14, 2) DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_coa_tenant ON finance_coa(tenant_id);

-- 15. Invoices (Accounts Receivable & Accounts Payable)
CREATE TABLE IF NOT EXISTS invoices (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    invoice_type VARCHAR(16) NOT NULL,
    invoice_number VARCHAR(64) NOT NULL,
    party VARCHAR(255) NOT NULL,
    description TEXT,
    amount NUMERIC(14, 2) NOT NULL,
    due_date DATE,
    status VARCHAR(32) DEFAULT 'DUE',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_invoices_tenant ON invoices(tenant_id, invoice_type);

-- 16. CRM Contacts & Donor Pipeline
CREATE TABLE IF NOT EXISTS crm_contacts (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    org_name VARCHAR(255) NOT NULL,
    contact_person VARCHAR(255),
    stage VARCHAR(32) DEFAULT 'LEAD',
    grant_amount NUMERIC(14, 2) DEFAULT 0,
    focus VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_crm_tenant ON crm_contacts(tenant_id, stage);

-- 17. PPM Projects & Tasks
CREATE TABLE IF NOT EXISTS ppm_projects (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    code VARCHAR(64) NOT NULL,
    name VARCHAR(255) NOT NULL,
    budget NUMERIC(14, 2),
    spent NUMERIC(14, 2),
    manager VARCHAR(255),
    progress_percent INT DEFAULT 0,
    status VARCHAR(32) DEFAULT 'ON_TRACK',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ppm_tasks (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    project_id VARCHAR(64) REFERENCES ppm_projects(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    assignee_id VARCHAR(64),
    assignee_name VARCHAR(255),
    stage VARCHAR(32) DEFAULT 'TO_DO',
    priority VARCHAR(16) DEFAULT 'MEDIUM',
    due_date DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_tasks_tenant ON ppm_tasks(tenant_id, stage);

-- 18. Timesheets
CREATE TABLE IF NOT EXISTS timesheets (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id VARCHAR(64) NOT NULL,
    employee_name VARCHAR(255),
    project_name VARCHAR(255),
    hours NUMERIC(6, 2) NOT NULL,
    week_ending DATE NOT NULL,
    status VARCHAR(32) DEFAULT 'SUBMITTED',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_timesheets_tenant ON timesheets(tenant_id);

-- 19. Immutable Statutory Audit Ledger
CREATE TABLE IF NOT EXISTS audit_logs (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    user_id VARCHAR(64),
    user_name VARCHAR(255),
    user_role VARCHAR(32),
    action VARCHAR(128) NOT NULL,
    module VARCHAR(64) NOT NULL,
    details TEXT,
    ip_address VARCHAR(45)
);
CREATE INDEX IF NOT EXISTS idx_audit_tenant_ts ON audit_logs(tenant_id, timestamp DESC);

-- 20. Enterprise Chatter & Activity Stream
CREATE TABLE IF NOT EXISTS chatter_messages (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    record_type VARCHAR(64) NOT NULL,
    record_id VARCHAR(64) NOT NULL,
    author_id VARCHAR(64),
    author_name VARCHAR(255),
    message_type VARCHAR(32) DEFAULT 'NOTE',
    content TEXT NOT NULL,
    activity_type VARCHAR(32),
    due_date DATE,
    completed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_chatter_tenant_rec ON chatter_messages(tenant_id, record_type, record_id);
