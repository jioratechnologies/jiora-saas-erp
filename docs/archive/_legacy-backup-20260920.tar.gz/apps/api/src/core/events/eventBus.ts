import { EventEmitter } from 'events';

export interface DomainEvent<T = any> {
  eventId: string;
  eventType: string;
  sourceModule: string;
  timestamp: string;
  payload: T;
}

class DomainEventBus {
  private emitter = new EventEmitter();

  constructor() {
    this.emitter.setMaxListeners(50);
  }

  public publish<T>(eventType: string, sourceModule: string, payload: T): void {
    const event: DomainEvent<T> = {
      eventId: `evt_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      eventType,
      sourceModule,
      timestamp: new Date().toISOString(),
      payload,
    };

    console.log(`[EventBus] Published event: ${eventType} from [${sourceModule}]`, {
      id: event.eventId,
      payloadSnippet: JSON.stringify(payload).substring(0, 80),
    });

    // In microservices mode, this emits to Redis PubSub or Kafka
    this.emitter.emit(eventType, event);
    this.emitter.emit('*', event);
  }

  public subscribe<T>(eventType: string, handler: (event: DomainEvent<T>) => void): void {
    this.emitter.on(eventType, handler);
  }
}

export const eventBus = new DomainEventBus();
