import { Request, Response, NextFunction } from 'express';
import { formatErrorResponse } from '../errors/index.js';
import { logger } from '../logging/logger.js';
import { CorrelatedRequest } from './loggingMiddleware.js';

export const errorHandler = (err: any, req: Request, res: Response, next: NextFunction) => {
  const requestId = (req as CorrelatedRequest).requestId || (req.headers['x-request-id'] as string);
  const tenantId = (req as CorrelatedRequest).tenantId || (req.headers['x-tenant-id'] as string);

  const { statusCode, envelope } = formatErrorResponse(err, requestId);

  logger.error(`Error handling ${req.method} ${req.url}: ${err.message}`, {
    requestId,
    tenantId,
    statusCode,
    errorCode: envelope.error.code,
  }, err);

  res.status(statusCode).json(envelope);
};
