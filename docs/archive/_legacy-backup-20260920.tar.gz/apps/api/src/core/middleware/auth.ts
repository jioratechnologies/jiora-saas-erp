import { Request, Response, NextFunction } from 'express';
import { db } from '../database/store.js';
import { User, UserRole } from '../types/index.js';
import { UnauthorizedError, ForbiddenError, TenantError } from '../errors/index.js';

export interface AuthenticatedRequest extends Request {
  user?: User;
  tenantId?: string;
  requestId?: string;
}

export const authenticate = (req: Request, res: Response, next: NextFunction): void => {
  const authReq = req as AuthenticatedRequest;

  // 1. Resolve tenant context
  const tenantId = (req.headers['x-tenant-id'] as string) || 'sachhi-saheli-delhi';
  const tenant = db.getTenant(tenantId);
  if (!tenant) {
    return next(new TenantError(`Tenant '${tenantId}' does not exist or is inactive.`));
  }
  authReq.tenantId = tenantId;

  // 2. Check for Zitadel OIDC Bearer token or simulated local persona
  const simulatedUserId = req.headers['x-simulated-user-id'] as string;
  const simulatedUserRole = req.headers['x-simulated-role'] as UserRole;
  const authHeader = req.headers.authorization;

  if (simulatedUserId) {
    const user = db.users.find((u) => u.id === simulatedUserId && (u.role === 'SUPER_ADMIN' || u.tenantId === tenantId));
    if (user) {
      authReq.user = user;
      return next();
    }
  }

  if (simulatedUserRole) {
    const user = db.users.find((u) => u.role === simulatedUserRole && (u.role === 'SUPER_ADMIN' || u.tenantId === tenantId));
    if (user) {
      authReq.user = user;
      return next();
    }
  }

  // 3. If standard Bearer JWT from Zitadel
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    try {
      // Decode JWT payload (Zitadel standard OIDC claims)
      const parts = token.split('.');
      if (parts.length === 3) {
        const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString('utf8'));
        const userEmail = payload.email || payload.preferred_username;
        const matchedUser = db.users.find((u) => u.email === userEmail);
        if (matchedUser) {
          authReq.user = matchedUser;
          return next();
        }
      }
    } catch {
      // Continue to fallback
    }
  }

  // 4. Default persona for the active tenant (President or Super Admin)
  const tenantUsers = db.getUsers(tenantId);
  authReq.user = tenantUsers.find((u) => u.role === 'PRESIDENT') || db.users[0];
  next();
};

export const requireRole = (allowedRoles: UserRole[]) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    const authReq = req as AuthenticatedRequest;
    if (!authReq.user) {
      return next(new UnauthorizedError('Authentication token or simulated persona required.'));
    }

    // SUPER_ADMIN has global bypass permissions
    if (authReq.user.role === 'SUPER_ADMIN') {
      return next();
    }

    if (!allowedRoles.includes(authReq.user.role)) {
      return next(
        new ForbiddenError(
          `Forbidden: Action requires role in [${allowedRoles.join(', ')}], but current user has role [${authReq.user.role}]`,
          { requiredRoles: allowedRoles, currentRole: authReq.user.role }
        )
      );
    }

    next();
  };
};
