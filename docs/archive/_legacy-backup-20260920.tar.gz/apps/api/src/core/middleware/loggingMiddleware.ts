import { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { logger } from '../logging/logger.js';

export interface CorrelatedRequest extends Request {
  requestId: string;
  tenantId: string;
}

export const requestLogger = (req: Request, res: Response, next: NextFunction) => {
  const start = Date.now();
  const requestId = (req.headers['x-request-id'] as string) || `req_${uuidv4().substring(0, 8)}`;
  const tenantId = (req.headers['x-tenant-id'] as string) || 'sachhi-saheli-delhi';

  (req as CorrelatedRequest).requestId = requestId;
  (req as CorrelatedRequest).tenantId = tenantId;
  res.setHeader('X-Request-ID', requestId);
  res.setHeader('X-Tenant-ID', tenantId);

  res.on('finish', () => {
    const durationMs = Date.now() - start;
    const statusCode = res.statusCode;

    const context = {
      requestId,
      tenantId,
      method: req.method,
      path: req.originalUrl || req.url,
      statusCode,
      durationMs,
      ip: req.ip || req.socket.remoteAddress,
      userAgent: req.get('user-agent'),
      userId: req.headers['x-simulated-user-id'] as string,
    };

    if (statusCode >= 500) {
      logger.error(`HTTP ${req.method} ${req.url} - ${statusCode} [${durationMs}ms]`, context);
    } else if (statusCode >= 400) {
      logger.warn(`HTTP ${req.method} ${req.url} - ${statusCode} [${durationMs}ms]`, context);
    } else {
      logger.info(`HTTP ${req.method} ${req.url} - ${statusCode} [${durationMs}ms]`, context);
    }
  });

  next();
};
