export abstract class AppError extends Error {
  abstract readonly statusCode: number;
  abstract readonly errorCode: string;
  readonly timestamp: string;

  constructor(message: string, public readonly details?: any) {
    super(message);
    this.name = this.constructor.name;
    this.timestamp = new Date().toISOString();
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

export class ValidationError extends AppError {
  readonly statusCode = 400;
  readonly errorCode = 'VALIDATION_ERROR';
}

export class UnauthorizedError extends AppError {
  readonly statusCode = 401;
  readonly errorCode = 'UNAUTHORIZED';
}

export class ForbiddenError extends AppError {
  readonly statusCode = 403;
  readonly errorCode = 'FORBIDDEN_ACCESS';
}

export class NotFoundError extends AppError {
  readonly statusCode = 404;
  readonly errorCode = 'RESOURCE_NOT_FOUND';
}

export class ConflictError extends AppError {
  readonly statusCode = 409;
  readonly errorCode = 'RESOURCE_CONFLICT';
}

export class TenantError extends AppError {
  readonly statusCode = 400;
  readonly errorCode = 'INVALID_TENANT';
}

export class StatutoryComplianceError extends AppError {
  readonly statusCode = 422;
  readonly errorCode = 'STATUTORY_COMPLIANCE_BREACH';
}

export class WorkflowTransitionError extends AppError {
  readonly statusCode = 400;
  readonly errorCode = 'INVALID_WORKFLOW_TRANSITION';
}

export interface ErrorResponseEnvelope {
  success: false;
  error: {
    code: string;
    message: string;
    details?: any;
    requestId?: string;
    timestamp: string;
  };
}

export function formatErrorResponse(err: Error | AppError, requestId?: string): { statusCode: number; envelope: ErrorResponseEnvelope } {
  if (err instanceof AppError) {
    return {
      statusCode: err.statusCode,
      envelope: {
        success: false,
        error: {
          code: err.errorCode,
          message: err.message,
          details: err.details,
          requestId,
          timestamp: err.timestamp,
        },
      },
    };
  }

  // Fallback for unhandled unexpected errors
  return {
    statusCode: 500,
    envelope: {
      success: false,
      error: {
        code: 'INTERNAL_SERVER_ERROR',
        message: err.message || 'An unexpected error occurred.',
        requestId,
        timestamp: new Date().toISOString(),
      },
    },
  };
}
