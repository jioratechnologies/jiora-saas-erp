import http from 'http';
import { Server as SocketIOServer, Socket } from 'socket.io';
import { createAdapter } from '@socket.io/redis-adapter';
import { redisClient, isRedisAvailable } from '../database/redis.js';
import { eventBus, DomainEvent } from '../events/eventBus.js';
import { logger } from '../logging/logger.js';

let io: SocketIOServer | null = null;

export interface RealtimeMessage {
  event: string;
  payload: any;
  tenantId: string;
  senderId?: string;
  timestamp: string;
}

/**
 * Initialize Socket.IO Real-Time Server
 * Features:
 * - Multi-tenant room isolation (tenant:{tenantId}, user:{userId}, record:{type}:{id})
 * - Redis pub/sub adapter for horizontal clustering across multi-instance nodes
 * - Graceful fallback to in-memory adapter when Redis is offline
 */
export function initSocketServer(httpServer: http.Server): SocketIOServer {
  io = new SocketIOServer(httpServer, {
    cors: {
      origin: true, // Dynamically reflect origin to support credentials: true
      methods: ['GET', 'POST', 'PATCH', 'DELETE'],
      credentials: true,
    },
    transports: ['websocket', 'polling'],
    pingTimeout: 30000,
    pingInterval: 10000,
  });

  // Attach Redis adapter if Redis is online
  try {
    if (isRedisAvailable && redisClient) {
      const pubClient = redisClient.duplicate();
      const subClient = redisClient.duplicate();
      io.adapter(createAdapter(pubClient, subClient));
      logger.info('Socket.IO configured with Redis pub/sub distributed cluster adapter');
    } else {
      logger.info('Socket.IO running with local high-performance memory adapter');
    }
  } catch (err: any) {
    logger.warn('Socket.IO Redis adapter setup failed, defaulting to local adapter', { error: err.message });
  }

  // Connection lifecycle & authentication
  io.use((socket: Socket, next) => {
    const tenantId = (socket.handshake.auth?.tenantId || socket.handshake.query?.tenantId || 'sachhi-saheli-delhi') as string;
    const userId = (socket.handshake.auth?.userId || socket.handshake.query?.userId || 'anonymous') as string;
    const userName = (socket.handshake.auth?.userName || socket.handshake.query?.userName || 'Anonymous User') as string;
    const role = (socket.handshake.auth?.role || socket.handshake.query?.role || 'EMPLOYEE') as string;

    socket.data = {
      tenantId,
      userId,
      userName,
      role,
      connectedAt: new Date().toISOString(),
    };

    next();
  });

  io.on('connection', (socket: Socket) => {
    const { tenantId, userId, userName, role } = socket.data;

    // Automatically join tenant and private user rooms
    const tenantRoom = `tenant:${tenantId}`;
    const userRoom = `user:${userId}`;

    socket.join(tenantRoom);
    if (userId && userId !== 'anonymous') {
      socket.join(userRoom);
    }

    logger.info(`Realtime client connected: ${userName} (${role})`, {
      socketId: socket.id,
      tenantId,
      userId,
      role,
    });

    // Client subscribes to a specific record chatter stream (e.g. candidate, invoice, task)
    socket.on('subscribe:record', ({ recordType, recordId }: { recordType: string; recordId: string }) => {
      if (recordType && recordId) {
        const recordRoom = `record:${tenantId}:${recordType}:${recordId}`;
        socket.join(recordRoom);
        logger.debug(`Socket ${socket.id} joined record room: ${recordRoom}`);
      }
    });

    // Client unsubscribes from a record chatter stream
    socket.on('unsubscribe:record', ({ recordType, recordId }: { recordType: string; recordId: string }) => {
      if (recordType && recordId) {
        const recordRoom = `record:${tenantId}:${recordType}:${recordId}`;
        socket.leave(recordRoom);
        logger.debug(`Socket ${socket.id} left record room: ${recordRoom}`);
      }
    });

    // Client subscribes to an approval workflow instance
    socket.on('subscribe:workflow', ({ workflowId }: { workflowId: string }) => {
      if (workflowId) {
        const wfRoom = `workflow:${tenantId}:${workflowId}`;
        socket.join(wfRoom);
      }
    });

    socket.on('unsubscribe:workflow', ({ workflowId }: { workflowId: string }) => {
      if (workflowId) {
        const wfRoom = `workflow:${tenantId}:${workflowId}`;
        socket.leave(wfRoom);
      }
    });

    // Ping / heartbeat
    socket.on('client:ping', () => {
      socket.emit('server:pong', { timestamp: new Date().toISOString() });
    });

    socket.on('disconnect', (reason) => {
      logger.info(`Realtime client disconnected: ${userName} (${reason})`, {
        socketId: socket.id,
        tenantId,
        userId,
      });
    });
  });

  // Bridge domain events from eventBus to real-time WebSockets
  eventBus.subscribe('*', (event: DomainEvent<any>) => {
    const payload = event.payload || {};
    const tenantId = payload.tenantId || 'sachhi-saheli-delhi';

    // Broadcast domain event to tenant room
    emitToTenant(tenantId, 'domain:event', event);

    // If event specifies a target user, send directly to user channel
    if (payload.userId || payload.requesterId) {
      const targetUserId = payload.userId || payload.requesterId;
      emitToUser(targetUserId, 'domain:user_event', event);
    }

    // If event concerns a workflow, broadcast to workflow room
    if (payload.workflowId || (event.eventType && event.eventType.startsWith('WORKFLOW_'))) {
      const wfId = payload.workflowId || payload.id;
      if (wfId) {
        emitToWorkflow(tenantId, wfId, 'workflow:transition', event);
      }
    }
  });

  return io;
}

export function getIo(): SocketIOServer | null {
  return io;
}

/**
 * Broadcast event across an entire tenant (e.g. company announcements, biometric punches)
 */
export function emitToTenant(tenantId: string, event: string, payload: any) {
  if (!io) return;
  const room = `tenant:${tenantId}`;
  io.to(room).emit(event, {
    event,
    payload,
    tenantId,
    timestamp: new Date().toISOString(),
  });
}

/**
 * Send event to a specific individual user (e.g. approval requested, leave approved)
 */
export function emitToUser(userId: string, event: string, payload: any) {
  if (!io) return;
  const room = `user:${userId}`;
  io.to(room).emit(event, {
    event,
    payload,
    userId,
    timestamp: new Date().toISOString(),
  });
}

/**
 * Broadcast live chatter note / activity to everyone viewing a specific record
 */
export function emitToRecord(tenantId: string, recordType: string, recordId: string, event: string, payload: any) {
  if (!io) return;
  const room = `record:${tenantId}:${recordType}:${recordId}`;
  io.to(room).emit(event, {
    event,
    recordType,
    recordId,
    payload,
    tenantId,
    timestamp: new Date().toISOString(),
  });
}

/**
 * Broadcast real-time workflow state machine transition
 */
export function emitToWorkflow(tenantId: string, workflowId: string, event: string, payload: any) {
  if (!io) return;
  const room = `workflow:${tenantId}:${workflowId}`;
  io.to(room).emit(event, {
    event,
    workflowId,
    payload,
    tenantId,
    timestamp: new Date().toISOString(),
  });
}
