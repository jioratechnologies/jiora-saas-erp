export type UserRole = 
  | 'SUPER_ADMIN' 
  | 'APP_DEVELOPER' 
  | 'PRESIDENT' 
  | 'HR' 
  | 'FINANCE' 
  | 'MANAGER' 
  | 'EMPLOYEE';

export interface Tenant {
  id: string;
  name: string;
  slug: string;
  logoUrl?: string;
  faviconUrl?: string;
  primaryColor?: string;
  accentColor?: string;
  legalEntityType?: string;
  currency?: string;
  tagline?: string;
  createdAt?: string;
}

export interface User {
  id: string;
  tenantId: string;
  employeeId: string;
  email: string;
  name: string;
  role: UserRole;
  department: string;
  designation: string;
  avatarUrl?: string;
  reportingManagerId?: string;
  joiningDate: string;
  status: 'ACTIVE' | 'PROBATION' | 'NOTICE_PERIOD' | 'EXITED';
  passwordHash?: string;
}

export type WorkflowStatus = 
  | 'DRAFT'
  | 'PENDING_MANAGER'
  | 'PENDING_HR'
  | 'PENDING_FINANCE'
  | 'PENDING_PRESIDENT'
  | 'APPROVED'
  | 'REJECTED'
  | 'CANCELLED';

export interface WorkflowStage {
  stage: WorkflowStatus;
  approverRole: UserRole;
  approverId?: string;
  approverName?: string;
  decision?: 'APPROVED' | 'REJECTED';
  comments?: string;
  actionDate?: string;
}

export interface WorkflowInstance {
  id: string;
  tenantId: string;
  workflowType: string;
  title: string;
  requesterId: string;
  requesterName: string;
  requesterRole: UserRole;
  department: string;
  currentStage: WorkflowStatus;
  stages: WorkflowStage[];
  payload: any;
  createdAt: string;
  updatedAt: string;
}

export interface AuditLogEntry {
  id: string;
  tenantId: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: string;
  module: string;
  entityId?: string;
  details: string;
  ipAddress?: string;
}

export interface RecruitmentRequisition {
  id: string;
  tenantId: string;
  jobTitle: string;
  department: string;
  openPositions: number;
  budgetBandAnnual: string;
  experienceRequired: string;
  justification: string;
  status: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED' | 'CLOSED';
  requestedBy: string;
  createdAt: string;
}

export interface ReferenceCheck {
  referee: string;
  designation: string;
  feedback: string;
  verified: boolean;
  verifiedDate?: string;
}

export interface Candidate {
  id: string;
  tenantId: string;
  requisitionId?: string;
  name: string;
  email: string;
  phone?: string;
  appliedRole: string;
  stage: 'SOURCED' | 'SCREENING' | 'INTERVIEW' | 'REFERENCE_CHECK' | 'OFFER_SENT' | 'HIRED' | 'REJECTED';
  interviewScore?: number;
  interviewFeedback?: string;
  referenceChecks: ReferenceCheck[];
  offerDetails?: {
    offeredCtc: number;
    joiningDate: string;
    status: 'PENDING_ACCEPTANCE' | 'ACCEPTED' | 'DECLINED';
    signedBy?: string;
  };
  createdAt: string;
}

export interface OnboardingChecklist {
  id: string;
  tenantId: string;
  userId: string;
  employeeCategory: 'STANDARD' | 'INTERN' | 'CONTRACTUAL';
  tasks: {
    id: string;
    department: 'IT' | 'ADMIN' | 'HR' | 'MANAGER';
    task: string;
    completed: boolean;
  }[];
  probationEndDate?: string;
  probationStatus: 'IN_PROBATION' | 'CONFIRMED' | 'EXTENDED';
  confirmationLetterIssued: boolean;
  createdAt: string;
}

export interface Appraisal {
  id: string;
  tenantId: string;
  userId: string;
  cycleYear: string;
  kras: {
    kra: string;
    metric: string;
    weightage: number;
    achievement: number;
  }[];
  selfRating?: number;
  selfComments?: string;
  managerRating?: number;
  managerComments?: string;
  presidentCalibratedRating?: number;
  presidentComments?: string;
  status: 'SELF_REVIEW' | 'MANAGER_REVIEW' | 'PRESIDENT_CALIBRATED' | 'FINALIZED';
  createdAt: string;
}

export interface TravelTour {
  id: string;
  tenantId: string;
  userId: string;
  destination: string;
  departureDate: string;
  returnDate: string;
  purpose: string;
  cityTier: 'Tier-1' | 'Tier-2' | 'Tier-3';
  advanceRequested: number;
  advanceDisbursed: boolean;
  status: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED';
  createdAt: string;
}

export interface ExpenseClaim {
  id: string;
  tenantId: string;
  userId: string;
  claimType: 'TOUR_TRAVEL' | 'LOCAL_CONVEYANCE' | 'HEALTH_CHECKUP' | 'EMERGENCY_ADVANCE';
  items: any[];
  totalAmount: number;
  cityTier?: string;
  status: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED' | 'REIMBURSED';
  createdAt: string;
}

export interface Invoice {
  id: string;
  tenantId: string;
  invoiceType: 'AR' | 'AP';
  invoiceNumber: string;
  party: string;
  description: string;
  amount: number;
  dueDate: string;
  status: 'DUE' | 'PENDING_APPROVAL' | 'APPROVED' | 'PAID';
  createdAt: string;
}

export interface PpmTask {
  id: string;
  tenantId: string;
  projectId: string;
  title: string;
  assigneeId?: string;
  assigneeName?: string;
  stage: 'TO_DO' | 'IN_PROGRESS' | 'REVIEW' | 'DONE';
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
  dueDate?: string;
  createdAt: string;
}

export interface ChatterMessage {
  id: string;
  tenantId: string;
  recordType: string;
  recordId: string;
  authorId?: string;
  authorName?: string;
  messageType: 'NOTE' | 'MESSAGE' | 'ACTIVITY';
  content: string;
  activityType?: 'CALL' | 'EMAIL' | 'MEETING' | 'TODO';
  dueDate?: string;
  completed?: boolean;
  createdAt: string;
}
