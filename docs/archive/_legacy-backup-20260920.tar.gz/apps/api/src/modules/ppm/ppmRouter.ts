import { Router, Response } from 'express';
import { db } from '../../core/database/store.js';
import { AuthenticatedRequest, authenticate, requireRole } from '../../core/middleware/auth.js';
import { ValidationError, NotFoundError } from '../../core/errors/index.js';
import { PpmTask } from '../../core/types/index.js';

export const ppmRouter = Router();

// 1. Get Projects
ppmRouter.get('/projects', authenticate, (req: any, res: Response) => {
  const tenantId = req.tenantId;
  const projects = db.ppmProjects.filter((p) => p.tenantId === tenantId);
  res.json({ success: true, count: projects.length, data: projects });
});

// 2. Get Tasks (Grouped for Kanban)
ppmRouter.get('/tasks', authenticate, (req: any, res: Response) => {
  const tenantId = req.tenantId;
  const tasks = db.getPpmTasks(tenantId);
  const stages = ['TO_DO', 'IN_PROGRESS', 'REVIEW', 'DONE'];

  const kanban = stages.map((stg) => ({
    stage: stg,
    count: tasks.filter((t) => t.stage === stg).length,
    tasks: tasks.filter((t) => t.stage === stg),
  }));

  res.json({
    success: true,
    total: tasks.length,
    kanban,
    data: tasks,
  });
});

// 3. Create Task
ppmRouter.post('/tasks', authenticate, (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { projectId, title, assigneeId, priority, dueDate } = req.body;

    if (!title) {
      throw new ValidationError('Task title is mandatory.');
    }

    const assignee = db.users.find((u) => u.id === assigneeId && u.tenantId === tenantId);

    const newTask: PpmTask = {
      id: `tsk_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      tenantId,
      projectId: projectId || 'ppm_01',
      title,
      assigneeId: assigneeId || req.user.id,
      assigneeName: assignee ? assignee.name : req.user.name,
      stage: 'TO_DO',
      priority: priority || 'MEDIUM',
      dueDate: dueDate || new Date(Date.now() + 86400000 * 7).toISOString().split('T')[0],
      createdAt: new Date().toISOString(),
    };

    db.ppmTasks.unshift(newTask);

    db.addChatterMessage({
      tenantId,
      recordType: 'task',
      recordId: newTask.id,
      authorId: req.user.id,
      authorName: req.user.name,
      messageType: 'NOTE',
      content: `Task "${title}" created and assigned to ${newTask.assigneeName}.`,
    });

    res.status(201).json({ success: true, data: newTask });
  } catch (err) {
    next(err);
  }
});

// 4. Update Task Stage (Kanban card move)
ppmRouter.patch('/tasks/:id/stage', authenticate, (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { id } = req.params;
    const { stage } = req.body;

    const task = db.ppmTasks.find((t) => t.id === id && t.tenantId === tenantId);
    if (!task) {
      throw new NotFoundError('Task not found.');
    }

    const prevStage = task.stage;
    task.stage = stage;

    db.addChatterMessage({
      tenantId,
      recordType: 'task',
      recordId: task.id,
      authorId: req.user.id,
      authorName: req.user.name,
      messageType: 'NOTE',
      content: `Task stage moved from [${prevStage}] to [${stage}].`,
    });

    res.json({ success: true, data: task });
  } catch (err) {
    next(err);
  }
});

// 5. Get Timesheets
ppmRouter.get('/timesheets', authenticate, (req: any, res: Response) => {
  const tenantId = req.tenantId;
  const timesheets = db.timesheets.filter((t) => t.tenantId === tenantId);
  res.json({ success: true, count: timesheets.length, data: timesheets });
});

// 6. Log Timesheet
ppmRouter.post('/timesheets', authenticate, (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { projectName, hours, weekEnding } = req.body;

    if (!hours) {
      throw new ValidationError('Hours logged must be greater than 0.');
    }

    const newTs = {
      id: `ts_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      tenantId,
      userId: req.user.id,
      employeeName: req.user.name,
      projectName: projectName || 'Project Saheli: Delhi NCR Health Drive',
      hours: Number(hours),
      weekEnding: weekEnding || new Date().toISOString().split('T')[0],
      status: 'SUBMITTED',
      createdAt: new Date().toISOString(),
    };

    db.timesheets.unshift(newTs);

    res.status(201).json({ success: true, data: newTs });
  } catch (err) {
    next(err);
  }
});
