import { Router, Response } from 'express';
import { db } from '../../core/database/store.js';
import { AuthenticatedRequest, authenticate, requireRole } from '../../core/middleware/auth.js';
import { ValidationError, NotFoundError } from '../../core/errors/index.js';

export const crmRouter = Router();

// 1. Get all contacts
crmRouter.get('/contacts', authenticate, (req: any, res: Response) => {
  const tenantId = req.tenantId;
  const contacts = db.crmContacts.filter((c) => c.tenantId === tenantId);
  res.json({ success: true, count: contacts.length, data: contacts });
});

// 2. Get Visual CRM Pipeline (Kanban Board)
crmRouter.get('/pipeline', authenticate, (req: any, res: Response) => {
  const tenantId = req.tenantId;
  const contacts = db.crmContacts.filter((c) => c.tenantId === tenantId);
  const stages = ['LEAD', 'CONTACTED', 'PROPOSAL_SUBMITTED', 'PARTNERED'];

  const grouped = stages.map((stage) => {
    const items = contacts.filter((c) => c.stage === stage);
    return {
      stage,
      count: items.length,
      totalGrantValue: items.reduce((acc, curr) => acc + (Number(curr.grantAmount || curr.grantPotential) || 0), 0),
      contacts: items,
    };
  });

  res.json({ success: true, pipeline: grouped });
});

// 3. Create Lead / Institutional Partner
crmRouter.post('/contacts', authenticate, (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { orgName, contactPerson, stage, grantAmount, focus } = req.body;

    if (!orgName) {
      throw new ValidationError('Organization or Donor name is mandatory.');
    }

    const newContact = {
      id: `crm_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      tenantId,
      orgName,
      contactPerson: contactPerson || 'Principal Representative',
      stage: stage || 'LEAD',
      grantAmount: Number(grantAmount) || 0,
      grantPotential: Number(grantAmount) || 0,
      focus: focus || 'Adolescent Healthcare & Gender Equity',
    };

    db.crmContacts.unshift(newContact);

    db.addChatterMessage({
      tenantId,
      recordType: 'crm',
      recordId: newContact.id,
      authorId: req.user.id,
      authorName: req.user.name,
      messageType: 'NOTE',
      content: `Created lead for ${orgName} in stage [${newContact.stage}].`,
    });

    res.status(201).json({ success: true, data: newContact });
  } catch (err) {
    next(err);
  }
});

// 4. Update Lead Stage (Kanban transition)
crmRouter.patch('/contacts/:id/stage', authenticate, (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { id } = req.params;
    const { stage } = req.body;

    const contact = db.crmContacts.find((c) => c.id === id && c.tenantId === tenantId);
    if (!contact) {
      throw new NotFoundError('CRM Contact not found.');
    }

    const prevStage = contact.stage;
    contact.stage = stage;

    db.addChatterMessage({
      tenantId,
      recordType: 'crm',
      recordId: contact.id,
      authorId: req.user.id,
      authorName: req.user.name,
      messageType: 'NOTE',
      content: `Lead stage progressed from [${prevStage}] to [${stage}].`,
    });

    res.json({ success: true, data: contact });
  } catch (err) {
    next(err);
  }
});
