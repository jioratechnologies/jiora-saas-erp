import { Router, Response } from 'express';
import { db } from '../../core/database/store.js';
import { AuthenticatedRequest, authenticate } from '../../core/middleware/auth.js';

export const authRouter = Router();

// Get personas for active tenant (and global platform operators)
authRouter.get('/personas', (req: any, res: Response) => {
  const tenantId = (req.headers['x-tenant-id'] as string) || 'sachhi-saheli-delhi';
  
  // Return users belonging to this tenant plus Super Admin and App Dev
  const personas = db.users.filter(
    (u) => u.tenantId === tenantId || u.role === 'SUPER_ADMIN' || u.role === 'APP_DEVELOPER'
  );

  res.json({
    success: true,
    count: personas.length,
    tenantId,
    data: personas,
  });
});

// Get current authenticated user
authRouter.get('/me', authenticate, (req: any, res: Response) => {
  res.json({
    success: true,
    tenantId: req.tenantId,
    data: req.user,
  });
});
