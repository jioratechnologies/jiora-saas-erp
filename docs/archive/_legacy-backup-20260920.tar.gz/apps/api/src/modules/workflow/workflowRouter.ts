import { Router, Response } from 'express';
import { db } from '../../core/database/store.js';
import { AuthenticatedRequest, authenticate } from '../../core/middleware/auth.js';
import { eventBus } from '../../core/events/eventBus.js';
import { WorkflowInstance, WorkflowStatus } from '../../core/types/index.js';
import { NotFoundError, ForbiddenError, WorkflowTransitionError } from '../../core/errors/index.js';

export const workflowRouter = Router();

// Get all workflows (filtered by tenant and user role)
workflowRouter.get('/', authenticate, (req: any, res: Response) => {
  const tenantId = req.tenantId;
  const user = req.user!;
  let list = db.getWorkflows(tenantId);

  // Filter based on role
  if (user.role === 'EMPLOYEE') {
    list = list.filter((w) => w.requesterId === user.id);
  } else if (user.role === 'MANAGER') {
    list = list.filter(
      (w) =>
        w.requesterId === user.id ||
        w.currentStage === 'PENDING_MANAGER' ||
        w.stages.some((s) => s.approverId === user.id)
    );
  } else if (user.role === 'HR') {
    list = list.filter(
      (w) =>
        w.currentStage === 'PENDING_HR' ||
        w.workflowType.startsWith('LEAVE') ||
        w.workflowType.startsWith('RECRUITMENT') ||
        w.workflowType.startsWith('EXIT')
    );
  } else if (user.role === 'FINANCE') {
    list = list.filter(
      (w) =>
        w.currentStage === 'PENDING_FINANCE' ||
        w.workflowType.includes('ADVANCE') ||
        w.workflowType.includes('EXPENSE') ||
        w.workflowType.includes('PAYROLL')
    );
  }
  // PRESIDENT and SUPER_ADMIN see all workflows

  res.json({ success: true, count: list.length, data: list });
});

// Get pending approval count & inbox for current user
workflowRouter.get('/inbox', authenticate, (req: any, res: Response) => {
  const tenantId = req.tenantId;
  const user = req.user!;
  const targetStage: Record<string, WorkflowStatus> = {
    MANAGER: 'PENDING_MANAGER',
    HR: 'PENDING_HR',
    FINANCE: 'PENDING_FINANCE',
    PRESIDENT: 'PENDING_PRESIDENT',
  };

  const myStage = targetStage[user.role];
  const pendingItems = myStage
    ? db.getWorkflows(tenantId).filter((w) => w.currentStage === myStage)
    : user.role === 'SUPER_ADMIN'
    ? db.getWorkflows(tenantId)
    : [];

  res.json({
    success: true,
    count: pendingItems.length,
    data: pendingItems,
  });
});

// Approve a workflow step
workflowRouter.post('/:id/approve', authenticate, (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { id } = req.params;
    const { comments } = req.body;
    const user = req.user!;

    const wf = db.workflows.find((w) => w.id === id && w.tenantId === tenantId);
    if (!wf) {
      throw new NotFoundError('Workflow not found.');
    }

    const currentStageIndex = wf.stages.findIndex((s) => s.stage === wf.currentStage);
    if (currentStageIndex === -1 && wf.currentStage !== 'APPROVED') {
      throw new WorkflowTransitionError('Workflow has no active pending stage.');
    }

    const stage = wf.stages[currentStageIndex];

    // RBAC check: Only authorized approver role (or President / Super Admin) can approve
    if (user.role !== 'SUPER_ADMIN' && user.role !== 'PRESIDENT' && user.role !== stage.approverRole) {
      throw new ForbiddenError(
        `Forbidden: Stage [${stage.stage}] requires approver role [${stage.approverRole}], but your current role is [${user.role}].`,
        { requiredRole: stage.approverRole, currentRole: user.role }
      );
    }

    stage.decision = 'APPROVED';
    stage.comments = comments || 'Approved';
    stage.actionDate = new Date().toISOString();
    stage.approverId = user.id;
    stage.approverName = user.name;

    // Advance to next stage or mark APPROVED
    const nextStageIndex = currentStageIndex + 1;
    if (nextStageIndex < wf.stages.length) {
      wf.currentStage = wf.stages[nextStageIndex].stage;
    } else {
      wf.currentStage = 'APPROVED';
    }

    wf.updatedAt = new Date().toISOString();

    db.addAuditLog({
      tenantId,
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'WORKFLOW_STEP_APPROVED',
      module: 'WORKFLOW',
      entityId: wf.id,
      details: `Approved stage [${stage.stage}] for "${wf.title}". Next stage: [${wf.currentStage}].`,
      ipAddress: req.ip,
    });

    eventBus.publish('WORKFLOW_STEP_APPROVED', 'workflow', {
      workflowId: wf.id,
      stage: stage.stage,
      nextStage: wf.currentStage,
      approverId: user.id,
    });

    res.json({
      success: true,
      message: `Stage [${stage.stage}] approved successfully.`,
      data: wf,
    });
  } catch (err) {
    next(err);
  }
});

// Reject a workflow step
workflowRouter.post('/:id/reject', authenticate, (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { id } = req.params;
    const { comments } = req.body;
    const user = req.user!;

    const wf = db.workflows.find((w) => w.id === id && w.tenantId === tenantId);
    if (!wf) {
      throw new NotFoundError('Workflow not found.');
    }

    const currentStageIndex = wf.stages.findIndex((s) => s.stage === wf.currentStage);
    if (currentStageIndex === -1) {
      throw new WorkflowTransitionError('Workflow has no active pending stage.');
    }

    const stage = wf.stages[currentStageIndex];

    if (user.role !== 'SUPER_ADMIN' && user.role !== 'PRESIDENT' && user.role !== stage.approverRole) {
      throw new ForbiddenError(
        `Forbidden: Stage [${stage.stage}] requires approver role [${stage.approverRole}], but your current role is [${user.role}].`,
        { requiredRole: stage.approverRole, currentRole: user.role }
      );
    }

    stage.decision = 'REJECTED';
    stage.comments = comments || 'Rejected';
    stage.actionDate = new Date().toISOString();
    stage.approverId = user.id;
    stage.approverName = user.name;
    wf.currentStage = 'REJECTED';
    wf.updatedAt = new Date().toISOString();

    db.addAuditLog({
      tenantId,
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'WORKFLOW_STEP_REJECTED',
      module: 'WORKFLOW',
      entityId: wf.id,
      details: `Rejected stage [${stage.stage}] for "${wf.title}". Reason: ${comments || 'None provided'}`,
      ipAddress: req.ip,
    });

    res.json({
      success: true,
      message: `Workflow rejected.`,
      data: wf,
    });
  } catch (err) {
    next(err);
  }
});
