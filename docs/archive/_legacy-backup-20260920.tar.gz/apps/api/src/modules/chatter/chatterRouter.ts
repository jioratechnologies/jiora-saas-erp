import { Router, Response } from 'express';
import { db } from '../../core/database/store.js';
import { AuthenticatedRequest, authenticate } from '../../core/middleware/auth.js';
import { ValidationError, NotFoundError } from '../../core/errors/index.js';
import { emitToRecord, emitToTenant } from '../../core/realtime/socketServer.js';

export const chatterRouter = Router();

// 1. Get chatter timeline for a record
chatterRouter.get('/:recordType/:recordId', authenticate, (req: any, res: Response) => {
  const tenantId = req.tenantId;
  const { recordType, recordId } = req.params;

  const messages = db.getChatterMessages(tenantId, recordType, recordId);
  res.json({ success: true, count: messages.length, data: messages });
});

// 2. Post a Note or Message
chatterRouter.post('/:recordType/:recordId/note', authenticate, (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { recordType, recordId } = req.params;
    const { content, messageType } = req.body;

    if (!content || !content.trim()) {
      throw new ValidationError('Message content cannot be empty.');
    }

    const msg = db.addChatterMessage({
      tenantId,
      recordType,
      recordId,
      authorId: req.user.id,
      authorName: req.user.name,
      messageType: messageType || 'NOTE',
      content: content.trim(),
    });

    // Real-time broadcast to all viewers of this record
    emitToRecord(tenantId, recordType, recordId, 'chatter:new_message', msg);

    res.status(201).json({ success: true, data: msg });
  } catch (err) {
    next(err);
  }
});

// 3. Schedule an Activity (Call, Email, Meeting, Todo)
chatterRouter.post('/:recordType/:recordId/activity', authenticate, (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { recordType, recordId } = req.params;
    const { activityType, content, dueDate } = req.body;

    if (!activityType || !content) {
      throw new ValidationError('activityType (CALL, EMAIL, MEETING, TODO) and summary content are required.');
    }

    const msg = db.addChatterMessage({
      tenantId,
      recordType,
      recordId,
      authorId: req.user.id,
      authorName: req.user.name,
      messageType: 'ACTIVITY',
      activityType,
      content,
      dueDate: dueDate || new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
      completed: false,
    });

    // Real-time broadcast to record viewers and tenant alerts
    emitToRecord(tenantId, recordType, recordId, 'chatter:new_activity', msg);
    emitToTenant(tenantId, 'notification:activity_scheduled', {
      authorName: req.user.name,
      activityType,
      dueDate: msg.dueDate,
      recordType,
    });

    res.status(201).json({ success: true, data: msg });
  } catch (err) {
    next(err);
  }
});

// 4. Toggle Activity Completion
chatterRouter.patch('/activity/:id/toggle', authenticate, (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { id } = req.params;

    const activity = db.chatterMessages.find((m) => m.id === id && m.tenantId === tenantId);
    if (!activity) {
      throw new NotFoundError('Activity not found.');
    }

    activity.completed = !activity.completed;

    // Real-time broadcast update
    emitToRecord(tenantId, activity.recordType, activity.recordId, 'chatter:update_activity', activity);

    res.json({ success: true, data: activity });
  } catch (err) {
    next(err);
  }
});
