import { Router } from 'express';
import { db, AttendanceRecord } from '../../core/database/store.js';
import { AuthenticatedRequest, authenticate } from '../../core/middleware/auth.js';
import { eventBus } from '../../core/events/eventBus.js';

export const attendanceRouter = Router();

// Get attendance logs (by user or all if manager/HR/President)
attendanceRouter.get('/', authenticate, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  let records = db.attendance;

  if (user.role === 'EMPLOYEE') {
    records = db.attendance.filter((a) => a.userId === user.id);
  }

  // Count lateness for current month
  const currentMonth = new Date().toISOString().slice(0, 7);
  const lateCountForUser = db.attendance.filter(
    (a) => a.userId === user.id && a.isLate && a.date.startsWith(currentMonth)
  ).length;

  res.json({
    success: true,
    count: records.length,
    userStats: {
      latenessThisMonth: lateCountForUser,
      halfDayDeductionTriggered: lateCountForUser >= 3,
      wfhDaysUsedThisMonth: db.attendance.filter(
        (a) => a.userId === user.id && a.isWfh && a.date.startsWith(currentMonth)
      ).length,
      wfhMaxAllowedPerMonth: 2,
    },
    data: records,
  });
});

// Check-in (Punch In)
attendanceRouter.post('/check-in', authenticate, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const today = new Date().toISOString().split('T')[0];

  // Check if already checked in today
  let record = db.attendance.find((a) => a.userId === user.id && a.date === today);
  if (record) {
    return res.status(400).json({ success: false, message: 'Already checked in for today', data: record });
  }

  const now = new Date();
  const hours = now.getHours();
  const minutes = now.getMinutes();
  const seconds = now.getSeconds();
  const timeString = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

  // Lateness check: After 10:00:00 AM
  const isLate = hours > 10 || (hours === 10 && minutes > 0);

  // Check how many times late this month
  const currentMonth = today.slice(0, 7);
  const priorLateCount = db.attendance.filter(
    (a) => a.userId === user.id && a.isLate && a.date.startsWith(currentMonth)
  ).length;

  const totalLateNow = priorLateCount + (isLate ? 1 : 0);
  const halfDayDeduction = totalLateNow >= 3;

  const newRecord: AttendanceRecord = {
    id: `att_${Date.now()}`,
    tenantId: user.tenantId || 'sachhi-saheli-delhi',
    userId: user.id,
    userName: user.name,
    date: today,
    checkInTime: timeString,
    isLate,
    isWfh: req.body.isWfh || false,
    halfDayDeduction,
    status: req.body.isWfh ? 'WFH' : (halfDayDeduction ? 'HALF_DAY' : 'PRESENT'),
    ipAddress: req.ip || '127.0.0.1',
  };

  db.attendance.unshift(newRecord);

  db.addAuditLog({
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: 'ATTENDANCE_CHECK_IN',
    module: 'ATTENDANCE',
    entityId: newRecord.id,
    details: `Digital check-in at ${timeString}. Lateness flag: ${isLate ? 'YES (>10:00 AM)' : 'NO'}. Monthly late count: ${totalLateNow}.`,
    ipAddress: req.ip,
  });

  if (isLate) {
    eventBus.publish('ATTENDANCE_LATE_FLAGGED', 'attendance', {
      userId: user.id,
      date: today,
      checkInTime: timeString,
      monthLateCount: totalLateNow,
      halfDayDeduction,
    });
  }

  res.json({
    success: true,
    message: isLate ? 'Check-in recorded. Note: Arrival after 10:00 AM is flagged as late.' : 'Check-in recorded on time.',
    data: newRecord,
  });
});

// Check-out (Punch Out)
attendanceRouter.post('/check-out', authenticate, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const today = new Date().toISOString().split('T')[0];

  const record = db.attendance.find((a) => a.userId === user.id && a.date === today);
  if (!record) {
    return res.status(404).json({ success: false, message: 'No check-in found for today' });
  }

  const now = new Date();
  const timeString = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
  record.checkOutTime = timeString;

  db.addAuditLog({
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: 'ATTENDANCE_CHECK_OUT',
    module: 'ATTENDANCE',
    entityId: record.id,
    details: `Digital check-out at ${timeString}.`,
    ipAddress: req.ip,
  });

  res.json({ success: true, message: 'Check-out recorded successfully', data: record });
});
