import { Router, Response } from 'express';
import { db } from '../../core/database/store.js';
import { AuthenticatedRequest, authenticate, requireRole } from '../../core/middleware/auth.js';
import { ValidationError, NotFoundError } from '../../core/errors/index.js';
import { OnboardingChecklist } from '../../core/types/index.js';

export const onboardingRouter = Router();

// 1. Get all onboarding instances
onboardingRouter.get('/checklists', authenticate, (req: any, res: Response) => {
  const tenantId = req.tenantId;
  const checklists = db.getOnboarding(tenantId).map((item) => {
    const user = db.users.find((u) => u.id === item.userId);
    return {
      ...item,
      employeeName: user?.name || 'Unknown Employee',
      department: user?.department || 'Unassigned',
      designation: user?.designation || 'Specialist',
      completedTasks: item.tasks.filter((t) => t.completed).length,
      totalTasks: item.tasks.length,
      progressPercent: Math.round((item.tasks.filter((t) => t.completed).length / (item.tasks.length || 1)) * 100),
    };
  });

  res.json({ success: true, count: checklists.length, data: checklists });
});

// 2. Initiate Onboarding / Induction (Standard / Intern / Contractual templates)
onboardingRouter.post('/checklists', authenticate, requireRole(['SUPER_ADMIN', 'APP_DEVELOPER', 'PRESIDENT', 'HR']), (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { userId, employeeCategory } = req.body;

    if (!userId || !employeeCategory) {
      throw new ValidationError('userId and employeeCategory (STANDARD, INTERN, CONTRACTUAL) are required.');
    }

    const tasks = [
      { id: 't_it_1', department: 'IT' as const, task: 'Google Workspace email & SSO account provisioned', completed: false },
      { id: 't_admin_1', department: 'ADMIN' as const, task: 'Biometric registration & Office access card issued', completed: false },
      { id: 't_admin_2', department: 'ADMIN' as const, task: 'Workstation laptop & accessories allocated', completed: false },
      { id: 't_hr_1', department: 'HR' as const, task: 'POSH (Sexual Harassment) policy acknowledgment signed', completed: false },
      { id: 't_hr_2', department: 'HR' as const, task: 'Statutory PF (Form 11) and Bank account details captured', completed: false },
      { id: 't_mgr_1', department: 'MANAGER' as const, task: 'First-week buddy assigned & 30-day KRA orientation planned', completed: false },
    ];

    if (employeeCategory === 'INTERN') {
      tasks.push({ id: 't_intern_1', department: 'HR' as const, task: 'Academic MOU & College NOC filed', completed: false });
    } else if (employeeCategory === 'CONTRACTUAL') {
      tasks.push({ id: 't_contract_1', department: 'HR' as const, task: 'Vendor agreement / Consultant contract execution', completed: false });
    }

    const probationEndDate = new Date();
    probationEndDate.setMonth(probationEndDate.getMonth() + 6);

    const newOnboarding: OnboardingChecklist = {
      id: `onb_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      tenantId,
      userId,
      employeeCategory,
      tasks,
      probationEndDate: probationEndDate.toISOString().split('T')[0],
      probationStatus: 'IN_PROBATION',
      confirmationLetterIssued: false,
      createdAt: new Date().toISOString(),
    };

    db.onboarding.unshift(newOnboarding);

    db.addAuditLog({
      tenantId,
      userId: req.user.id,
      userName: req.user.name,
      userRole: req.user.role,
      action: 'ONBOARDING_INITIATED',
      module: 'ONBOARDING',
      details: `Initiated ${employeeCategory} induction checklist for employee ID ${userId}`,
    });

    res.status(201).json({ success: true, data: newOnboarding });
  } catch (err) {
    next(err);
  }
});

// 3. Mark Department Task as Completed
onboardingRouter.patch('/checklists/:id/task/:taskId', authenticate, requireRole(['SUPER_ADMIN', 'APP_DEVELOPER', 'PRESIDENT', 'HR', 'MANAGER']), (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { id, taskId } = req.params;
    const { completed } = req.body;

    const record = db.onboarding.find((o) => o.id === id && o.tenantId === tenantId);
    if (!record) {
      throw new NotFoundError('Onboarding record not found.');
    }

    const task = record.tasks.find((t) => t.id === taskId);
    if (!task) {
      throw new NotFoundError(`Task '${taskId}' not found on checklist.`);
    }

    task.completed = completed !== undefined ? completed : true;

    db.addChatterMessage({
      tenantId,
      recordType: 'onboarding',
      recordId: record.id,
      authorId: req.user.id,
      authorName: req.user.name,
      messageType: 'NOTE',
      content: `Task "${task.task}" [${task.department}] marked as ${task.completed ? 'COMPLETED' : 'PENDING'}.`,
    });

    res.json({ success: true, data: record });
  } catch (err) {
    next(err);
  }
});

// 4. Confirm Probation (President Sign-off)
onboardingRouter.post('/checklists/:id/confirm-probation', authenticate, requireRole(['SUPER_ADMIN', 'APP_DEVELOPER', 'PRESIDENT']), (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { id } = req.params;

    const record = db.onboarding.find((o) => o.id === id && o.tenantId === tenantId);
    if (!record) {
      throw new NotFoundError('Onboarding record not found.');
    }

    record.probationStatus = 'CONFIRMED';
    record.confirmationLetterIssued = true;

    // Update employee profile status
    const profile = db.profiles.find((p) => p.userId === record.userId && p.tenantId === tenantId);
    if (profile) {
      profile.jobDetails.probationStatus = 'CONFIRMED';
    }

    const user = db.users.find((u) => u.id === record.userId && u.tenantId === tenantId);
    if (user) {
      user.status = 'ACTIVE';
    }

    db.addAuditLog({
      tenantId,
      userId: req.user.id,
      userName: req.user.name,
      userRole: req.user.role,
      action: 'PROBATION_CONFIRMED',
      module: 'HRIS',
      details: `Dr. Surbhi Singh issued confirmation order for employee ${user?.name || record.userId}.`,
    });

    res.json({
      success: true,
      message: 'Probation confirmed and President confirmation letter issued.',
      data: record,
    });
  } catch (err) {
    next(err);
  }
});
