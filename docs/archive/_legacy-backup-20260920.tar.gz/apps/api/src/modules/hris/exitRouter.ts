import { Router } from 'express';
import { db } from '../../core/database/store.js';
import { AuthenticatedRequest, authenticate } from '../../core/middleware/auth.js';
import { eventBus } from '../../core/events/eventBus.js';

export const exitRouter = Router();

// Get exit records
exitRouter.get('/', authenticate, (req: AuthenticatedRequest, res) => {
  res.json({ success: true, count: db.exitRecords.length, data: db.exitRecords });
});

// Update a step in the 16-step clearance checklist
exitRouter.post('/:exitId/checklist/:stepNumber', authenticate, (req: AuthenticatedRequest, res) => {
  const { exitId, stepNumber } = req.params;
  const { completed } = req.body;
  const user = req.user!;

  const record = db.exitRecords.find((e) => e.id === exitId);
  if (!record) {
    return res.status(404).json({ success: false, message: 'Exit record not found' });
  }

  const step = record.checklist16Steps.find((s) => s.stepNumber === parseInt(stepNumber, 10));
  if (!step) {
    return res.status(404).json({ success: false, message: 'Step number not found in checklist' });
  }

  step.completed = completed !== undefined ? completed : true;
  step.completedAt = new Date().toISOString();

  // Check if all steps completed
  const allCompleted = record.checklist16Steps.every((s) => s.completed);
  if (allCompleted) {
    record.status = 'COMPLETED';
    if (record.fnfDetails) {
      record.fnfDetails.relievingLetterIssued = true;
    }
  }

  db.addAuditLog({
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: 'EXIT_CHECKLIST_STEP_UPDATED',
    module: 'EXIT',
    entityId: exitId,
    details: `Updated Step ${stepNumber} (${step.department}: ${step.task}) to [${step.completed ? 'COMPLETED' : 'PENDING'}].`,
    ipAddress: req.ip,
  });

  eventBus.publish('EXIT_STEP_UPDATED', 'exit', {
    exitId,
    stepNumber: parseInt(stepNumber, 10),
    department: step.department,
    completed: step.completed,
  });

  res.json({ success: true, message: 'Exit checklist step updated', data: record });
});
