import { Router, Response } from 'express';
import { db } from '../../core/database/store.js';
import { AuthenticatedRequest, authenticate } from '../../core/middleware/auth.js';
import { eventBus } from '../../core/events/eventBus.js';
import { WorkflowInstance, WorkflowStatus } from '../../core/types/index.js';
import { ValidationError, NotFoundError, StatutoryComplianceError } from '../../core/errors/index.js';

export const leaveRouter = Router();

// Get leave balances for current user or specified user
leaveRouter.get('/balances', authenticate, (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const user = req.user!;
    const targetUserId = (req.query.userId as string) || user.id;

    const balance = db.getLeaveBalance(tenantId, targetUserId);
    if (!balance) {
      throw new NotFoundError('Leave balance not found.');
    }

    res.json({ success: true, data: balance });
  } catch (err) {
    next(err);
  }
});

// Apply for leave
leaveRouter.post('/apply', authenticate, (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const user = req.user!;
    const { leaveType, startDate, endDate, days, reason, documentUrl } = req.body;

    if (!leaveType || !startDate || !endDate || !days) {
      throw new ValidationError('Missing required leave fields: leaveType, startDate, endDate, and days are mandatory.');
    }

    const balances = db.getLeaveBalance(tenantId, user.id);
    if (!balances) {
      throw new NotFoundError('Employee leave profile not found.');
    }

    // Check validation rules per BRD
    const isSpecialLeave = ['MATERNITY_LEAVE', 'PATERNITY_LEAVE', 'ADOPTION_LEAVE'].includes(leaveType);

    if (leaveType === 'EARNED_LEAVE') {
      // Check 6-month service rule
      const joinDate = new Date(user.joiningDate);
      const monthsSinceJoin = (Date.now() - joinDate.getTime()) / (1000 * 60 * 60 * 24 * 30.4);
      if (monthsSinceJoin < 6) {
        throw new StatutoryComplianceError('Statutory Rule: Earned Leave (EL) can only be availed after 6 months of continuous service.');
      }

      // Check 15 days advance notice
      const start = new Date(startDate);
      const daysInAdvance = (start.getTime() - Date.now()) / (1000 * 60 * 60 * 24);
      if (daysInAdvance < 14) {
        throw new ValidationError('Policy Requirement: Earned Leave requires at least 15 days advance notice.');
      }
    }

    // Determine workflow chain
    let stages: any[] = [];
    let initialStage: WorkflowStatus = 'PENDING_MANAGER';

    if (isSpecialLeave) {
      stages = [
        { stage: 'PENDING_MANAGER', approverRole: 'MANAGER' },
        { stage: 'PENDING_HR', approverRole: 'HR' },
        { stage: 'PENDING_PRESIDENT', approverRole: 'PRESIDENT' },
      ];
    } else {
      stages = [{ stage: 'PENDING_MANAGER', approverRole: 'MANAGER' }];
    }

    const workflowId = `wf_leave_${Date.now()}`;
    const workflow: WorkflowInstance = {
      id: workflowId,
      tenantId,
      workflowType: isSpecialLeave ? 'LEAVE_SPECIAL' : 'LEAVE_STANDARD',
      title: `${leaveType.replace('_', ' ')} Application (${days} Days)`,
      requesterId: user.id,
      requesterName: user.name,
      requesterRole: user.role,
      department: user.department,
      currentStage: initialStage,
      stages,
      payload: {
        leaveType,
        startDate,
        endDate,
        days: Number(days),
        reason,
        documentUrl,
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    db.workflows.unshift(workflow);

    db.addAuditLog({
      tenantId,
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'LEAVE_APPLIED',
      module: 'LEAVE',
      entityId: workflow.id,
      details: `Applied for ${days} days of ${leaveType}. Workflow instance created.`,
      ipAddress: req.ip,
    });

    eventBus.publish('LEAVE_REQUESTED', 'leave', {
      workflowId: workflow.id,
      userId: user.id,
      leaveType,
      days,
    });

    res.status(201).json({
      success: true,
      message: 'Leave application submitted successfully.',
      data: workflow,
    });
  } catch (err) {
    next(err);
  }
});
