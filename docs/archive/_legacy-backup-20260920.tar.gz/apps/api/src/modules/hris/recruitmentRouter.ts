import { Router, Response } from 'express';
import { db } from '../../core/database/store.js';
import { AuthenticatedRequest, authenticate, requireRole } from '../../core/middleware/auth.js';
import { ValidationError, NotFoundError, StatutoryComplianceError } from '../../core/errors/index.js';
import { Candidate, RecruitmentRequisition } from '../../core/types/index.js';

export const recruitmentRouter = Router();

// 1. Get all requisitions for tenant
recruitmentRouter.get('/requisitions', authenticate, (req: any, res: Response) => {
  const tenantId = req.tenantId;
  const requisitions = db.getRequisitions(tenantId);
  res.json({ success: true, count: requisitions.length, data: requisitions });
});

// 2. Create a new job requisition (Function Head or HR)
recruitmentRouter.post('/requisitions', authenticate, requireRole(['SUPER_ADMIN', 'APP_DEVELOPER', 'PRESIDENT', 'HR', 'MANAGER']), (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { jobTitle, department, openPositions, budgetBandAnnual, experienceRequired, justification } = req.body;

    if (!jobTitle || !department) {
      throw new ValidationError('Job title and department are mandatory for requisition.');
    }

    const newReq: RecruitmentRequisition = {
      id: `req_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      tenantId,
      jobTitle,
      department,
      openPositions: Number(openPositions) || 1,
      budgetBandAnnual: budgetBandAnnual || '₹ 6,00,000 - ₹ 8,00,000',
      experienceRequired: experienceRequired || '2-4 Years',
      justification: justification || 'New role creation.',
      status: req.user.role === 'PRESIDENT' ? 'APPROVED' : 'PENDING_APPROVAL',
      requestedBy: req.user.id,
      createdAt: new Date().toISOString(),
    };

    db.requisitions.unshift(newReq);

    // Also trigger workflow instance #1 (Recruitment Requisition)
    db.workflows.unshift({
      id: `wf_req_${newReq.id}`,
      tenantId,
      workflowType: 'RECRUITMENT_REQUISITION',
      title: `Requisition: ${jobTitle} (${department})`,
      requesterId: req.user.id,
      requesterName: req.user.name,
      requesterRole: req.user.role,
      department,
      currentStage: req.user.role === 'PRESIDENT' ? 'APPROVED' : 'PENDING_PRESIDENT',
      stages: [
        {
          stage: 'PENDING_PRESIDENT',
          approverRole: 'PRESIDENT',
          decision: req.user.role === 'PRESIDENT' ? 'APPROVED' : undefined,
          actionDate: req.user.role === 'PRESIDENT' ? new Date().toISOString() : undefined,
        },
      ],
      payload: newReq,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    db.addAuditLog({
      tenantId,
      userId: req.user.id,
      userName: req.user.name,
      userRole: req.user.role,
      action: 'RECRUITMENT_REQUISITION_CREATED',
      module: 'RECRUITMENT',
      details: `Created requisition '${jobTitle}' for department '${department}'`,
    });

    res.status(201).json({ success: true, data: newReq });
  } catch (err) {
    next(err);
  }
});

// 3. Get candidates (grouped for Kanban)
recruitmentRouter.get('/candidates', authenticate, (req: any, res: Response) => {
  const tenantId = req.tenantId;
  const candidates = db.getCandidates(tenantId);
  const stages = ['SOURCED', 'SCREENING', 'INTERVIEW', 'REFERENCE_CHECK', 'OFFER_SENT', 'HIRED'];

  const kanban = stages.map((stg) => ({
    stage: stg,
    count: candidates.filter((c) => c.stage === stg).length,
    candidates: candidates.filter((c) => c.stage === stg),
  }));

  res.json({
    success: true,
    total: candidates.length,
    kanban,
    data: candidates,
  });
});

// 4. Create / Add Candidate
recruitmentRouter.post('/candidates', authenticate, requireRole(['SUPER_ADMIN', 'APP_DEVELOPER', 'PRESIDENT', 'HR', 'MANAGER']), (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { name, email, phone, appliedRole, requisitionId } = req.body;

    if (!name || !email || !appliedRole) {
      throw new ValidationError('Name, email, and applied role are mandatory.');
    }

    const newCandidate: Candidate = {
      id: `cand_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      tenantId,
      requisitionId,
      name,
      email,
      phone,
      appliedRole,
      stage: 'SOURCED',
      referenceChecks: [],
      createdAt: new Date().toISOString(),
    };

    db.candidates.unshift(newCandidate);

    db.addChatterMessage({
      tenantId,
      recordType: 'candidate',
      recordId: newCandidate.id,
      authorId: req.user.id,
      authorName: req.user.name,
      messageType: 'NOTE',
      content: `Candidate ${name} sourced for role '${appliedRole}'.`,
    });

    res.status(201).json({ success: true, data: newCandidate });
  } catch (err) {
    next(err);
  }
});

// 5. Update Candidate Stage (Kanban drag/click transition)
recruitmentRouter.patch('/candidates/:id/stage', authenticate, requireRole(['SUPER_ADMIN', 'APP_DEVELOPER', 'PRESIDENT', 'HR', 'MANAGER']), (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { id } = req.params;
    const { stage, feedback, score } = req.body;

    const candidate = db.candidates.find((c) => c.id === id && c.tenantId === tenantId);
    if (!candidate) {
      throw new NotFoundError('Candidate not found.');
    }

    // STRICT BRD RULE: Minimum of 2 verified reference checks required before OFFER_SENT stage!
    if (stage === 'OFFER_SENT' || stage === 'HIRED') {
      const verifiedCount = candidate.referenceChecks.filter((rc) => rc.verified).length;
      if (verifiedCount < 2) {
        throw new StatutoryComplianceError(
          `BRD Rule Violation: A minimum of 2 verified reference checks are mandatory before issuing an offer. Currently verified: ${verifiedCount}/2.`,
          { currentVerified: verifiedCount, required: 2 }
        );
      }
    }

    const prevStage = candidate.stage;
    candidate.stage = stage;
    if (feedback) candidate.interviewFeedback = feedback;
    if (score !== undefined) candidate.interviewScore = score;

    db.addChatterMessage({
      tenantId,
      recordType: 'candidate',
      recordId: candidate.id,
      authorId: req.user.id,
      authorName: req.user.name,
      messageType: 'NOTE',
      content: `Candidate stage moved from [${prevStage}] to [${stage}].`,
    });

    res.json({ success: true, data: candidate });
  } catch (err) {
    next(err);
  }
});

// 6. Complete a Reference Check (Recording referee details and verification)
recruitmentRouter.post('/candidates/:id/reference-check', authenticate, requireRole(['SUPER_ADMIN', 'APP_DEVELOPER', 'PRESIDENT', 'HR']), (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { id } = req.params;
    const { referee, designation, feedback } = req.body;

    if (!referee || !feedback) {
      throw new ValidationError('Referee name and feedback are required.');
    }

    const candidate = db.candidates.find((c) => c.id === id && c.tenantId === tenantId);
    if (!candidate) {
      throw new NotFoundError('Candidate not found.');
    }

    const refCheck = {
      referee,
      designation: designation || 'Professional Reference',
      feedback,
      verified: true,
      verifiedDate: new Date().toISOString().split('T')[0],
    };

    candidate.referenceChecks.push(refCheck);

    db.addChatterMessage({
      tenantId,
      recordType: 'candidate',
      recordId: candidate.id,
      authorId: req.user.id,
      authorName: req.user.name,
      messageType: 'NOTE',
      content: `Completed reference check #${candidate.referenceChecks.length} with ${referee} (${designation}): "${feedback}"`,
    });

    res.json({
      success: true,
      message: `Reference check verified (${candidate.referenceChecks.length}/2 completed).`,
      data: candidate,
    });
  } catch (err) {
    next(err);
  }
});

// 7. Issue President-Signed Offer Letter
recruitmentRouter.post('/candidates/:id/generate-offer', authenticate, requireRole(['SUPER_ADMIN', 'APP_DEVELOPER', 'PRESIDENT', 'HR']), (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { id } = req.params;
    const { offeredCtc, joiningDate } = req.body;

    const candidate = db.candidates.find((c) => c.id === id && c.tenantId === tenantId);
    if (!candidate) {
      throw new NotFoundError('Candidate not found.');
    }

    if (candidate.referenceChecks.filter((r) => r.verified).length < 2) {
      throw new StatutoryComplianceError('Cannot issue offer letter: 2 verified reference checks required.');
    }

    candidate.offerDetails = {
      offeredCtc: Number(offeredCtc) || 750000,
      joiningDate: joiningDate || '2026-10-15',
      status: 'PENDING_ACCEPTANCE',
      signedBy: 'Dr. Surbhi Singh (President)',
    };
    candidate.stage = 'OFFER_SENT';

    db.addAuditLog({
      tenantId,
      userId: req.user.id,
      userName: req.user.name,
      userRole: req.user.role,
      action: 'RECRUITMENT_OFFER_ISSUED',
      module: 'RECRUITMENT',
      details: `Issued digital appointment offer to ${candidate.name} for ₹${candidate.offerDetails.offeredCtc} CTC.`,
    });

    res.json({
      success: true,
      message: 'Offer letter prepared and dispatched with secure acceptance link.',
      data: candidate,
    });
  } catch (err) {
    next(err);
  }
});
