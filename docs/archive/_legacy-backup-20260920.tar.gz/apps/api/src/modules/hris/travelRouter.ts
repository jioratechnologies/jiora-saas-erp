import { Router, Response } from 'express';
import { db } from '../../core/database/store.js';
import { AuthenticatedRequest, authenticate, requireRole } from '../../core/middleware/auth.js';
import { ValidationError, NotFoundError, StatutoryComplianceError } from '../../core/errors/index.js';
import { TravelTour, ExpenseClaim } from '../../core/types/index.js';

export const travelRouter = Router();

// City Tier statutory per-diem allowances as defined in BRD v2
const PER_DIEM_LIMITS: Record<string, number> = {
  'Tier-1': 2500, // Delhi, Mumbai, Bengaluru
  'Tier-2': 1800, // Lucknow, Varanasi, Jaipur
  'Tier-3': 1200, // Small districts and rural zones
};

// 1. Get all tours
travelRouter.get('/tours', authenticate, (req: any, res: Response) => {
  const tenantId = req.tenantId;
  const tours = db.getTravelTours(tenantId).map((t) => {
    const user = db.users.find((u) => u.id === t.userId);
    return {
      ...t,
      employeeName: user?.name || 'Unknown Traveler',
      department: user?.department || 'Unassigned',
      perDiemLimit: PER_DIEM_LIMITS[t.cityTier] || 1800,
    };
  });

  res.json({ success: true, count: tours.length, data: tours });
});

// 2. Request Tour Approval
travelRouter.post('/tours', authenticate, (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { destination, departureDate, returnDate, purpose, cityTier, advanceRequested } = req.body;

    if (!destination || !departureDate || !returnDate || !purpose) {
      throw new ValidationError('Destination, departure date, return date, and purpose are mandatory.');
    }

    const newTour: TravelTour = {
      id: `tour_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      tenantId,
      userId: req.user.id,
      destination,
      departureDate,
      returnDate,
      purpose,
      cityTier: cityTier || 'Tier-2',
      advanceRequested: Number(advanceRequested) || 0,
      advanceDisbursed: false,
      status: 'PENDING_APPROVAL',
      createdAt: new Date().toISOString(),
    };

    db.travelTours.unshift(newTour);

    // Create workflow instance #10 (Tour / Travel Approval)
    db.workflows.unshift({
      id: `wf_tour_${newTour.id}`,
      tenantId,
      workflowType: 'TRAVEL_TOUR_APPROVAL',
      title: `Tour Request: ${destination} (${cityTier})`,
      requesterId: req.user.id,
      requesterName: req.user.name,
      requesterRole: req.user.role,
      department: req.user.department,
      currentStage: 'PENDING_MANAGER',
      stages: [
        { stage: 'PENDING_MANAGER', approverRole: 'MANAGER' },
        { stage: 'PENDING_PRESIDENT', approverRole: 'PRESIDENT' },
      ],
      payload: newTour,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    res.status(201).json({ success: true, data: newTour });
  } catch (err) {
    next(err);
  }
});

// 3. Get Expense Claims
travelRouter.get('/claims', authenticate, (req: any, res: Response) => {
  const tenantId = req.tenantId;
  const claims = db.getExpenseClaims(tenantId).map((c) => {
    const user = db.users.find((u) => u.id === c.userId);
    return {
      ...c,
      employeeName: user?.name || 'Unknown Employee',
      department: user?.department || 'Unassigned',
    };
  });

  res.json({ success: true, count: claims.length, data: claims });
});

// 4. Submit Expense Claim (with per-diem validation)
travelRouter.post('/claims', authenticate, (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { claimType, items, cityTier } = req.body;

    if (!Array.isArray(items) || items.length === 0) {
      throw new ValidationError('Expense claim must include at least one itemized entry.');
    }

    const totalAmount = items.reduce((sum: number, item: any) => sum + (Number(item.amount) || 0), 0);

    const newClaim: ExpenseClaim = {
      id: `exp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      tenantId,
      userId: req.user.id,
      claimType: claimType || 'TOUR_TRAVEL',
      items,
      totalAmount,
      cityTier: cityTier || 'Tier-2',
      status: 'PENDING_APPROVAL',
      createdAt: new Date().toISOString(),
    };

    db.expenseClaims.unshift(newClaim);

    // Create workflow instance #11 (Travel Expense Claim)
    db.workflows.unshift({
      id: `wf_claim_${newClaim.id}`,
      tenantId,
      workflowType: 'TRAVEL_EXPENSE_CLAIM',
      title: `Expense Claim: ₹${totalAmount} (${claimType})`,
      requesterId: req.user.id,
      requesterName: req.user.name,
      requesterRole: req.user.role,
      department: req.user.department,
      currentStage: 'PENDING_MANAGER',
      stages: [
        { stage: 'PENDING_MANAGER', approverRole: 'MANAGER' },
        { stage: 'PENDING_FINANCE', approverRole: 'FINANCE' },
      ],
      payload: newClaim,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    res.status(201).json({ success: true, data: newClaim });
  } catch (err) {
    next(err);
  }
});

// 5. Emergency Salary Advance (Capped at 3 months gross or ₹1,00,000, 12-month EMI schedule)
travelRouter.post('/emergency-advance', authenticate, (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { amount, tenureMonths, purpose } = req.body;
    const requestedAmount = Number(amount);
    const months = Math.min(Math.max(Number(tenureMonths) || 12, 1), 12); // max 12 months

    const profile = db.profiles.find((p) => p.userId === req.user.id && p.tenantId === tenantId);
    const grossMonthly = (profile?.salaryStructure?.basicMonthly || 30000) * 2;
    const maxLimit = Math.min(grossMonthly * 3, 100000);

    if (requestedAmount > maxLimit) {
      throw new StatutoryComplianceError(
        `Statutory Cap Exceeded: Emergency Salary Advance cannot exceed ₹${maxLimit.toLocaleString('en-IN')} (lesser of 3 months gross or ₹1,00,000).`,
        { maxLimit, requestedAmount }
      );
    }

    const monthlyEmi = Math.round(requestedAmount / months);

    const advancePayload = {
      requestedAmount,
      tenureMonths: months,
      monthlyEMI: monthlyEmi,
      purpose: purpose || 'Medical / Family emergency',
      status: 'PENDING_APPROVAL',
    };

    // Create workflow #16 (Emergency Salary Advance)
    const wf = {
      id: `wf_adv_${Date.now()}`,
      tenantId,
      workflowType: 'EMERGENCY_SALARY_ADVANCE',
      title: `Emergency Salary Advance: ₹${requestedAmount.toLocaleString('en-IN')} (${months}-month EMI)`,
      requesterId: req.user.id,
      requesterName: req.user.name,
      requesterRole: req.user.role,
      department: req.user.department,
      currentStage: 'PENDING_FINANCE' as const,
      stages: [
        { stage: 'PENDING_MANAGER' as const, approverRole: 'MANAGER' as const, decision: 'APPROVED' as const, actionDate: new Date().toISOString() },
        { stage: 'PENDING_FINANCE' as const, approverRole: 'FINANCE' as const },
        { stage: 'PENDING_PRESIDENT' as const, approverRole: 'PRESIDENT' as const },
      ],
      payload: advancePayload,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    db.workflows.unshift(wf);

    res.status(201).json({
      success: true,
      message: `Emergency Advance application submitted. Monthly EMI: ₹${monthlyEmi} across ${months} months.`,
      data: advancePayload,
      workflow: wf,
    });
  } catch (err) {
    next(err);
  }
});
