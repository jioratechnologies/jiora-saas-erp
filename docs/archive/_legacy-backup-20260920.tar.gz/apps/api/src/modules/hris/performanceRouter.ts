import { Router, Response } from 'express';
import { db } from '../../core/database/store.js';
import { AuthenticatedRequest, authenticate, requireRole } from '../../core/middleware/auth.js';
import { ValidationError, NotFoundError } from '../../core/errors/index.js';
import { Appraisal } from '../../core/types/index.js';

export const performanceRouter = Router();

// 1. Get all appraisal cycles for tenant
performanceRouter.get('/appraisals', authenticate, (req: any, res: Response) => {
  const tenantId = req.tenantId;
  const appraisals = db.getAppraisals(tenantId).map((item) => {
    const user = db.users.find((u) => u.id === item.userId);
    return {
      ...item,
      employeeName: user?.name || 'Unknown Employee',
      department: user?.department || 'Unassigned',
      designation: user?.designation || 'Specialist',
    };
  });

  // Calculate bell curve calibration distribution
  const ratings = appraisals.map((a) => a.presidentCalibratedRating || a.managerRating || a.selfRating || 3);
  const bellCurve = {
    topPerformersGradeA: ratings.filter((r) => r === 5).length,
    solidContributorsGradeB: ratings.filter((r) => r === 4).length,
    meetingExpectationsGradeC: ratings.filter((r) => r === 3).length,
    needsImprovementGradeD: ratings.filter((r) => r <= 2).length,
  };

  res.json({
    success: true,
    count: appraisals.length,
    bellCurveDistribution: bellCurve,
    data: appraisals,
  });
});

// 2. Assign SMART KRAs
performanceRouter.post('/appraisals', authenticate, requireRole(['SUPER_ADMIN', 'APP_DEVELOPER', 'PRESIDENT', 'HR', 'MANAGER']), (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { userId, cycleYear, kras } = req.body;

    if (!userId || !cycleYear || !Array.isArray(kras) || kras.length === 0) {
      throw new ValidationError('userId, cycleYear, and non-empty kras array are required.');
    }

    const newAppraisal: Appraisal = {
      id: `appr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      tenantId,
      userId,
      cycleYear,
      kras,
      status: 'SELF_REVIEW',
      createdAt: new Date().toISOString(),
    };

    db.appraisals.unshift(newAppraisal);

    res.status(201).json({ success: true, data: newAppraisal });
  } catch (err) {
    next(err);
  }
});

// 3. Employee Self-Review
performanceRouter.post('/appraisals/:id/self-review', authenticate, (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { id } = req.params;
    const { rating, comments } = req.body;

    const appraisal = db.appraisals.find((a) => a.id === id && a.tenantId === tenantId);
    if (!appraisal) {
      throw new NotFoundError('Appraisal record not found.');
    }

    appraisal.selfRating = Number(rating);
    appraisal.selfComments = comments || '';
    appraisal.status = 'MANAGER_REVIEW';

    db.addChatterMessage({
      tenantId,
      recordType: 'appraisal',
      recordId: appraisal.id,
      authorId: req.user.id,
      authorName: req.user.name,
      messageType: 'NOTE',
      content: `Submitted self-review rating (${rating}/5): "${comments}"`,
    });

    res.json({ success: true, data: appraisal });
  } catch (err) {
    next(err);
  }
});

// 4. Reporting Manager Review
performanceRouter.post('/appraisals/:id/manager-review', authenticate, requireRole(['SUPER_ADMIN', 'APP_DEVELOPER', 'PRESIDENT', 'MANAGER', 'HR']), (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { id } = req.params;
    const { rating, comments } = req.body;

    const appraisal = db.appraisals.find((a) => a.id === id && a.tenantId === tenantId);
    if (!appraisal) {
      throw new NotFoundError('Appraisal record not found.');
    }

    appraisal.managerRating = Number(rating);
    appraisal.managerComments = comments || '';
    appraisal.status = 'PRESIDENT_CALIBRATED';

    db.addChatterMessage({
      tenantId,
      recordType: 'appraisal',
      recordId: appraisal.id,
      authorId: req.user.id,
      authorName: req.user.name,
      messageType: 'NOTE',
      content: `Manager evaluated rating (${rating}/5): "${comments}"`,
    });

    res.json({ success: true, data: appraisal });
  } catch (err) {
    next(err);
  }
});

// 5. President Bell-Curve Calibration & Outcome
performanceRouter.post('/appraisals/:id/president-calibration', authenticate, requireRole(['SUPER_ADMIN', 'APP_DEVELOPER', 'PRESIDENT']), (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { id } = req.params;
    const { rating, comments } = req.body;

    const appraisal = db.appraisals.find((a) => a.id === id && a.tenantId === tenantId);
    if (!appraisal) {
      throw new NotFoundError('Appraisal record not found.');
    }

    appraisal.presidentCalibratedRating = Number(rating);
    appraisal.presidentComments = comments || '';
    appraisal.status = 'FINALIZED';

    db.addAuditLog({
      tenantId,
      userId: req.user.id,
      userName: req.user.name,
      userRole: req.user.role,
      action: 'APPRAISAL_PRESIDENT_CALIBRATED',
      module: 'HRIS',
      details: `President calibrated appraisal ${appraisal.id} with final score ${rating}/5.`,
    });

    res.json({
      success: true,
      message: 'Appraisal calibrated and promotion/increment order finalized.',
      data: appraisal,
    });
  } catch (err) {
    next(err);
  }
});
