import { Router } from 'express';
import { db, EmployeeProfile } from '../../core/database/store.js';
import { AuthenticatedRequest, authenticate } from '../../core/middleware/auth.js';

export const employeesRouter = Router();

// Get list of all employees
employeesRouter.get('/', authenticate, (req: AuthenticatedRequest, res) => {
  const employees = db.users.map((u) => {
    let profile = db.profiles.find((p) => p.userId === u.id);
    const defaultBasic =
      u.role === 'PRESIDENT'
        ? 95000
        : u.role === 'HR' || u.role === 'FINANCE'
        ? 55000
        : u.role === 'MANAGER'
        ? 45000
        : 30000;

    if (!profile) {
      profile = {
        id: `prof_${u.id}`,
        tenantId: u.tenantId || 'sachhi-saheli-delhi',
        userId: u.id,
        personalInfo: {
          dob: '1990-01-01',
          gender: 'FEMALE',
          phone: '+91 98765 00000',
          address: 'New Delhi, India',
          emergencyContact: 'Family Contact - +91 98765 11111',
          bloodGroup: 'B+',
        },
        jobDetails: {
          title: u.designation,
          department: u.department,
          grade: u.role === 'PRESIDENT' ? 'EXEC' : 'L2',
          joiningDate: u.joiningDate,
          probationEnd: '2023-01-01',
          probationStatus: u.status === 'PROBATION' ? 'IN_PROBATION' : 'CONFIRMED',
          employmentType: 'PERMANENT',
          reportingManager: 'Dr. Surbhi Singh',
        },
        salaryStructure: {
          ctcAnnual: defaultBasic * 24,
          basicMonthly: defaultBasic,
          hraMonthly: Math.round(defaultBasic * 0.5),
          specialAllowanceMonthly: Math.round(defaultBasic * 0.5),
          pfDeductionMonthly: Math.round(defaultBasic * 0.12),
          gratuityEligible: false,
          medicalInsuranceCover: 300000,
          accidentInsuranceCover: 500000,
        },
        statutoryInfo: {
          pan: 'ABCDE1234F',
          aadhaarMasked: 'XXXX-XXXX-9900',
          uan: '101298347999',
          pfNumber: `DL/CPM/10293/${u.employeeId}`,
          bankAccountNumber: '918237461999',
          ifscCode: 'HDFC0001234',
          bankName: 'HDFC Bank Ltd, New Delhi',
        },
        documentsVerified: true,
        documentChecklist: {
          degreeCertificate: true,
          clearanceLetterPrevEmployer: true,
          prevPayslips: true,
          photoId: true,
          dobProof: true,
          addressProof: true,
          photographs: true,
        },
      };
      db.profiles.push(profile);
    }

    const basicSalary = profile?.salaryStructure?.basicMonthly || defaultBasic;

    return {
      ...u,
      basicSalary,
      profile,
    };
  });

  res.json({ success: true, count: employees.length, data: employees });
});

// Get single employee by ID
employeesRouter.get('/:id', authenticate, (req: AuthenticatedRequest, res) => {
  const { id } = req.params;
  const user = db.users.find((u) => u.id === id);
  if (!user) {
    return res.status(404).json({ success: false, message: 'Employee not found' });
  }

  const profile = db.profiles.find((p) => p.userId === id);
  const leaveBalance = db.leaveBalances.get(id);

  res.json({
    success: true,
    data: {
      ...user,
      basicSalary: profile?.salaryStructure?.basicMonthly ?? 30000,
      profile,
      leaveBalance,
    },
  });
});
