import { Router } from 'express';
import { db } from '../../core/database/store.js';
import { AuthenticatedRequest, authenticate } from '../../core/middleware/auth.js';

export const complianceRouter = Router();

// Get live audit trail logs
complianceRouter.get('/audit-logs', authenticate, (req: AuthenticatedRequest, res) => {
  res.json({
    success: true,
    count: db.auditLogs.length,
    retentionNotice: 'Compliance: All audit records retained for 6+ years per statutory mandate.',
    data: db.auditLogs,
  });
});

// Statutory calculation helpers
complianceRouter.post('/calculate-gratuity', (req, res) => {
  const { basicSalary, tenureYears } = req.body;
  if (!basicSalary || tenureYears === undefined) {
    return res.status(400).json({ success: false, message: 'basicSalary and tenureYears required' });
  }

  const eligible = tenureYears >= 5.0;
  // Payment of Gratuity Act, 1972: (15 * Last Drawn Basic * Tenure in Years) / 26
  const gratuityAmount = eligible
    ? Math.round((15 * Number(basicSalary) * Math.round(Number(tenureYears))) / 26)
    : 0;

  res.json({
    success: true,
    act: 'Payment of Gratuity Act, 1972',
    tenureYears: Number(tenureYears),
    isEligible: eligible,
    eligible,
    condition: 'Minimum 5 continuous years of full-time service required',
    gratuityAmount,
    gratuityPayable: gratuityAmount,
    formula: '(15 * Last Drawn Basic Salary * Tenure in Completed Years) / 26',
  });
});

complianceRouter.post('/calculate-pf', (req, res) => {
  const { basicPlusDA } = req.body;
  const basic = Number(basicPlusDA) || 0;

  const employeePF = Math.round(basic * 0.12);
  const employerPF = Math.round(basic * 0.12);
  const eps = Math.min(Math.round(basic * 0.0833), 1250); // EPS capped at statutory ceiling
  const epfEmployer = employerPF - eps;

  res.json({
    success: true,
    act: 'Employees Provident Funds and Miscellaneous Provisions Act, 1952',
    basicSalary: basic,
    employeePF,
    employerTotal: employerPF,
    employeeContribution: { percentage: '12%', amount: employeePF },
    employerContribution: {
      percentage: '12%',
      totalAmount: employerPF,
      breakdown: {
        epsPensionFund: eps,
        epfProvidentFund: epfEmployer,
      },
    },
    totalMonthlyPFDeposit: employeePF + employerPF,
  });
});
