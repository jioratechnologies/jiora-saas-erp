import { Router, Response } from 'express';
import { db } from '../../core/database/store.js';
import { AuthenticatedRequest, authenticate, requireRole } from '../../core/middleware/auth.js';
import { NotFoundError } from '../../core/errors/index.js';

export const tenantRouter = Router();

// Get active tenant's branding and settings
tenantRouter.get('/branding', authenticate, (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const tenant = db.getTenant(tenantId);
    if (!tenant) {
      throw new NotFoundError(`Tenant '${tenantId}' not found.`);
    }

    res.json({
      success: true,
      data: tenant,
    });
  } catch (err) {
    next(err);
  }
});

// List all tenants (for tenant switcher & Super Admin)
tenantRouter.get('/all', authenticate, (req: any, res: Response) => {
  res.json({
    success: true,
    count: db.tenants.length,
    data: db.tenants,
  });
});

// Update tenant branding (Whitelabel customizer - Super Admin, App Dev, or President)
tenantRouter.patch('/branding', authenticate, requireRole(['SUPER_ADMIN', 'APP_DEVELOPER', 'PRESIDENT']), (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { name, logoUrl, faviconUrl, primaryColor, accentColor, legalEntityType, currency, tagline } = req.body;

    const updated = db.updateTenantBranding(tenantId, {
      name,
      logoUrl,
      faviconUrl,
      primaryColor,
      accentColor,
      legalEntityType,
      currency,
      tagline,
    });

    if (!updated) {
      throw new NotFoundError(`Tenant '${tenantId}' not found.`);
    }

    db.addAuditLog({
      tenantId,
      userId: req.user?.id || 'system',
      userName: req.user?.name || 'Authorized User',
      userRole: req.user?.role || 'PRESIDENT',
      action: 'TENANT_BRANDING_UPDATED',
      module: 'TENANT',
      details: `Updated branding for tenant '${updated.name}'. Primary: ${updated.primaryColor}, Accent: ${updated.accentColor}`,
    });

    res.json({
      success: true,
      message: 'Tenant branding updated successfully.',
      data: updated,
    });
  } catch (err) {
    next(err);
  }
});
