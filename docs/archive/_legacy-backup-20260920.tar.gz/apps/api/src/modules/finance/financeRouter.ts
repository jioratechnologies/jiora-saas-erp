import { Router, Response } from 'express';
import { db } from '../../core/database/store.js';
import { AuthenticatedRequest, authenticate, requireRole } from '../../core/middleware/auth.js';
import { ValidationError, NotFoundError } from '../../core/errors/index.js';
import { Invoice } from '../../core/types/index.js';

export const financeRouter = Router();

// 1. Get Chart of Accounts (COA) with category totals
financeRouter.get('/coa', authenticate, (req: any, res: Response) => {
  const tenantId = req.tenantId;
  const coa = db.financeCOA.filter((c) => c.tenantId === tenantId);

  const assets = coa.filter((c) => c.type === 'ASSET');
  const liabilities = coa.filter((c) => c.type === 'LIABILITY');
  const revenue = coa.filter((c) => c.type === 'REVENUE');
  const expenses = coa.filter((c) => c.type === 'EXPENSE');

  const totalAssets = assets.reduce((sum, a) => sum + (Number(a.balance) || 0), 0);
  const totalLiabilities = liabilities.reduce((sum, l) => sum + (Number(l.balance) || 0), 0);
  const totalRevenue = revenue.reduce((sum, r) => sum + (Number(r.balance) || 0), 0);
  const totalExpenses = expenses.reduce((sum, e) => sum + (Number(e.balance) || 0), 0);

  res.json({
    success: true,
    summary: {
      totalAssets,
      totalLiabilities,
      totalRevenue,
      totalExpenses,
      operatingSurplus: totalRevenue - totalExpenses,
    },
    accounts: coa,
  });
});

// 2. Get Accounts Receivable & Payable Invoices
financeRouter.get('/invoices', authenticate, (req: any, res: Response) => {
  const tenantId = req.tenantId;
  const allInvoices = db.getInvoices(tenantId);

  const payables = allInvoices.filter((i) => i.invoiceType === 'AP');
  const receivables = allInvoices.filter((i) => i.invoiceType === 'AR');

  const totalReceivables = receivables.reduce((sum, r) => sum + Number(r.amount), 0);
  const totalPayables = payables.reduce((sum, p) => sum + Number(p.amount), 0);

  res.json({
    success: true,
    summary: {
      totalReceivables,
      totalPayables,
      netCashflowProjection: totalReceivables - totalPayables,
    },
    data: allInvoices,
    receivables,
    payables,
  });
});

// 3. Create Invoice (AR or AP)
financeRouter.post('/invoices', authenticate, requireRole(['SUPER_ADMIN', 'APP_DEVELOPER', 'PRESIDENT', 'FINANCE']), (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { invoiceType, invoiceNumber, party, description, amount, dueDate } = req.body;

    if (!invoiceType || !party || !amount) {
      throw new ValidationError('invoiceType (AR/AP), party name, and amount are mandatory.');
    }

    const newInv: Invoice = {
      id: `inv_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      tenantId,
      invoiceType,
      invoiceNumber: invoiceNumber || `INV-${Date.now().toString().slice(-6)}`,
      party,
      description: description || 'Professional services / donor grant invoice',
      amount: Number(amount),
      dueDate: dueDate || new Date(Date.now() + 86400000 * 15).toISOString().split('T')[0],
      status: 'DUE',
      createdAt: new Date().toISOString(),
    };

    db.invoices.unshift(newInv);

    db.addAuditLog({
      tenantId,
      userId: req.user.id,
      userName: req.user.name,
      userRole: req.user.role,
      action: 'INVOICE_CREATED',
      module: 'FINANCE',
      details: `Created ${invoiceType} invoice ${newInv.invoiceNumber} for ${party} (₹${amount})`,
    });

    res.status(201).json({ success: true, data: newInv });
  } catch (err) {
    next(err);
  }
});

// 4. Mark Invoice as Paid
financeRouter.patch('/invoices/:id/pay', authenticate, requireRole(['SUPER_ADMIN', 'APP_DEVELOPER', 'PRESIDENT', 'FINANCE']), (req: any, res: Response, next) => {
  try {
    const tenantId = req.tenantId;
    const { id } = req.params;

    const invoice = db.invoices.find((i) => i.id === id && i.tenantId === tenantId);
    if (!invoice) {
      throw new NotFoundError('Invoice not found.');
    }

    invoice.status = 'PAID';

    db.addChatterMessage({
      tenantId,
      recordType: 'invoice',
      recordId: invoice.id,
      authorId: req.user.id,
      authorName: req.user.name,
      messageType: 'NOTE',
      content: `Invoice marked as PAID by ${req.user.name}.`,
    });

    res.json({ success: true, message: 'Invoice marked as PAID.', data: invoice });
  } catch (err) {
    next(err);
  }
});
